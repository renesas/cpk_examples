**该示例工程由 瑞萨电子-冉庆领 提供，2026年3月11日**

### 工程概述

- 该示例工程演示了基于瑞萨FSP的瑞萨RA MCU上 ACMPHS 驱动程序的基本功能。

### 支持的开发板 / 演示板：

- CPKNET-RA8T2
   
### 硬件要求：

- 1块Renesas RA8开发板：CPKNET-RA8T2 

- 1根USB Type A->Type C或Type-C->Type C线 （支持Type-C 2.0即可）

### 硬件连接：

- 通过 USB Type-C 线连接 CPKNET-RA8T2  板上的 USB 调试端口和调试用主机。

### 硬件设置注意事项：

- 无

### 软件开发环境：
   
- FSP版本
  - FSP 6.3.0
- 集成开发环境和编译器：
  - e2studio v2025-12 + LLVM v21.1.1

### 第三方软件
- 无 
	   

**详细的样例程序配置和使用，请参考下面的文件。**

[acmphs_cpknet_ra8t2_ep_readme](acmphs_cpknet_ra8t2_ep_readme.md)
