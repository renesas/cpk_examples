/*
 * Copyright (C) 2010-2022 Arm Limited or its affiliates. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ----------------------------------------------------------------------
 * Project:      Arm-2D Library
 * Title:        arm-2d_helium.c
 * Description:  Acceleration extensions using Helium.
 *
 * $Date:        24. Dec 2025
 * $Revision:    V.2.0.0
 *
 * Target Processor:  Cortex-M cores with Helium
 *
 * -------------------------------------------------------------------- */

#define __ARM_2D_IMPL__
#define __ARM_2D_IMPLEMENT_HELIUM__     1

#include "arm_2d.h"
#include "__arm_2d_impl.h"

#if defined(__ARM_2D_HAS_HELIUM__) && __ARM_2D_HAS_HELIUM__

#if defined(__clang__)
#   pragma clang diagnostic ignored "-Wunknown-warning-option"
#   pragma clang diagnostic ignored "-Wreserved-identifier"
#   pragma clang diagnostic ignored "-Wincompatible-pointer-types-discards-qualifiers"
#   pragma clang diagnostic ignored "-Wcast-qual"
#   pragma clang diagnostic ignored "-Wcast-align"
#   pragma clang diagnostic ignored "-Wextra-semi-stmt"
#   pragma clang diagnostic ignored "-Wsign-conversion"
#   pragma clang diagnostic ignored "-Wunused-function"
#   pragma clang diagnostic ignored "-Wimplicit-int-float-conversion"
#   pragma clang diagnostic ignored "-Wdouble-promotion"
#   pragma clang diagnostic ignored "-Wunused-parameter"
#   pragma clang diagnostic ignored "-Wimplicit-float-conversion"
#   pragma clang diagnostic ignored "-Wimplicit-int-conversion"
#   pragma clang diagnostic ignored "-Wtautological-pointer-compare"
#   pragma clang diagnostic ignored "-Wmissing-prototypes"
#   pragma clang diagnostic ignored "-Wsign-compare"
#   pragma clang diagnostic ignored "-Wgnu-zero-variadic-macro-arguments"
#   pragma clang diagnostic ignored "-Wpadded"
#   pragma clang diagnostic ignored "-Wvector-conversion"
#   pragma clang diagnostic ignored "-Wundef"
#   pragma clang diagnostic ignored "-Wdeclaration-after-statement"
#   pragma clang diagnostic ignored "-Wunused-variable"
#endif


/*============================ INCLUDES ======================================*/

#include "__arm_2d_utils_helium.h"
#include "__arm_2d_paving_helium.h"
#include "__arm_2d_math_helium.h"

#ifdef   __cplusplus
extern "C" {
#endif

/*============================ MACROS ========================================*/
#define DIV3  (uint32_t)((131072.0f/3.0f) + 0.5f)
/*============================ MACROFIED FUNCTIONS ===========================*/
/*============================ TYPES =========================================*/
/*============================ GLOBAL VARIABLES ==============================*/
/*============================ PROTOTYPES ====================================*/
/*============================ LOCAL VARIABLES ===============================*/
/*============================ IMPLEMENTATION ================================*/

/*!
 * \brief initialise the helium acceleration
 */
void __arm_2d_helium_init(void)
{
    /* even if this is empty, do not remove it */
}


/*----------------------------------------------------------------------------*
 * Code Template for tile operations                                          *
 *----------------------------------------------------------------------------*/

#define __API_COLOUR                c8bit
#define __API_INT_TYPE              uint8_t
#define __API_INT_TYPE_BIT_NUM      8

#include "__arm_2d_ll_copy_helium.inc"

#define __API_COLOUR                rgb16
#define __API_INT_TYPE              uint16_t
#define __API_INT_TYPE_BIT_NUM      16

#include "__arm_2d_ll_copy_helium.inc"


#define __API_COLOUR                rgb32
#define __API_INT_TYPE              uint32_t
#define __API_INT_TYPE_BIT_NUM      32

#include "__arm_2d_ll_copy_helium.inc"


/*
 * common blendig utilities used in:
 * __arm_2d_tile_copy_with_mask_and_opacity_helium.c /__arm_2d_fill_colour_with_horizontal_line_mask_helium.c
 */

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_blend_gray8(uint16x8_t vtrgt, uint16_t chColour, uint16x8_t opa)
{
    uint16x8_t      vTrans = 256 - opa;

    return (vmulq(vTrans, chColour) + vmulq(vtrgt, opa)) >> 8;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_blend_n_gray8(uint16x8_t vtrgt, uint16_t chColour, uint16_t opa)
{
    return vaddq_n_u16(vmulq(vtrgt, opa), ((256 - opa) * chColour)) >> 8;
//    return vmlasq_n_u16(vtrgt, opa, ((256 - opa) * chColour)) >> 8;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_vblend_gray8(uint16x8_t vtrgt, uint16x8_t vSrc, uint16x8_t opa)
{
    uint16x8_t      vTrans = 256 - opa;

    return (vmulq(vTrans, vSrc) + vmulq(vtrgt, opa)) >> 8;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_blend_rgb565(uint16x8_t vtrgt, __arm_2d_color_fast_rgb_t * RGB, uint16x8_t opa)
{
    uint16x8_t      vTrans = 256 - opa;
    uint16x8_t      vRtgt, vGtgt, vBtgt;

    __arm_2d_rgb565_unpack_single_vec(vtrgt, &vRtgt, &vGtgt, &vBtgt);

    vRtgt = (vmulq(vTrans, RGB->R) + vmulq(vRtgt, opa)) >> 8;
    vGtgt = (vmulq(vTrans, RGB->G) + vmulq(vGtgt, opa)) >> 8;
    vBtgt = (vmulq(vTrans, RGB->B) + vmulq(vBtgt, opa)) >> 8;

    return __arm_2d_rgb565_pack_single_vec(vRtgt, vGtgt, vBtgt);
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_blend_n_rgb565(uint16x8_t vtrgt, __arm_2d_color_fast_rgb_t * RGB, uint16_t opa)
{
    uint16_t        trans = 256 - opa;
    uint16x8_t      vRtgt, vGtgt, vBtgt;

    __arm_2d_rgb565_unpack_single_vec(vtrgt, &vRtgt, &vGtgt, &vBtgt);

    vRtgt = vaddq_n_u16(vmulq(vRtgt, opa), (trans * RGB->R)) >> 8;
    vGtgt = vaddq_n_u16(vmulq(vGtgt, opa), (trans * RGB->G)) >> 8;
    vBtgt = vaddq_n_u16(vmulq(vBtgt, opa), (trans * RGB->B)) >> 8;

    return __arm_2d_rgb565_pack_single_vec(vRtgt, vGtgt, vBtgt);
}

#define  __arm_2d_vblend_rgb565  __arm_2d_rgb565_blending_opacity_single_vec


__STATIC_FORCEINLINE
uint16x8_t __arm_2d_blend_cccn888(uint16x8_t       vTrg, uint16x8_t vChColour, uint16x8_t opa)
{
    uint16x8_t      vTrans = 256 - opa;
    return (vTrg * opa + vChColour * vTrans) >> 8;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_blend_n_cccn888(uint16x8_t        vTrg, uint16x8_t vChColour, uint16_t opa)
{
    return (vmulq(vTrg, opa) + vmulq(vChColour,(256 - opa))) >> 8;
}

__STATIC_FORCEINLINE
void __arm_2d_ccca8888_get_and_dup_opa(const uint8_t * pSource, uint16x8_t * opa,
                                           uint16x8_t * src)
{
    /* offset to replicate the opacity accross the 4 channels */
    uint16x8_t      offset = { 3, 3, 3, 3, 7, 7, 7, 7 };

    *src = vldrbq_u16(pSource);

    /*
       replicate alpha, but alpha location = 0 (zeroing) so that transparency = 0x100
       and leaves target 0 unchanged
       vSrcOpa = | opa0 | opa0 | opa0 |  0  | opa1 | opa1 | opa1 |  0  |
     */
    *opa = vldrbq_gather_offset_z_u16(pSource, offset, 0x3f3f);
}

__STATIC_FORCEINLINE
void __arm_2d_ccca8888_get_and_dup_opa_pred(const uint8_t * pSource, uint16x8_t * opa,
                                            uint16x8_t * src, mve_pred16_t tailPred)
{
    /* offset to replicate the opacity accross the 4 channels */
    uint16x8_t      offset = { 3, 3, 3, 3, 7, 7, 7, 7 };

    *src = vldrbq_u16(pSource);

    /*
       replicate alpha, but alpha location = 0 (zeroing) so that transparency = 0x100
       and leaves target 0 unchanged
       vSrcOpa = | opa0 | opa0 | opa0 |  0  | opa1 | opa1 | opa1 |  0  |
     */
    *opa = vldrbq_gather_offset_z_u16(pSource, offset, 0x3f3f & tailPred);
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_unpack_and_blend_gray8(const uint8_t * pchTarget, uint16x8_t opa,
                                               uint16x8_t R, uint16x8_t G, uint16x8_t B)
{
    uint16x8_t      vtrgt = vldrbq_u16(pchTarget);
    uint16x8_t      vTrans = 256 - opa;

    uint16x8_t      vAvg = R + G + B;
    vAvg = vAvg / 3;

    return (vmulq(vAvg, opa) + vmulq(vtrgt, vTrans)) >> 8;
}


__STATIC_FORCEINLINE
uint16x8_t __arm_2d_unpack_and_blend_rg565(const uint16_t * phwTarget, uint16x8_t opa,
                                               uint16x8_t vRsrc, uint16x8_t vGsrc, uint16x8_t vBsrc)
{
    uint16x8_t      vtrgt = vld1q(phwTarget);
    uint16x8_t      vTrans = 256 - opa;
    uint16x8_t      vRtgt, vGtgt, vBtgt;

    __arm_2d_rgb565_unpack_single_vec(vtrgt, &vRtgt, &vGtgt, &vBtgt);


    vRtgt = (vmulq(vRsrc, opa) + vmulq(vRtgt, vTrans)) >> 8;
    vGtgt = (vmulq(vGsrc, opa) + vmulq(vGtgt, vTrans)) >> 8;
    vBtgt = (vmulq(vBsrc, opa) + vmulq(vBtgt, vTrans)) >> 8;

    return __arm_2d_rgb565_pack_single_vec(vRtgt, vGtgt, vBtgt);
}


__STATIC_FORCEINLINE
uint16x8_t __arm_2d_unpack_and_blend_cccn888(const uint8_t * pwTarget, 
                                             uint16x8_t opa,
                                             uint16x8_t vSrc)
{
    uint16x8_t      vTrg = vldrbq_u16(pwTarget);
    uint16x8_t      vTrans = 256 - opa;

    return (vTrg * vTrans + vSrc * opa) >> 8;
}

/**
  @brief         return 3 vector of 16-bit channels (8-bit widened) taken from a memory reference
  @param[in]     pMem           pointer to packed 8-bit channel
  @param[out]    R              vector of 16-bit widened R channel
  @param[out]    G              vector of 16-bit widened G channel
  @param[out]    B              vector of 16-bit widened B channel
 */
__STATIC_FORCEINLINE
void __arm_2d_unpack_cccn888_from_mem(const uint8_t * pMem, 
                                     uint16x8_t * R, 
                                     uint16x8_t * G,
                                     uint16x8_t * B)
{
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    
    *B = vldrbq_gather_offset_u16(pMem, sg);
    *G = vldrbq_gather_offset_u16(pMem + 1, sg);
    *R = vldrbq_gather_offset_u16(pMem + 2, sg);
}

/**
  @brief         return 3 vector of 16-bit channels (8-bit widened) taken from a memory reference
  @param[in]     pMem           pointer to packed 8-bit channel
  @param[out]    R              vector of 16-bit widened R channel
  @param[out]    G              vector of 16-bit widened G channel
  @param[out]    B              vector of 16-bit widened B channel
  @param[in]     p              tail predition
 */
__STATIC_FORCEINLINE
void __arm_2d_unpack_cccn888_from_mem_z( const uint8_t * pMem, 
                                        uint16x8_t * R,
                                        uint16x8_t * G, 
                                        uint16x8_t * B,
                                        mve_pred16_t p)
{
    uint16x8_t      sg = vidupq_n_u16(0, 4);

    *B = vldrbq_gather_offset_z_u16(pMem, sg, p);
    *G = vldrbq_gather_offset_z_u16(pMem + 1, sg, p);
    *R = vldrbq_gather_offset_z_u16(pMem + 2, sg, p);
}


/**
  @brief         return 4 vector of 16-bit channels (8-bit widened) taken from a memory reference
  @param[in]     pMem           pointer to packed 8-bit channel
  @param[out]    R              vector of 16-bit widened R channel
  @param[out]    G              vector of 16-bit widened G channel
  @param[out]    B              vector of 16-bit widened B channel
  @param[out]    A              vector of 16-bit widened A channel
 */
__STATIC_FORCEINLINE
void __arm_2d_unpack_ccca8888_from_mem( const uint32_t *pwPixel, 
                                        uint16x8_t * R,
                                        uint16x8_t * G, 
                                        uint16x8_t * B,
                                        uint16x8_t * A)
{
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    const uint8_t * pMem = (uint8_t *)pwPixel;
    *B = vldrbq_gather_offset_u16(pMem, sg);
    *G = vldrbq_gather_offset_u16(pMem + 1, sg);
    *R = vldrbq_gather_offset_u16(pMem + 2, sg);
    *A = vldrbq_gather_offset_u16(pMem + 3, sg);
}

/**
  @brief         return 4 vector of 16-bit channels (8-bit widened) taken from a memory reference
  @param[in]     pMem           pointer to packed 8-bit channel
  @param[out]    R              vector of 16-bit widened R channel
  @param[out]    G              vector of 16-bit widened G channel
  @param[out]    B              vector of 16-bit widened B channel
  @param[out]    A              vector of 16-bit widened A channel
 */
__STATIC_FORCEINLINE
void __arm_2d_unpack_ccca8888_from_mem_z(   const uint32_t *pwPixel, 
                                            uint16x8_t * R,
                                            uint16x8_t * G, 
                                            uint16x8_t * B,
                                            uint16x8_t * A,
                                            mve_pred16_t p)
{
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    const uint8_t * pMem = (uint8_t *)pwPixel;
    *B = vldrbq_gather_offset_z_u16(pMem, sg, p);
    *G = vldrbq_gather_offset_z_u16(pMem + 1, sg, p);
    *R = vldrbq_gather_offset_z_u16(pMem + 2, sg, p);
    *A = vldrbq_gather_offset_z_u16(pMem + 3, sg, p);
}

/**
  @brief         interleave 3 x 16-bit widened vectors into 8-bit memory reference
                 (4th channel untouched)
  @param[in]     pMem           pointer to packed 8-bit channel
  @param[in]     R              vector of 16-bit widened R channel
  @param[in]     G              vector of 16-bit widened G channel
  @param[in]     B              vector of 16-bit widened B channel
 */
__STATIC_FORCEINLINE
void __arm_2d_pack_rgb888_to_mem(uint8_t * pMem, uint16x8_t R, uint16x8_t G, uint16x8_t B)
{
    uint16x8_t      sg = vidupq_n_u16(0, 4);

    vstrbq_scatter_offset_u16(pMem,     sg, vminq(B, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16(pMem + 1, sg, vminq(G, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16(pMem + 2, sg, vminq(R, vdupq_n_u16(255)));
    //vstrbq_scatter_offset_u16(pMem + 3, sg, vdupq_n_u16(0));
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_scale_alpha_n_opa( uint16x8_t vPixelAlpha, uint_fast16_t hwOpacity)
{
    /* vPixelAlpha: 0~255 */
    /* hwOpacity: 0~256 */
    return vmulq(vPixelAlpha,  hwOpacity) >> 8;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_scale_alpha_mask(   uint16x8_t vPixelAlpha, /* will become 0 ~ 256 */
                                        uint16x8_t vMask)       /* input range 0 ~ 255 */
{
    /* vPixelAlpha: 0~256 */
    vPixelAlpha = vpselq(vdupq_n_u16(256), vPixelAlpha, vcmpeqq_n_u16(vPixelAlpha, 255));

    /* vSrcMask: 0~255 */
    vPixelAlpha = vmulq(vPixelAlpha, vMask) >> 8;
    return vPixelAlpha;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_scale_alpha_mask_n_opa( uint16x8_t vPixelAlpha, uint16x8_t vMask,
                                            uint_fast16_t hwOpacity)
{
    /* vPixelAlpha: 0~256 */
    vPixelAlpha = vpselq(vdupq_n_u16(256), vPixelAlpha, vcmpeqq_n_u16(vPixelAlpha, 255));

    /* vSrcMask: 0~255 */
    /* hwOpacity: 0~256 */
    vPixelAlpha = vmulq(vPixelAlpha, (vmulq(vMask, hwOpacity) >> 8)) >> 8;
    return vPixelAlpha;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_scale_alpha_mask_opa(uint16x8_t vPixelAlpha, uint16x8_t vMask,
                                         uint16x8_t vOpacity)
{
    
    /* vPixelAlpha: 0~256 */
    vPixelAlpha = vpselq(vdupq_n_u16(256), vPixelAlpha, vcmpeqq_n_u16(vPixelAlpha, 255));

    /* vSrcMask: 0~255 */
    /* vOpacity: 0~256 */
    vPixelAlpha = vmulq(vPixelAlpha, (vmulq(vMask, vOpacity) >> 8)) >> 8;
    return vPixelAlpha;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_scale_alpha_masks(uint16x8_t vPixelAlpha, uint16x8_t vSrcMask,
                                      uint16x8_t vDesMask)
{
    /* vPixelAlpha: 0~256 */
    vPixelAlpha = vpselq(vdupq_n_u16(256), vPixelAlpha, vcmpeqq_n_u16(vPixelAlpha, 255));

    /* vDesMask：0 ~ 256 */
    vDesMask = vpselq(vdupq_n_u16(256), vDesMask, vcmpeqq_n_u16(vDesMask, 255));

    /* vSrcMask: 0~255 */
    vPixelAlpha = vmulq(vPixelAlpha, 
                        (vmulq(vSrcMask, vDesMask) >> 8))   
                >> 8;
    return vPixelAlpha;
}

__STATIC_FORCEINLINE
uint16x8_t __arm_2d_scale_alpha_masks_n_opa(uint16x8_t vPixelAlpha,     /* vPixelAlpha: 0~256 */
                                            uint16x8_t vSrcMask,        /* vSrcMask: 0~255 */
                                            uint16x8_t vDesMask,        /* vDesMask：0 ~ 256 */
                                            uint16_t hwOpacity)         /* hwOpacity: 0 ~ 256 */
{                       
    /* vPixelAlpha: 0~256 */
    vPixelAlpha = vpselq(vdupq_n_u16(256), vPixelAlpha, vcmpeqq_n_u16(vPixelAlpha, 255));

    /* vDesMask：0 ~ 256 */
    vDesMask = vpselq(vdupq_n_u16(256), vDesMask, vcmpeqq_n_u16(vDesMask, 255));

    /* vSrcMask: 0~255 */
    vPixelAlpha = vmulq(vPixelAlpha, 
                        (vmulq(vSrcMask, vDesMask) >> 8))   
                >> 8;

    /* hwOpacity: 0~256 */
    vPixelAlpha = vmulq(vPixelAlpha, hwOpacity) >> 8;

    return vPixelAlpha;
}


/*---------------------------------------------------------------------------*
 * CCCA8888 pixel blend to GRAY8                                             *
 *---------------------------------------------------------------------------*/
__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_gray8(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount
)
{
/* In Arm Compiler 6.24, it reports an issue: 

    E:\Work\Arm-2D\Library\Source\arm_2d_helium.c(347): error: invalid instruction, any one of the following would fix this:
      347 |         "   vldrb.u16       q4, [%[pchTarget]]              \n"
          |          ^
    E:\Work\Arm-2D\examples\[template][bare-metal][an552]\project\mdk\<inline asm>(19): note: instantiated into assembly here
       19 |    vldrb.u16       q4, [r11]              
          |    ^
    E:\Work\Arm-2D\Library\Source\arm_2d_helium.c(347): note: invalid operand for instruction
    
    Here is an ugly workaround: using intrinsics.
*/

#if 1 //def USE_MVE_INTRINSICS
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        vSrcOpa = vpselq(v256, vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255));

        vstrbq_p_u16(pchTarget,
            __arm_2d_unpack_and_blend_gray8(pchTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrc += 8;
        pchTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
#else

        register unsigned loopCnt  __asm("lr");
        loopCnt = iBlockCount;

    __asm volatile(
        ".p2align 2                                         \n"

        // pipelining
        "   vld20.8         {q2,q3}, [%[pwSrc]]             \n"
        "   vdup.16         q1, %[one_third]                \n"
        "   vld21.8         {q2,q3}, [%[pwSrc]]!            \n"
        "   vmov.i16        q0, #0x100                      \n"
        "   wlstp.16        lr, %[loopCnt], 1f              \n"

        "2:                                                 \n"
        // Opacity
        "   vmovlt.u8       q4, q3                          \n"
        "   vmovlb.u8       q3, q3                          \n"
        "   vmovlt.u8       q5, q2                          \n"
        "   vmovlb.u8       q2, q2                          \n"
        // averaging
        "   vadd.i16        q6, q3, q5                      \n"
        "   vadd.i16        q6, q6, q2                      \n"
        "   vmulh.u16       q6, q6, q1                      \n"
        // Transparency
        "   vsub.i16        q7, q0, q4                      \n"
        "   vld20.8         {q2,q3}, [%[pwSrc]]             \n"
        "   vshr.u16        q6, q6, #0x1                    \n"
        "   vmul.i16        q6, q6, q4                      \n"
        "   vldrb.u16       q4, [%[pchTarget]]              \n"
        "   vmul.i16        q7, q7, q4                      \n"
        "   vld21.8         {q2,q3}, [%[pwSrc]]!            \n"
        "   vadd.i16        q6, q6, q7                      \n"
        // 8-bit right shift
        "   vqdmulh.s16     q6, q6, %[inv2pow8]             \n"
        "   vstrb.u16       q6, [%[pchTarget]] , #8         \n"
        "   letp            lr, 2b                          \n"
        "1:                                                 \n"

        : [pchTarget] "+r" (pchTarget),
          [pwSrc] "+r" (pwSrc), [loopCnt] "+r"(loopCnt)
        : [one_third] "r" (0xaaab),
          [inv2pow8] "r" ( 1 << (15 - 8)) //  /* 1/(2^8) in Q.15 */
        : "q0", "q1", "q2", "q3",
          "q4", "q5", "q6", "q7",
          "memory" );

#endif
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_gray8_with_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
#ifdef USE_MVE_INTRINSICS
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        vSrcOpa=  vmulq_n_u16(vSrcOpa, hwOpacity) >> 8;
        vSrcOpa = vpselq(v256, vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255));

        vstrbq_p_u16(pchTarget,
            __arm_2d_unpack_and_blend_gray8(pchTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrc += 8;
        pchTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
#else
        register unsigned loopCnt  __asm("lr");
        loopCnt = iBlockCount;

    __asm volatile(
            ".p2align 2                                           \n"

            "oneThird            .req q2                          \n"

            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vdup.16         oneThird, %[one_third]             \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vdup.16         q1, %[cst256]                      \n"

            "   wlstp.16        lr, %[loopCnt], 1f                \n"
            "2:                                                   \n"

            "  vmovlt.u8       q5, q4                             \n"
            /* vpselq(vdupq_n_u16(256),vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255)); */
            "  vpt.i16         eq, q5, %[cst255]                  \n"
            "  vmovt           q5, q1                             \n"

            "  vmovlt.u8       q6, q3                             \n"
            "  vmul.i16        q0, q5, %[hwOpacity]               \n"
            "  vmovlb.u8       q3, q3                             \n"
            "  vldrb.u16       q5, [%[pchTarget]]                 \n"
            /* vSrcOpa=  vmulq_n_u16(vSrcOpa, hwOpacity)  >> 8; */
            "  vshr.u16        q7, q0, #0x8                       \n"
            "  vmovlb.u8       q4, q4                             \n"
            /* average for gray8 pack : (R + G + B) / 3*/
            "  vadd.i16        q4, q6, q4                         \n"
            "  vadd.i16        q3, q4, q3                         \n"
            "  vmulh.u16       q4, q3, oneThird                   \n"

            /* blend */
            /* (vmulq(vAvg, opa) + vmulq(vtrgt, vTrans)) >> 8; */
            "  vsub.i16        q3, q1, q7                         \n"
            "  vmul.i16        q0, q3, q5                         \n"
            "  vshr.u16        q3, q4, #0x1                       \n"
            "  vmul.i16        q7, q3, q7                         \n"
            /* pipeline */
            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vadd.i16        q7, q0, q7                         \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vstrb.u16       q7, [%[pchTarget]] , #8            \n"
            "  letp            lr, 2b                             \n"
            "1:                                                   \n"

            ".unreq oneThird                                       \n"
        : [pchTarget] "+l" (pchTarget),
          [pwSrc] "+r" (pwSrc), [loopCnt] "+r"(loopCnt)
        : [one_third] "r" (DIV3), [hwOpacity] "r" (hwOpacity),
          [cst255] "r" (255), [cst256] "r" (256)
        : "q0", "q1", "q2", "q3",
          "q4", "q5", "q6", "q7",
          "memory" );
#endif
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_gray8_with_src_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
#ifdef USE_MVE_INTRINSICS
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_z_u16(pchSrcMsk, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity);

        vstrbq_p_u16(pchTarget,
            __arm_2d_unpack_and_blend_gray8(pchTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pchSrcMsk += 8;
        pwSrc += 8;
        pchTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
#else
        //const uint8_t  *__RESTRICT pSource = (const uint8_t *) pwSrc;

        register unsigned loopCnt  __asm("lr");
        loopCnt = iBlockCount;


    __asm volatile(
            ".p2align 2                                           \n"

            "oneThird            .req q2                          \n"

            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vdup.16         oneThird, %[one_third]             \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vdup.16         q1, %[cst256]                      \n"


            "   wlstp.16        lr, %[loopCnt], 1f                \n"
            "2:                                                   \n"

            "  vmovlt.u8       q5, q4                             \n"
            /* vpselq(vdupq_n_u16(256),vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255)); */
            "  vpt.i16         eq, q5, %[cst255]                  \n"
            "  vmovt           q5, q1                             \n"

            "  vldrb.u16       q7, [%[pchSrcMsk]], #8     \n"

            "  vmovlt.u8       q6, q3                             \n"
            /* __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity); */
            "  vmul.i16        q7, q7, %[hwOpacity]               \n"


            "  vmovlb.u8       q3, q3                             \n"
            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vmul.i16        q7, q5, q7                         \n"

            "  vldrb.u16       q5, [%[pchTarget]]                 \n"

            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vmovlb.u8       q4, q4                             \n"
            /* average for gray8 pack : (R + G + B) / 3*/
            "  vadd.i16        q4, q6, q4                         \n"
            "  vadd.i16        q3, q4, q3                         \n"
            "  vmulh.u16       q4, q3, oneThird                   \n"

            /* blend */
            /* (vmulq(vAvg, opa) + vmulq(vtrgt, vTrans)) >> 8; */
            "  vsub.i16        q3, q1, q7                         \n"
            "  vmul.i16        q0, q3, q5                         \n"
            "  vshr.u16        q3, q4, #0x1                       \n"
            "  vmul.i16        q7, q3, q7                         \n"
            /* pipeline */
            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vadd.i16        q7, q0, q7                         \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vstrb.u16       q7, [%[pchTarget]] , #8            \n"
            "  letp            lr, 2b                             \n"
            "1:                                                   \n"

            ".unreq oneThird                                       \n"

        : [pchTarget] "+l" (pchTarget),
          [pwSrc] "+r" (pwSrc), [pchSrcMsk] "+l" (pchSrcMsk),
          [loopCnt] "+r"(loopCnt)
        : [one_third] "r" (DIV3), [hwOpacity] "r" (hwOpacity),
          [cst255] "r" (255), [cst256] "r" (256)
        : "q0", "q1", "q2", "q3",
          "q4", "q5", "q6", "q7",
          "memory" );
#endif
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_gray8_with_src_mask(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount
)
{
#ifdef USE_MVE_INTRINSICS
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_z_u16(pchSrcMsk, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask);

        vstrbq_p_u16(pchTarget,
            __arm_2d_unpack_and_blend_gray8(pchTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pchSrcMsk += 8;
        pwSrc += 8;
        pchTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
#else

        register unsigned loopCnt  __asm("lr");
        loopCnt = iBlockCount;


    __asm volatile(
            ".p2align 2                                           \n"

            "oneThird            .req q2                          \n"

            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vdup.16         oneThird, %[one_third]             \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vdup.16         q1, %[cst256]                      \n"


            "   wlstp.16        lr, %[loopCnt], 1f                \n"
            "2:                                                   \n"

            "  vmovlt.u8       q5, q4                             \n"
            /* vpselq(vdupq_n_u16(256),vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255)); */
            "  vpt.i16         eq, q5, %[cst255]                  \n"
            "  vmovt           q5, q1                             \n"

            "  vldrb.u16       q7, [%[pchSrcMsk]], #8             \n"

            "  vmovlt.u8       q6, q3                             \n"

            /* __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask); */
            "  vmul.i16        q7, q5, q7                         \n"

            "  vmovlb.u8       q3, q3                             \n"

            "  vldrb.u16       q5, [%[pchTarget]]                 \n"

            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vmovlb.u8       q4, q4                             \n"
            /* average for gray8 pack : (R + G + B) / 3*/
            "  vadd.i16        q4, q6, q4                         \n"
            "  vadd.i16        q3, q4, q3                         \n"
            "  vmulh.u16       q4, q3, oneThird                   \n"

            /* blend */
            /* (vmulq(vAvg, opa) + vmulq(vtrgt, vTrans)) >> 8; */
            "  vsub.i16        q3, q1, q7                         \n"
            "  vmul.i16        q0, q3, q5                         \n"
            "  vshr.u16        q3, q4, #0x1                       \n"
            "  vmul.i16        q7, q3, q7                         \n"
            /* pipeline */
            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vadd.i16        q7, q0, q7                         \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vstrb.u16       q7, [%[pchTarget]] , #8            \n"
            "  letp            lr, 2b                             \n"
            "1:                                                   \n"

            ".unreq oneThird                                       \n"

        : [pchTarget] "+l" (pchTarget),
          [pwSrc] "+r" (pwSrc), [pchSrcMsk] "+l" (pchSrcMsk),
          [loopCnt] "+r"(loopCnt)
        : [one_third] "r" (DIV3),
          [cst255] "r" (255), [cst256] "r" (256)
        : "q0", "q1", "q2", "q3",
          "q4", "q5", "q6", "q7",
          "memory" );
#endif
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_gray8_with_src_chn_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
#ifdef USE_MVE_INTRINSICS
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_gather_offset_z_u16((const uint8_t *)pwSrcMsk, vStride4Offs, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity);

        vstrbq_p_u16(pchTarget,
            __arm_2d_unpack_and_blend_gray8(pchTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrcMsk += 8;
        pwSrc += 8;
        pchTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
#else
        register unsigned loopCnt  __asm("lr");
        uint16x8_t      scratch[1];
        vst1q((uint16_t*)&scratch[0], vdupq_n_u16((DIV3)));
        loopCnt = iBlockCount;
        uint32_t incr4 = 0;

    __asm volatile(
            ".p2align 2                                           \n"

            "gathOfs            .req q2                           \n"
            "  vidup.u16       gathOfs, %[incr], #0x4             \n"

            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"

            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vdup.16         q1, %[cst256]                      \n"


            "   wlstp.16        lr, %[loopCnt], 1f                \n"
            "2:                                                   \n"

            "  vmovlt.u8       q5, q4                             \n"
            /* vpselq(vdupq_n_u16(256),vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255)); */
            "  vpt.i16         eq, q5, %[cst255]                  \n"
            "  vmovt           q5, q1                             \n"

            "  vldrb.u16       q7, [%[pwSrcMsk], gathOfs]    \n"

            "  vmovlt.u8       q6, q3                             \n"
            /* __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity); */
            "  vmul.i16        q7, q7, %[hwOpacity]               \n"


            "  vmovlb.u8       q3, q3                             \n"
            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vmul.i16        q7, q5, q7                         \n"

            "  vldrb.u16       q5, [%[pchTarget]]                 \n"

            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vmovlb.u8       q4, q4                             \n"
            /* average for gray8 pack : (R + G + B) / 3*/
            "  vadd.i16        q4, q6, q4                         \n"
            "  vldrh.u16       q0, [%[scratch]]                   \n"
            "  vadd.i16        q3, q4, q3                         \n"
            "  vmulh.u16       q4, q3, q0                         \n"

            /* blend */
            /* (vmulq(vAvg, opa) + vmulq(vtrgt, vTrans)) >> 8; */
            "  vsub.i16        q3, q1, q7                         \n"
            "  vmul.i16        q0, q3, q5                         \n"
            "  vshr.u16        q3, q4, #0x1                       \n"
            "  vmul.i16        q7, q3, q7                         \n"

            "  vidup.u16       gathOfs, %[incr], #0x4             \n"
            /* pipeline */
            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vadd.i16        q7, q0, q7                         \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vstrb.u16       q7, [%[pchTarget]] , #8            \n"
            "  letp            lr, 2b                             \n"
            "1:                                                   \n"

            ".unreq gathOfs                                      \n"

        : [pchTarget] "+l" (pchTarget),
          [pwSrc] "+r" (pwSrc), [pwSrcMsk] "+l" (pwSrcMsk),
          [loopCnt] "+r"(loopCnt),
          [incr] "+Te" (incr4)
        : [hwOpacity] "r" (hwOpacity),
          [cst255] "r" (255), [cst256] "r" (256),
          [cst32] "r" (32), [scratch] "r" (scratch)

        : "q0", "q1", "q2", "q3",
          "q4", "q5", "q6", "q7",
          "memory" );
#endif
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_gray8_with_src_chn_mask(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount
)
{
#ifdef USE_MVE_INTRINSICS
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_gather_offset_z_u16((const uint8_t *)pwSrcMsk, vStride4Offs, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask);

        vstrbq_p_u16(pchTarget,
            __arm_2d_unpack_and_blend_gray8(pchTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrcMsk += 8;
        pwSrc += 8;
        pchTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
#else

        register unsigned loopCnt  __asm("lr");
        uint16x8_t      scratch[1];
        vst1q((uint16_t*)&scratch[0], vdupq_n_u16((DIV3)));
        loopCnt = iBlockCount;
        uint32_t incr4 = 0;

    __asm volatile(
            ".p2align 2                                           \n"

            "gathOfs            .req q2                           \n"
            "  vidup.u16       gathOfs, %[incr], #0x4             \n"

            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"

            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vdup.16         q1, %[cst256]                      \n"


            "   wlstp.16        lr, %[loopCnt], 1f                \n"
            "2:                                                   \n"

            "  vmovlt.u8       q5, q4                             \n"
            /* vpselq(vdupq_n_u16(256),vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255)); */
            "  vpt.i16         eq, q5, %[cst255]                  \n"
            "  vmovt           q5, q1                             \n"

            "  vldrb.u16       q7, [%[pwSrcMsk], gathOfs]    \n"

            "  vmovlt.u8       q6, q3                             \n"
            /* __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask); */
            "  vmul.i16        q7, q5, q7                         \n"

            "  vmovlb.u8       q3, q3                             \n"

            "  vldrb.u16       q5, [%[pchTarget]]                 \n"

            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vmovlb.u8       q4, q4                             \n"
            /* average for gray8 pack : (R + G + B) / 3*/
            "  vadd.i16        q4, q6, q4                         \n"
            "  vldrh.u16       q0, [%[scratch]]                   \n"
            "  vadd.i16        q3, q4, q3                         \n"
            "  vmulh.u16       q4, q3, q0                         \n"

            /* blend */
            /* (vmulq(vAvg, opa) + vmulq(vtrgt, vTrans)) >> 8; */
            "  vsub.i16        q3, q1, q7                         \n"
            "  vmul.i16        q0, q3, q5                         \n"
            "  vshr.u16        q3, q4, #0x1                       \n"
            "  vmul.i16        q7, q3, q7                         \n"

            "  vidup.u16       gathOfs, %[incr], #0x4             \n"
            /* pipeline */
            "  vld20.8         {q3,q4}, [%[pwSrc]]                \n"
            "  vadd.i16        q7, q0, q7                         \n"
            "  vld21.8         {q3,q4}, [%[pwSrc]]!               \n"
            "  vshr.u16        q7, q7, #0x8                       \n"
            "  vstrb.u16       q7, [%[pchTarget]] , #8            \n"
            "  letp            lr, 2b                             \n"
            "1:                                                   \n"

            ".unreq gathOfs                                      \n"

        : [pchTarget] "+l" (pchTarget),
          [pwSrc] "+r" (pwSrc), [pwSrcMsk] "+l" (pwSrcMsk),
          [loopCnt] "+r"(loopCnt),
          [incr] "+Te" (incr4)
        : [cst255] "r" (255), [cst256] "r" (256),
          [cst32] "r" (32), [scratch] "r" (scratch)

        : "q0", "q1", "q2", "q3",
          "q4", "q5", "q6", "q7",
          "memory" );
#endif
}

/*---------------------------------------------------------------------------*
 * CCCA8888 pixel blend to CCCN888                                           *
 *---------------------------------------------------------------------------*/
__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_cccn888(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount
)
{
#if 1 //USE_MVE_INTRINSICS  // todo: check error
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t vSrc, vSrcOpa;

        __arm_2d_ccca8888_get_and_dup_opa_pred((const uint8_t *)pwSrc, &vSrcOpa, &vSrc, tailPred);

        vSrcOpa = vpselq(v256, vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255));

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vSrcOpa, vSrc),
            tailPred);

        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
#else
    /* offset to replicate the opacity accross the 4 channels */
    const uint16x8_t offset = {3, 3, 3, 3, 7, 7, 7, 7};

    register unsigned loopCnt  __asm("lr");
    loopCnt = iBlockCount;

      __asm volatile(
            ".p2align 2                                         \n"

            "   vmsr            p0, %[repl_pred_msk]            \n"

            "   vpst                                            \n"
            "   vldrbt.u16      q5, [%[pwSrc], %q[offset]]      \n"
            "   vmov.i16        q0, #0x100                      \n"
            "   vldrb.u16       q4, [%[pwSrc]], #8              \n"

            // 2 x 32-bit pixel / loop
            "   wlstp.64        lr, %[loopCnt], 1f              \n"

            "2:                                                 \n"
            "   vmul.i16        q4, q5, q4                      \n"
            "   vldrb.u16       q2, [%[pwTarget]]               \n"
            // transparency
            "   vsub.i16        q3, q0, q5                      \n"
            "   vmul.i16        q3, q3, q2                      \n"
            // Opacity
            "   vpst                                            \n"
            "   vldrbt.u16      q5, [%[pwSrc], %q[offset]]      \n"
            "   vadd.i16        q3, q3, q4                      \n"
            "   vldrb.u16       q4, [%[pwSrc]], #8              \n"
            "   vshr.u16        q3, q3, #0x8                    \n"

            "   vstrb.16        q3, [%[pwTarget]], #8           \n"
            "   letp            lr, 2b                          \n"
            "1:                                                 \n"
            : [pwTarget] "+r" (pwTarget),
              [pwSrc] "+r" (pwSrc), [loopCnt] "+r"(loopCnt)
            : [repl_pred_msk] "r" (0x3f3f), [offset] "t" (offset)
            : "q0", "q1", "q2", "q3",
              "q4", "q5",
              "memory" );
#endif
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_cccn888_with_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t vSrc, vSrcOpa;

        __arm_2d_ccca8888_get_and_dup_opa_pred((const uint8_t *)pwSrc, &vSrcOpa, &vSrc, tailPred);

        vSrcOpa=  vmulq_n_u16(vSrcOpa, hwOpacity) >> 8;
        vSrcOpa = vpselq(v256, vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255));

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vSrcOpa, vSrc),
            tailPred);

        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_cccn888_with_src_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    /* offset to replicate 2 masks accross the 4 channels */
    const uint16x8_t offsetMsk = {0, 0, 0, 0, 1, 1, 1, 1};
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t vSrc, vSrcOpa;

        __arm_2d_ccca8888_get_and_dup_opa_pred((const uint8_t *)pwSrc, &vSrcOpa, &vSrc, tailPred);

        uint16x8_t vSrcMask = vldrbq_gather_offset_u16((const uint8_t *)pchSrcMsk,  offsetMsk);
        vSrcOpa = __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity);

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vSrcOpa, vSrc),
            tailPred);

        pchSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_cccn888_with_src_mask(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount
)
{
    /* offset to replicate 2 masks accross the 4 channels */
    const uint16x8_t offsetMsk = {0, 0, 0, 0, 1, 1, 1, 1};
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t vSrc, vSrcOpa;

        __arm_2d_ccca8888_get_and_dup_opa_pred((const uint8_t *)pwSrc, &vSrcOpa, &vSrc, tailPred);

        uint16x8_t vSrcMask = vldrbq_gather_offset_u16((const uint8_t *)pchSrcMsk,  offsetMsk);
        vSrcOpa = __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask);

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vSrcOpa, vSrc),
            tailPred);

        pchSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_cccn888_with_src_chn_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    /* offset to replicate 2 masks accros the 4 channels */
    const uint16x8_t offsetMsk = {0, 0, 0, 0, 4, 4, 4, 4};

    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t vSrc, vSrcOpa;

        __arm_2d_ccca8888_get_and_dup_opa_pred((const uint8_t *)pwSrc, &vSrcOpa, &vSrc, tailPred);

        uint16x8_t vSrcMask = vldrbq_gather_offset_u16((const uint8_t *)pwSrcMsk,  offsetMsk);
        vSrcOpa = __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity);

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vSrcOpa, vSrc),
            tailPred);

        pwSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_cccn888_with_src_chn_mask(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount
)
{
    /* offset to replicate 2 masks accros the 4 channels */
    const uint16x8_t offsetMsk = {0, 0, 0, 0, 4, 4, 4, 4};

    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t vSrc, vSrcOpa;

        __arm_2d_ccca8888_get_and_dup_opa_pred((const uint8_t *)pwSrc, &vSrcOpa, &vSrc, tailPred);

        uint16x8_t vSrcMask = vldrbq_gather_offset_u16((const uint8_t *)pwSrcMsk,  offsetMsk);
        vSrcOpa = __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask);

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vSrcOpa, vSrc),
            tailPred);

        pwSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

/*---------------------------------------------------------------------------*
 * CCCA8888 pixel blend to RGB565                                            *
 *---------------------------------------------------------------------------*/
__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_rgb565(
    uint32_t *__RESTRICT pwSrc,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount
)
{
#ifdef USE_MVE_INTRINSICS
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);
        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        vSrcOpa = vpselq(v256, vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255));

        vst1q_p(phwTarget,
            __arm_2d_unpack_and_blend_rg565(phwTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrc += 8;
        phwTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
#else
    uint16x8_t      scratch[2];
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0xf800));
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x7e0));


    register unsigned loopCnt  __asm("lr");
    loopCnt = iBlockCount;

    __asm volatile(
        ".p2align 2                                         \n"

        // pipelining
        "   vldrh.u16       q4, [%[phwTarget]]              \n"
        "   vmov.i16        q0, #0xf8                       \n"
        "   vld20.8         {q5,q6}, [%[pwSrc]]             \n"
        "   wlstp.16        lr, %[loopCnt], 1f              \n"
        "   vld21.8         {q5,q6}, [%[pwSrc]]!            \n"


        "2:                                                 \n"
        "   vrev16.8        q7, q6                          \n"
        "   vmullb.u8       q3, q5, q7                      \n"
        // Opacity
        "   vmovlt.u8       q2, q6                          \n"
        "   vmov.i16        q1, #0x100                      \n"
        // Transparency
        "   vsub.i16        q2, q1, q2                      \n"
        // vmullt combines vmovlt + vmul
        "   vmullt.u8       q1, q5, q6                      \n"
        "   vshr.u16        q5, q4, #0x3                    \n"
        "   vmullb.u8       q7, q6, q7                      \n"
        "   vshr.u16        q6, q4, #0x8                    \n"
        "   vmul.i16        q4, q4,  %[eight]               \n"
        "   vand q6,        q6, q0                          \n"
        "   vmul.i16        q6, q2, q6                      \n"
        "   vand            q4, q4, q0                      \n"
        "   vmul.i16        q4, q2, q4                      \n"
        "   vadd.i16        q6, q6, q1                      \n"
        "   vmov.i16        q1, #0xfc                       \n"
        "   vand            q5, q5, q1                      \n"
        "   vmul.i16        q2, q2, q5                      \n"
        "   vadd.i16        q1, q4, q3                      \n"
        // vector of 0xf800
        "   vldrw.u32       q4, [%[scratch], #16]           \n"
        "   vand            q3, q6, q4                      \n"
        "   vld20.8         {q5,q6}, [%[pwSrc]]             \n"
        "   vshr.u16        q1, q1, #0xb                    \n"
        "   vldrh.u16       q4, [%[phwTarget], #16]         \n"
        "   vadd.i16        q2, q2, q7                      \n"
        "   vqdmulh.s16     q2, q2, %[inv2pow5]             \n"
        "   vorr            q1, q3, q1                      \n"
        // vector of 0x7e0
        "   vldrw.u32       q7, [%[scratch]]                \n"
        "   vand            q2, q2, q7                      \n"
        "   vld21.8         {q5,q6}, [%[pwSrc]]!            \n"
        "   vorr            q1, q1, q2                      \n"
        "   vstrh.u16       q1, [%[phwTarget]] , #16        \n"
        "   letp            lr, 2b                          \n"
        "1:                                                 \n"

        : [phwTarget] "+r" (phwTarget),
          [pwSrc] "+r" (pwSrc), [loopCnt] "+r"(loopCnt)
        : [scratch] "r" (scratch), [eight] "r" (8),
          [inv2pow5] "r" ( 1 << (15 - 5)) //  /* 1/(2^5) in Q.15 */
        : "q0", "q1", "q2", "q3",
          "q4", "q5", "q6", "q7",
          "memory" );

#endif
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_rgb565_with_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);
        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        vSrcOpa = vmulq_n_u16(vSrcOpa, hwOpacity)  >> 8;
        vSrcOpa = vpselq(v256, vSrcOpa, vcmpeqq_n_u16(vSrcOpa, 255));

        vst1q_p(phwTarget,
            __arm_2d_unpack_and_blend_rg565(phwTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrc += 8;
        phwTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_rgb565_with_src_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);
        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_z_u16(pchSrcMsk, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity);

        vst1q_p(phwTarget,
            __arm_2d_unpack_and_blend_rg565(phwTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pchSrcMsk += 8;
        pwSrc += 8;
        phwTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_rgb565_with_src_mask(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount
)
{
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);
        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_z_u16(pchSrcMsk, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask);

        vst1q_p(phwTarget,
            __arm_2d_unpack_and_blend_rg565(phwTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pchSrcMsk += 8;
        pwSrc += 8;
        phwTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_rgb565_with_src_chn_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);
        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_gather_offset_z_u16((const uint8_t *)pwSrcMsk, vStride4Offs, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask_n_opa(vSrcOpa, vSrcMask, hwOpacity);

        vst1q_p(phwTarget,
            __arm_2d_unpack_and_blend_rg565(phwTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrcMsk += 8;
        pwSrc += 8;
        phwTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_ccca8888_blend_to_rgb565_with_src_chn_mask(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount
)
{
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);

    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);
        uint16x8_t      vSrcOpa, vSrcG, vSrcR, vSrcB;

        __arm_2d_ccca8888_unpack_u16((const uint8_t *)pwSrc, &vSrcOpa, &vSrcR, &vSrcG, &vSrcB);

        uint16x8_t vSrcMask = vldrbq_gather_offset_z_u16((const uint8_t *)pwSrcMsk, vStride4Offs, tailPred);
        vSrcOpa = __arm_2d_scale_alpha_mask(vSrcOpa, vSrcMask);

        vst1q_p(phwTarget,
            __arm_2d_unpack_and_blend_rg565(phwTarget, vSrcOpa, vSrcR, vSrcG, vSrcB),
            tailPred);

        pwSrcMsk += 8;
        pwSrc += 8;
        phwTarget += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}


/*---------------------------------------------------------------------------*
 * GRAY8 pixel blend                                                         *
 *---------------------------------------------------------------------------*/

__STATIC_FORCEINLINE 
void __arm_2d_helium_gray8_blend_with_opacity(
    uint8_t *__RESTRICT pchSrc,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    uint16x8_t vHwAlpha = vdupq_n_u16(hwOpacity);
    vHwAlpha = v256 - vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));

    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16(pchSrc, tailPred);
        uint16x8_t      vtrgt = vldrbq_z_u16(pchTarget, tailPred);

        vstrbq_p_u16(pchTarget,
            __arm_2d_vblend_gray8(vtrgt, vSrc, vHwAlpha),
            tailPred);

        pchTarget += 8;
        pchSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_gray8_blend_with_src_mask_and_opacity(
    uint8_t *__RESTRICT pchSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16(pchSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_z_u16(pchSrcMsk, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - (vmulq(vHwAlpha, hwOpacity) >> 8);

        uint16x8_t      vtrgt = vldrbq_z_u16(pchTarget, tailPred);

        vstrbq_p_u16(pchTarget,
            __arm_2d_vblend_gray8(vtrgt, vSrc, vHwAlpha),
            tailPred);

        pchSrcMsk += 8;
        pchTarget += 8;
        pchSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_gray8_blend_with_src_mask(
    uint8_t *__RESTRICT pchSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16(pchSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_z_u16(pchSrcMsk, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - vHwAlpha;

        uint16x8_t      vtrgt = vldrbq_z_u16(pchTarget, tailPred);

        vstrbq_p_u16(pchTarget,
            __arm_2d_vblend_gray8(vtrgt, vSrc, vHwAlpha),
            tailPred);

        pchSrcMsk += 8;
        pchTarget += 8;
        pchSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_gray8_blend_with_src_chn_mask_and_opacity(
    uint8_t *__RESTRICT pchSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16(pchSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pwSrcMsk, vStride4Offs, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - (vmulq(vHwAlpha, hwOpacity) >> 8);

        uint16x8_t      vtrgt = vldrbq_z_u16(pchTarget, tailPred);

        vstrbq_p_u16(pchTarget,
            __arm_2d_vblend_gray8(vtrgt, vSrc, vHwAlpha),
            tailPred);

        pwSrcMsk += 8;
        pchTarget += 8;
        pchSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_gray8_blend_with_src_chn_mask(
    uint8_t *__RESTRICT pchSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint8_t *__RESTRICT pchTarget,
    int_fast16_t iBlockCount
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16(pchSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pwSrcMsk, vStride4Offs, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - vHwAlpha;

        uint16x8_t      vtrgt = vldrbq_z_u16(pchTarget, tailPred);

        vstrbq_p_u16(pchTarget,
            __arm_2d_vblend_gray8(vtrgt, vSrc, vHwAlpha),
            tailPred);

        pwSrcMsk += 8;
        pchTarget += 8;
        pchSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

/*---------------------------------------------------------------------------*
 * CCCN888 pixel blend.                                                      *
 *---------------------------------------------------------------------------*/

__STATIC_FORCEINLINE 
void __arm_2d_helium_cccn888_blend_with_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    uint16x8_t vHwAlpha = vdupq_n_u16(hwOpacity);
    vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));

    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);
        uint16x8_t      vSrc = vldrbq_z_u16((uint8_t*)pwSrc, tailPred);

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vHwAlpha, vSrc),
            tailPred);

        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_cccn888_blend_with_src_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{

    /* offset to replicate 2 masks accross the 4 channels */
    const uint16x8_t  offset = { 0, 0, 0, 0, 1, 1, 1, 1 };
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16((uint8_t*)pwSrc, tailPred);

        /*
            replicate alpha, but alpha location = 0 (zeroing) so that transparency = 0x100
            and leaves target 0 unchanged
            vSrcOpa = | opa0 | opa0 | opa0 |  0  | opa1 | opa1 | opa1 |  0  |
            */
        uint16x8_t vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pchSrcMsk, offset, 0x3f3f & tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha = vmulq(vHwAlpha, hwOpacity) >> 8;

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vHwAlpha, vSrc),
            tailPred);

        pchSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);

}

__STATIC_FORCEINLINE 
void __arm_2d_helium_cccn888_blend_with_src_mask(
    uint32_t *__RESTRICT pwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount
)
{

    /* offset to replicate 2 masks accross the 4 channels */
    const uint16x8_t  offset = { 0, 0, 0, 0, 1, 1, 1, 1 };
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16((uint8_t*)pwSrc, tailPred);

        /*
            replicate alpha, but alpha location = 0 (zeroing) so that transparency = 0x100
            and leaves target 0 unchanged
            vSrcOpa = | opa0 | opa0 | opa0 |  0  | opa1 | opa1 | opa1 |  0  |
            */
        uint16x8_t vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pchSrcMsk, offset, 0x3f3f & tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vHwAlpha, vSrc),
            tailPred);

        pchSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_cccn888_blend_with_src_chn_mask_and_opacity(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{

    /* offset to replicate 2 masks accross the 4 channels */
    const uint16x8_t  offset = { 0, 0, 0, 0, 4, 4, 4, 4 };
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16((uint8_t*)pwSrc, tailPred);

        /*
            replicate alpha, but alpha location = 0 (zeroing) so that transparency = 0x100
            and leaves target 0 unchanged
            vSrcOpa = | opa0 | opa0 | opa0 |  0  | opa1 | opa1 | opa1 |  0  |
            */
        uint16x8_t vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pwSrcMsk, offset, 0x3f3f & tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha = vmulq(vHwAlpha, hwOpacity) >> 8;

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vHwAlpha, vSrc),
            tailPred);

        pwSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_cccn888_blend_with_src_chn_mask(
    uint32_t *__RESTRICT pwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint32_t *__RESTRICT pwTarget,
    int_fast16_t iBlockCount
)
{

    /* offset to replicate 2 masks accross the 4 channels */
    const uint16x8_t  offset = { 0, 0, 0, 0, 4, 4, 4, 4 };
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp64q(iBlockCount);

        uint16x8_t      vSrc = vldrbq_z_u16((uint8_t*)pwSrc, tailPred);

        /*
            replicate alpha, but alpha location = 0 (zeroing) so that transparency = 0x100
            and leaves target 0 unchanged
            vSrcOpa = | opa0 | opa0 | opa0 |  0  | opa1 | opa1 | opa1 |  0  |
            */
        uint16x8_t vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pwSrcMsk, offset, 0x3f3f & tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));

        vstrbq_p_u16((const uint8_t *)pwTarget,
            __arm_2d_unpack_and_blend_cccn888((const uint8_t *)pwTarget, vHwAlpha, vSrc),
            tailPred);

        pwSrcMsk += 2;
        pwSrc += 2;
        pwTarget += 2;
        iBlockCount -= 2;
    } while (iBlockCount > 0);
}

__STATIC_INLINE
void __arm_2d_helium_cccn888_8pix_fill_colour_with_mask_p(  uint32_t wColour,
                                                            uint32_t * pwTarget,
                                                            uint16x8_t vHwPixelAlpha,
                                                            mve_pred16_t predTail,
                                                            mve_pred16_t predGlb)
{
    /* predicate accumulator */
    /* tracks all predications conditions for selecting final */
    /* averaged pixed / target pixel */
    //mve_pred16_t    predGlb = 0;

    uint16x8_t      vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;
    arm_2d_color_bgra8888_t tSrcPix = {.tValue = wColour, };
    uint16x8_t      vTargetR, vTargetG, vTargetB;
    uint16x8_t      vBlendedR, vBlendedG, vBlendedB;

    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem((const uint8_t *) pwTarget, &vTargetR, &vTargetG, &vTargetB);



    /* merge vector with expanded Mask colour */
    vBlendedR = vqaddq(vTargetR * vhwTransparency, vmulq_n_u16(vHwPixelAlpha, tSrcPix.u8R));
    vBlendedR = vBlendedR >> 8;

    vBlendedG = vqaddq(vTargetG * vhwTransparency, vmulq_n_u16(vHwPixelAlpha, tSrcPix.u8G));
    vBlendedG = vBlendedG >> 8;

    vBlendedB = vqaddq(vTargetB * vhwTransparency, vmulq_n_u16(vHwPixelAlpha, tSrcPix.u8B));
    vBlendedB = vBlendedB >> 8;

    /* select between target pixel, averaged pixed */
    vTargetR = vpselq_u16(vBlendedR, vTargetR, predGlb);
    vTargetG = vpselq_u16(vBlendedG, vTargetG, predGlb);
    vTargetB = vpselq_u16(vBlendedB, vTargetB, predGlb);

    /* pack */
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget, sg,
                                vminq(vTargetB, vdupq_n_u16(255)), predTail);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget + 1, sg,
                                vminq(vTargetG, vdupq_n_u16(255)), predTail);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget + 2, sg,
                                vminq(vTargetR, vdupq_n_u16(255)), predTail);
}

__STATIC_INLINE
void __arm_2d_helium_cccn888_8pix_fill_colour_with_mask(uint32_t wColour,
                                                        uint32_t * pwTarget,
                                                        uint16x8_t vHwPixelAlpha)
{
    uint16x8_t      vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;
    arm_2d_color_bgra8888_t tSrcPix = {.tValue = wColour, };
    uint16x8_t      vTargetR, vTargetG, vTargetB;
    uint16x8_t      vBlendedR, vBlendedG, vBlendedB;

    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem((const uint8_t *) pwTarget, 
                                    &vTargetR, 
                                    &vTargetG, 
                                    &vTargetB);

    /* merge vector with expanded Mask colour */
    vBlendedR = vqaddq(vTargetR * vhwTransparency, 
                        vmulq_n_u16(vHwPixelAlpha, tSrcPix.u8R));
    vBlendedR = vBlendedR >> 8;

    vBlendedG = vqaddq(vTargetG * vhwTransparency, 
                        vmulq_n_u16(vHwPixelAlpha, tSrcPix.u8G));
    vBlendedG = vBlendedG >> 8;

    vBlendedB = vqaddq(vTargetB * vhwTransparency, 
                        vmulq_n_u16(vHwPixelAlpha, tSrcPix.u8B));
    vBlendedB = vBlendedB >> 8;

    /* pack */
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget, sg,
                                vminq(vBlendedB, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget + 1, sg,
                                vminq(vBlendedG, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget + 2, sg,
                                vminq(vBlendedR, vdupq_n_u16(255)));
}

__STATIC_INLINE
void __arm_2d_helium_cccn888_blend_8pix_with_mask( uint32_t * pwSource,
                                                   uint32_t * pwTarget,
                                                   uint16x8_t vHwPixelAlpha)
{
    uint16x8_t      vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;
    
    uint16x8_t      vBlendedR, vBlendedG, vBlendedB;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem((const uint8_t *) pwSource, 
                                    &vBlendedR, 
                                    &vBlendedG, 
                                    &vBlendedB);

    uint16x8_t      vTargetR, vTargetG, vTargetB;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem((const uint8_t *) pwTarget, 
                                    &vTargetR, 
                                    &vTargetG, 
                                    &vTargetB);

    /* merge vector with expanded Mask colour */
    vBlendedR = vqaddq(vTargetR * vhwTransparency, 
                        vmulq_u16(vHwPixelAlpha, vBlendedR));
    vBlendedR = vBlendedR >> 8;

    vBlendedG = vqaddq(vTargetG * vhwTransparency, 
                        vmulq_u16(vHwPixelAlpha, vBlendedG));
    vBlendedG = vBlendedG >> 8;

    vBlendedB = vqaddq(vTargetB * vhwTransparency, 
                        vmulq_u16(vHwPixelAlpha, vBlendedB));
    vBlendedB = vBlendedB >> 8;

    /* pack */
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget, sg,
                                vminq(vBlendedB, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget + 1, sg,
                                vminq(vBlendedG, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget + 2, sg,
                                vminq(vBlendedR, vdupq_n_u16(255)));
}

__STATIC_INLINE
void __arm_2d_helium_cccn888_blend_8pix_with_mask_p(uint32_t * pwSource,
                                                    uint32_t * pwTarget,
                                                    uint16x8_t vHwPixelAlpha,
                                                    mve_pred16_t predTail,
                                                    mve_pred16_t predGlb)
{
    /* predicate accumulator */
    /* tracks all predications conditions for selecting final */
    /* averaged pixed / target pixel */
    //mve_pred16_t    predGlb = 0;

    uint16x8_t      vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;
    uint16x8_t      vBlendedR, vBlendedG, vBlendedB;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem_z(  (const uint8_t *)pwSource, 
                                        &vBlendedR, 
                                        &vBlendedG, 
                                        &vBlendedB,
                                        predTail);

    uint16x8_t      vTargetR, vTargetG, vTargetB;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem_z(  (const uint8_t *)pwTarget, 
                                        &vTargetR, 
                                        &vTargetG, 
                                        &vTargetB,
                                        predTail);

    /* merge vector with expanded Mask colour */
    vBlendedR = vqaddq(vTargetR * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedR));
    vBlendedR = vBlendedR >> 8;

    vBlendedG = vqaddq(vTargetG * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedG));
    vBlendedG = vBlendedG >> 8;

    vBlendedB = vqaddq(vTargetB * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedB));
    vBlendedB = vBlendedB >> 8;

    /* select between target pixel, averaged pixed */
    vTargetR = vpselq_u16(vBlendedR, vTargetR, predGlb);
    vTargetG = vpselq_u16(vBlendedG, vTargetG, predGlb);
    vTargetB = vpselq_u16(vBlendedB, vTargetB, predGlb);

    /* pack */
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget, sg,
                                vminq(vTargetB, vdupq_n_u16(255)), predTail);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget + 1, sg,
                                vminq(vTargetG, vdupq_n_u16(255)), predTail);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget + 2, sg,
                                vminq(vTargetR, vdupq_n_u16(255)), predTail);
}

__STATIC_INLINE
void __arm_2d_helium_ccca8888_blend_8pix_to_gray8_with_mask_p(
                                                    uint32_t * pwSource,
                                                    uint8_t * pchTarget,
                                                    uint16x8_t vHwPixelAlpha,
                                                    mve_pred16_t predTail,
                                                    mve_pred16_t predGlb)
{
    uint16x8_t vSourceR, vSourceG, vSourceB, vSourceA;
    __arm_2d_unpack_ccca8888_from_mem_z(pwSource, 
                                        &vSourceR,
                                        &vSourceG,
                                        &vSourceB, 
                                        &vSourceA,
                                        predTail);
    /* mix vSourceA and vHwPixelAlpha */
    vHwPixelAlpha = __arm_2d_scale_alpha_mask(vSourceA, vHwPixelAlpha);

    
    /* uint16_t tGrayScale = (ptRGB->R * 77 + ptRGB->G * 151 + ptRGB->B * 28) >> 8; */
    uint16x8_t vSource = (vSourceR * 77 + vSourceG * 151 + vSourceB * 28) >> 8;

    /* blending */
    uint16x8_t  vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;

    uint16x8_t  vTarget = vldrbq_z_u16(pchTarget, predTail);
    uint16x8_t  vBlended =
        vrshrq_n_u16(   vqaddq( vHwPixelAlpha * vSource, 
                                vTarget * vhwTransparency),
                        8);

    /* select between target pixel, averaged pixed */
    vTarget = vpselq_u16(vBlended, vTarget, predGlb);

    vstrbq_p_u16(pchTarget, vTarget, predTail);
}

__STATIC_INLINE
void __arm_2d_helium_ccca8888_blend_8pix_to_gray8_with_mask(
                                                    uint32_t * pwSource,
                                                    uint8_t * pchTarget,
                                                    uint16x8_t vHwPixelAlpha)
{
    uint16x8_t vSourceR, vSourceG, vSourceB, vSourceA;
    __arm_2d_unpack_ccca8888_from_mem(  pwSource, 
                                        &vSourceR,
                                        &vSourceG,
                                        &vSourceB, 
                                        &vSourceA);
    /* mix vSourceA and vHwPixelAlpha */
    vHwPixelAlpha = __arm_2d_scale_alpha_mask(vSourceA, vHwPixelAlpha);

    /* uint16_t tGrayScale = (ptRGB->R * 77 + ptRGB->G * 151 + ptRGB->B * 28) >> 8; */
    uint16x8_t vSource = (vSourceR * 77 + vSourceG * 151 + vSourceB * 28) >> 8;

    /* blending */
    uint16x8_t  vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;

    uint16x8_t  vTarget = vldrbq_u16(pchTarget);
    uint16x8_t  vBlended =
        vrshrq_n_u16(   vqaddq( vHwPixelAlpha * vSource, 
                                vTarget * vhwTransparency),
                        8);

    vstrbq_u16(pchTarget, vBlended);
}



__STATIC_INLINE
void __arm_2d_helium_ccca8888_blend_8pix_to_rgb565_with_mask_p(
                                                    uint32_t * pwSource,
                                                    uint16_t * phwTarget,
                                                    uint16x8_t vHwPixelAlpha,
                                                    mve_pred16_t predTail,
                                                    mve_pred16_t predGlb)
{
    uint16x8_t vSourceR, vSourceG, vSourceB, vSourceA;
    __arm_2d_unpack_ccca8888_from_mem_z(pwSource, 
                                        &vSourceR,
                                        &vSourceG,
                                        &vSourceB, 
                                        &vSourceA,
                                        predTail);

    /* mix vSourceA and vHwPixelAlpha */
    vHwPixelAlpha = __arm_2d_scale_alpha_mask(vSourceA, vHwPixelAlpha);
    uint16x8_t vTrans = vdupq_n_u16(256) - vHwPixelAlpha;

    uint16x8_t  vTarget = vld1q_z_u16(phwTarget, predTail);
    uint16x8_t vTargetR, vTargetG, vTargetB;
    __arm_2d_rgb565_unpack_single_vec(vTarget, &vTargetR, &vTargetG, &vTargetB);

    vSourceR = vrshrq_n_u16(vqaddq(vHwPixelAlpha * vSourceR, vTargetR * vTrans),8);
    vSourceG = vrshrq_n_u16(vqaddq(vHwPixelAlpha * vSourceG, vTargetG * vTrans),8);
    vSourceB = vrshrq_n_u16(vqaddq(vHwPixelAlpha * vSourceB, vTargetB * vTrans),8);

    vst1q_p(phwTarget, 
            vpselq_u16( __arm_2d_rgb565_pack_single_vec(vSourceR, vSourceG, vSourceB), 
                        vTarget, 
                        predGlb), 
            predTail);
}

__STATIC_INLINE
void __arm_2d_helium_ccca8888_blend_8pix_to_rgb565_with_mask(
                                                    uint32_t * pwSource,
                                                    uint16_t * phwTarget,
                                                    uint16x8_t vHwPixelAlpha)
{
    uint16x8_t vSourceR, vSourceG, vSourceB, vSourceA;
    __arm_2d_unpack_ccca8888_from_mem(  pwSource, 
                                        &vSourceR,
                                        &vSourceG,
                                        &vSourceB, 
                                        &vSourceA);

    /* mix vSourceA and vHwPixelAlpha */
    vHwPixelAlpha = __arm_2d_scale_alpha_mask(vSourceA, vHwPixelAlpha);
    uint16x8_t vTrans = vdupq_n_u16(256) - vHwPixelAlpha;

    uint16x8_t  vTarget = vld1q_u16(phwTarget);
    uint16x8_t vTargetR, vTargetG, vTargetB;
    __arm_2d_rgb565_unpack_single_vec(vTarget, &vTargetR, &vTargetG, &vTargetB);

    vSourceR = vrshrq_n_u16(vqaddq(vHwPixelAlpha * vSourceR, vTargetR * vTrans),8);
    vSourceG = vrshrq_n_u16(vqaddq(vHwPixelAlpha * vSourceG, vTargetG * vTrans),8);
    vSourceB = vrshrq_n_u16(vqaddq(vHwPixelAlpha * vSourceB, vTargetB * vTrans),8);

    vst1q(  phwTarget, 
            __arm_2d_rgb565_pack_single_vec(vSourceR, vSourceG, vSourceB));
}


__STATIC_INLINE
void __arm_2d_helium_ccca8888_blend_8pix_to_cccn888_with_mask_p(
                                                    uint32_t * pwSource,
                                                    uint32_t * pwTarget,
                                                    uint16x8_t vHwPixelAlpha,
                                                    mve_pred16_t predTail,
                                                    mve_pred16_t predGlb)
{
    /* predicate accumulator */
    /* tracks all predications conditions for selecting final */
    /* averaged pixed / target pixel */
    //mve_pred16_t    predGlb = 0;

    uint16x8_t      vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;
    uint16x8_t      vBlendedR, vBlendedG, vBlendedB, vBlendedA;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_ccca8888_from_mem_z( pwSource, 
                                        &vBlendedR, 
                                        &vBlendedG, 
                                        &vBlendedB,
                                        &vBlendedA,
                                        predTail);

    uint16x8_t      vTargetR, vTargetG, vTargetB;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem_z(  (const uint8_t *)pwTarget, 
                                        &vTargetR, 
                                        &vTargetG, 
                                        &vTargetB,
                                        predTail);

    vHwPixelAlpha = __arm_2d_scale_alpha_mask(vBlendedA, vHwPixelAlpha);

    /* merge vector with expanded Mask colour */
    vBlendedR = vqaddq(vTargetR * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedR));
    vBlendedR = vBlendedR >> 8;

    vBlendedG = vqaddq(vTargetG * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedG));
    vBlendedG = vBlendedG >> 8;

    vBlendedB = vqaddq(vTargetB * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedB));
    vBlendedB = vBlendedB >> 8;

    /* select between target pixel, averaged pixed */
    vTargetR = vpselq_u16(vBlendedR, vTargetR, predGlb);
    vTargetG = vpselq_u16(vBlendedG, vTargetG, predGlb);
    vTargetB = vpselq_u16(vBlendedB, vTargetB, predGlb);

    /* pack */
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget, sg,
                                vminq(vTargetB, vdupq_n_u16(255)), predTail);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget + 1, sg,
                                vminq(vTargetG, vdupq_n_u16(255)), predTail);
    vstrbq_scatter_offset_p_u16((uint8_t *) pwTarget + 2, sg,
                                vminq(vTargetR, vdupq_n_u16(255)), predTail);
}


__STATIC_INLINE
void __arm_2d_helium_ccca8888_blend_8pix_to_cccn888_with_mask(
                                                    uint32_t * pwSource,
                                                    uint32_t * pwTarget,
                                                    uint16x8_t vHwPixelAlpha)
{
    /* predicate accumulator */
    /* tracks all predications conditions for selecting final */
    /* averaged pixed / target pixel */
    //mve_pred16_t    predGlb = 0;

    uint16x8_t      vhwTransparency = vdupq_n_u16(256) - vHwPixelAlpha;
    uint16x8_t      vBlendedR, vBlendedG, vBlendedB, vBlendedA;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_ccca8888_from_mem( pwSource, 
                                        &vBlendedR, 
                                        &vBlendedG, 
                                        &vBlendedB,
                                        &vBlendedA);

    uint16x8_t      vTargetR, vTargetG, vTargetB;
    /* get vectors of 8 x R, G, B pix */
    __arm_2d_unpack_cccn888_from_mem(    (const uint8_t *)pwTarget, 
                                        &vTargetR, 
                                        &vTargetG, 
                                        &vTargetB);

    vHwPixelAlpha = __arm_2d_scale_alpha_mask(vBlendedA, vHwPixelAlpha);

    /* merge vector with expanded Mask colour */
    vBlendedR = vqaddq(vTargetR * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedR));
    vBlendedR = vBlendedR >> 8;

    vBlendedG = vqaddq(vTargetG * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedG));
    vBlendedG = vBlendedG >> 8;

    vBlendedB = vqaddq(vTargetB * vhwTransparency, vmulq_u16(vHwPixelAlpha, vBlendedB));
    vBlendedB = vBlendedB >> 8;

    /* pack */
    uint16x8_t      sg = vidupq_n_u16(0, 4);
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget, sg,
                                vminq(vBlendedB, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget + 1, sg,
                                vminq(vBlendedG, vdupq_n_u16(255)));
    vstrbq_scatter_offset_u16((uint8_t *) pwTarget + 2, sg,
                                vminq(vBlendedR, vdupq_n_u16(255)));
}


/*---------------------------------------------------------------------------*
 * RGB565 pixel blend                                                        *
 *---------------------------------------------------------------------------*/

__STATIC_FORCEINLINE 
void __arm_2d_helium_rgb565_blend_with_opacity(
    uint16_t *__RESTRICT phwSrc,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    uint16x8_t vHwAlpha = vdupq_n_u16(hwOpacity);
    vHwAlpha = v256 - vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));

    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrhq_z_u16(phwSrc, tailPred);

        uint16x8_t  vtrgt = vldrhq_z_u16(phwTarget, tailPred);

        vstrhq_p_u16(   phwTarget,
                        __arm_2d_vblend_rgb565(vtrgt, vSrc, vHwAlpha),
                        tailPred);

        phwTarget += 8;
        phwSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_rgb565_blend_with_src_mask_and_opacity(
    uint16_t *__RESTRICT phwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrhq_z_u16(phwSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_z_u16(pchSrcMsk, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - (vmulq(vHwAlpha, hwOpacity) >> 8);

        uint16x8_t  vtrgt = vldrhq_z_u16(phwTarget, tailPred);

        vstrhq_p_u16(   phwTarget,
                        __arm_2d_vblend_rgb565(vtrgt, vSrc, vHwAlpha),
                        tailPred);

        pchSrcMsk += 8;
        phwTarget += 8;
        phwSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_rgb565_blend_with_src_mask(
    uint16_t *__RESTRICT phwSrc,
    uint8_t *__RESTRICT pchSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrhq_z_u16(phwSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_z_u16(pchSrcMsk, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - vHwAlpha;

        uint16x8_t  vtrgt = vldrhq_z_u16(phwTarget, tailPred);

        vstrhq_p_u16(   phwTarget,
                        __arm_2d_vblend_rgb565(vtrgt, vSrc, vHwAlpha),
                        tailPred);

        pchSrcMsk += 8;
        phwTarget += 8;
        phwSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_rgb565_blend_with_src_chn_mask_and_opacity(
    uint16_t *__RESTRICT phwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount,
    uint16_t hwOpacity
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrhq_z_u16(phwSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pwSrcMsk, vStride4Offs, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - (vmulq(vHwAlpha, hwOpacity) >> 8);

        uint16x8_t  vtrgt = vldrhq_z_u16(phwTarget, tailPred);

        vstrhq_p_u16(   phwTarget,
                        __arm_2d_vblend_rgb565(vtrgt, vSrc, vHwAlpha),
                        tailPred);

        pwSrcMsk += 8;
        phwTarget += 8;
        phwSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

__STATIC_FORCEINLINE 
void __arm_2d_helium_rgb565_blend_with_src_chn_mask(
    uint16_t *__RESTRICT phwSrc,
    uint32_t *__RESTRICT pwSrcMsk,
    uint16_t *__RESTRICT phwTarget,
    int_fast16_t iBlockCount
)
{
    const uint16x8_t v256 = vdupq_n_u16(256);
    const uint16x8_t vStride4Offs = vidupq_n_u16(0, 4);
    do {
        mve_pred16_t    tailPred = vctp16q(iBlockCount);

        uint16x8_t      vSrc = vldrhq_z_u16(phwSrc, tailPred);
        uint16x8_t      vHwAlpha = vldrbq_gather_offset_z_u16((uint8_t*)pwSrcMsk, vStride4Offs, tailPred);

        vHwAlpha = vpselq(v256, vHwAlpha, vcmpeqq_n_u16(vHwAlpha, 255));
        vHwAlpha=  v256 - vHwAlpha;

        uint16x8_t  vtrgt = vldrhq_z_u16(phwTarget, tailPred);

        vstrhq_p_u16(   phwTarget,
                        __arm_2d_vblend_rgb565(vtrgt, vSrc, vHwAlpha),
                        tailPred);

        pwSrcMsk += 8;
        phwTarget += 8;
        phwSrc += 8;
        iBlockCount -= 8;
    } while (iBlockCount > 0);
}

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_transform_helium.c"

//#define __ARM_2D_COMPILATION_UNIT
//#include "__arm_2d_tile_4xssaa_transform_src_mask_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_conversion_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_tile_copy_with_source_mask_and_opacity_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_tile_fill_with_source_mask_and_opacity_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_tile_fill_with_opacity_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_fill_colour_with_horizontal_line_mask_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_fill_colour_with_vertical_line_mask_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_fill_colour_with_mask_and_mirroring_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_fill_colour_with_masks_and_mirroring_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_filter_iir_blur_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_filter_reverse_colour_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_fill_colour_with_alpha_gradient_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_ccca8888_transform_helium.c"

#define __ARM_2D_COMPILATION_UNIT
#include "__arm_2d_tile_copy_with_transformed_mask_source_mask_and_target_mask_helium.c"


/*----------------------------------------------------------------------------*
 * Helper
 *----------------------------------------------------------------------------*/

__OVERRIDE_WEAK
void __MVE_WRAPPER(arm_2d_helper_swap_rgb16)(uint16_t *phwBuffer, uint32_t wCount)
{
    if (0 == wCount) {
        return ;
    }

    // aligned (2)
    assert((((uintptr_t) phwBuffer) & 0x01) == 0);

    // src not aligned to 32-bit
    // (helium supports unaligned vector load & store but with extra cycle penalty)
    if ((((uintptr_t) phwBuffer) & 0x03) == 0x02) {
        // handle the leading pixel
        uint32_t wTemp = *phwBuffer;
        *phwBuffer++ = (uint16_t)__rev16(wTemp);
        wCount--;
    }

#ifdef USE_MVE_INTRINSICS
        do {
            mve_pred16_t    tailPred = vctp16q(wCount);
            uint16x8_t      rgb16vec = vld1q_z(phwBuffer, tailPred);

            rgb16vec = (uint16x8_t)vrev16q_m_u8(rgb16vec, rgb16vec, tailPred);

            vst1q_p(phwBuffer , rgb16vec , tailPred);

            phwBuffer += 8;
            wCount -= 8;
        }
        while ((int32_t)wCount > 0);

#else
    __asm volatile(
            ".p2align 2                                             \n"
            "   wlstp.16                lr, %[wCount], 1f           \n"
            "2:                                                     \n"

            "   vldrh.u16               q0, [%[phwBuffer]]          \n"
            "   vrev16.8                q0, q0                      \n"
            "   vstrh.u16               q0, [%[phwBuffer]], #16     \n"
            "   letp                    lr, 2b                      \n"
            "1:                                                     \n"

            : [phwBuffer] "+r"(phwBuffer)
            : [wCount] "r" (wCount)
            :"q0", "lr", "memory");
#endif
}



/*----------------------------------------------------------------------------*
 * Specialized Copy Routines                                                  *
 *----------------------------------------------------------------------------*/


static
void __arm_copy_16_mve_narrow(  uint16_t *phwSource,
                                                int16_t iSourceStride,
                                                uint16_t *phwTarget,
                                                int16_t iTargetStride,
                                                arm_2d_size_t *ptCopySize)
{
#ifdef USE_MVE_INTRINSICS
    for (int32_t x = 0; x < ptCopySize->iWidth; x++) {
        uint16x8_t      srcStr = vidupq_u16((uint32_t) 0, 1);
        uint16x8_t      dstStr = vidupq_u16((uint32_t) 0, 1);

        srcStr = srcStr * iSourceStride;
        dstStr = dstStr * iTargetStride;

        for (int32_t y = 0; y < ptCopySize->iHeight / 8; y++) {
            uint16x8_t      in = vldrhq_gather_shifted_offset_u16(phwSource, srcStr);
            srcStr = vaddq_n_u16(srcStr, (8 * iSourceStride));

            vstrhq_scatter_shifted_offset_u16(phwTarget, dstStr, in);
            dstStr = vaddq_n_u16(dstStr, (8 * iTargetStride));
        }

        phwSource++;
        phwTarget++;
    }
#else
    __asm volatile(
        "   clrm                {r2, r4}                               \n"
        "   vidup.u16           q0, r2, #1                             \n"
        "   vmul.i16            q2, q0, %[iSourceStride]               \n"
        "   vidup.u16           q1, r4, #1                             \n"
        "   vmul.i16            q3, q1, %[iTargetStride]               \n"

        "3:                                                            \n"
        /* outer loop, iterates over columns */
        /* size = ptCopySize->iWidth */
        "   vmov                q0, q2                                 \n"
        "   vmov                q1, q3                                 \n"

        /* inner loop, iterates over rows (size = ptCopySize->iHeight) */
        "   wlstp.16            lr, %[iHeight], 1f                     \n"
        ".p2align 2                                                    \n"
        "2:                                                            \n"
        "   vldrh.u16           q4, [%[phwSource], q0, uxtw #1]        \n"
        "   vadd.i16            q0, q0, %[iSourceStridex8]             \n"
        "   vstrh.16            q4, [%[phwTarget], q1, uxtw #1]        \n"
        "   vadd.i16            q1, q1, %[iTargetStridex8]             \n"
        "   letp                lr, 2b                                 \n"
        "1:                                                            \n"

        "   adds               %[phwSource], #2                        \n"
        "   adds               %[phwTarget], #2                        \n"
        "   subs                %[iWidth], #1                          \n"
        "   bne                 3b                                     \n"

        : [phwTarget] "+r"(phwTarget),  [phwSource] "+r"(phwSource)
        : [iHeight] "r"(ptCopySize->iHeight), [iWidth] "r" (ptCopySize->iWidth),
          [iSourceStride] "r" (iSourceStride),[iSourceStridex8] "r" (iSourceStride*8),
          [iTargetStride] "r" (iTargetStride),[iTargetStridex8] "r" (iTargetStride*8)
        : "r2", "r4", "q0", "q1", "q2", "q3", "q4", "memory", "r14", "cc");
#endif
}

static
void __arm_copy_32_mve_narrow(   uint32_t *pwSource,
                                                int32_t iSourceStride,
                                                uint32_t *pwTarget,
                                                int32_t iTargetStride,
                                                arm_2d_size_t *ptCopySize)
{
#ifdef USE_MVE_INTRINSICS
    for (int_fast32_t x = 0; x < ptCopySize->iWidth; x++) {
        uint32x4_t      srcStr = vidupq_u32((uint32_t) 0, 1);
        uint32x4_t      dstStr = vidupq_u32((uint32_t) 0, 1);

        srcStr = srcStr * iSourceStride;
        dstStr = dstStr * iTargetStride;

        for (int_fast32_t y = 0; y < ptCopySize->iHeight / 4; y++) {
            uint32x4_t      in = vldrwq_gather_shifted_offset_u32(pwSource, srcStr);
            srcStr = vaddq_n_u32(srcStr, (4 * iSourceStride));

            vstrwq_scatter_shifted_offset_u32(pwTarget, dstStr, in);
            dstStr = vaddq_n_u32(dstStr, (4 * iTargetStride));
        }

        pwSource++;
        pwTarget++;
    }
#else
    __asm volatile(

        "   clrm                {r2, r4}                              \n"
        "   vidup.u32           q0, r2, #1                            \n"
        "   vmul.i32            q2, q0, %[iSourceStride]              \n"
        "   vidup.u32           q1, r4, #1                            \n"
        "   vmul.i32            q3, q1, %[iTargetStride]              \n"

        "3:                                                           \n"
        /* outer loop, iterates over columns */
        /* size = ptCopySize->iWidth */
        "   vmov                q0, q2                                \n"
        "   vmov                q1, q3                                \n"

        /* inner loop, iterates over rows (size = ptCopySize->iHeight) */
        "   wlstp.32            lr, %[iHeight], 1f                    \n"
        ".p2align 2                                                   \n"
        "2:                                                           \n"
        "   vldrw.u32           q4, [%[pwSource], q0, uxtw #2]        \n"
        "   vadd.i32            q0, q0, %[iSourceStridex4]            \n"
        "   vstrw.32            q4, [%[pwTarget], q1, uxtw #2]        \n"
        "   vadd.i32            q1, q1, %[iTargetStridex4]            \n"
        "   letp                lr, 2b                                \n"
        "1:                                                           \n"

        "   adds               %[pwSource], #4                        \n"
        "   adds               %[pwTarget], #4                        \n"
        "   subs                %[iWidth], #1                         \n"
        "   bne                 3b                                    \n"

        : [pwTarget] "+r"(pwTarget),  [pwSource] "+r"(pwSource)
        : [iHeight] "r"(ptCopySize->iHeight), [iWidth] "r" (ptCopySize->iWidth),
          [iSourceStride] "r" (iSourceStride),[iSourceStridex4] "r" (iSourceStride*4),
          [iTargetStride] "r" (iTargetStride),[iTargetStridex4] "r" (iTargetStride*4)
        : "r2", "r4", "q0", "q1", "q2", "q3", "q4", "memory", "r14", "cc");
#endif
}




__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb16_copy)(   uint16_t *phwSource,
                                int16_t iSourceStride,
                                uint16_t *phwTarget,
                                int16_t iTargetStride,
                                arm_2d_size_t *ptCopySize)
{
    /*
     * 16-bit Narrow copy case:
     * use column copy with scatter / gather
     */
    if(ptCopySize->iWidth <= 4) {
        __arm_copy_16_mve_narrow(phwSource,
                                    iSourceStride,
                                    phwTarget,
                                    iTargetStride,
                                    ptCopySize);

    } else  if((((uint32_t)phwSource & 3) == 0) && (((uint32_t)phwTarget & 3) == 0)
        && ((iSourceStride & 3) == 0) && ((iTargetStride & 3) ==0)) {
        /*
         * source / dst & strides are 64-bit aligned
         * use scalar LDRD/STRD, faster than back to back vector VLDR/VSTR on M55
         */
        __asm volatile(
            "3:                                                          \n"

            "   mov                 r0, %[phwSource]                     \n"
            "   mov                 r1, %[phwTarget]                     \n"

            /* scalar version faster (no DTCM bank conflict)*/
            "   wls                 lr, %[iWidth], 1f                    \n"
            ".p2align 2                                                  \n"
            "2:                                                          \n"
            "   ldrd                r2, r3, [r0], #8                     \n"
            "   strd                r2, r3, [r1], #8                     \n"
            "   le                  lr, 2b                               \n"
            "1:                                                          \n"
           // tail
            "   wls                 lr, %[iWidthTail], 1f                \n"
            ".p2align 2                                                  \n"
            "2:                                                          \n"
            "   ldrh                r2, [r0], #2                         \n"
            "   strh                r2, [r1], #2                         \n"
            "   le                  lr, 2b                               \n"
            "1:                                                          \n"

            "   add                 %[phwSource], %[iSourceStride]       \n"
            "   add                 %[phwTarget], %[iTargetStride]       \n"
            "   subs                %[iHeight], #1                       \n"
            "   bne                 3b                                   \n"

            : [phwTarget] "+r"(phwTarget),  [phwSource] "+r"(phwSource)
            : [iHeight] "r"(ptCopySize->iHeight), [iWidth] "r" (ptCopySize->iWidth/4),
              [iWidthTail] "r" (ptCopySize->iWidth & 3),
              [iSourceStride] "r" (iSourceStride*sizeof(uint16_t)),
              [iTargetStride] "r" (iTargetStride*sizeof(uint16_t))
            : "r0", "r1", "r2", "r3", "q0", "memory", "r14", "cc"
            );
        }
        else
        {
        /*
         * generic column major 16-bit 2D copy
         */
        int32_t iWidth = ptCopySize->iWidth;
        int32_t iHeight = ptCopySize->iHeight;

        __asm volatile(
            "   mov                 r2, %[iHeight]                  \n"
            "3:                                                     \n"

            "   mov                 r0, %[phwSource]                \n"
            "   mov                 r1, %[phwTarget]                \n"

            "   wlstp.16            lr, %[iWidth], 1f               \n"
            ".p2align 2                                             \n"
            "2:                                                     \n"
            "   vldrh.u16           q0, [r0], #16                   \n"
            "   vstrh.16            q0, [r1], #16                   \n"
            "   letp                lr, 2b                          \n"
            "1:                                                     \n"
            "   add                 %[phwSource], %[iSourceStride]  \n"
            "   add                 %[phwTarget], %[iTargetStride]  \n"
            "   subs                r2, #1                          \n"
            "   bne                 3b                              \n"

            : [phwTarget] "+r"(phwTarget),  [phwSource] "+r"(phwSource)
            : [iHeight] "r"(iHeight), [iWidth] "r" (iWidth),
              [iSourceStride] "r" (iSourceStride*sizeof(uint16_t)),
              [iTargetStride] "r" (iTargetStride*sizeof(uint16_t))
            : "r0", "r1", "r2", "q0", "memory", "r14", "cc");
    }
}

__OVERRIDE_WEAK
 void __MVE_WRAPPER( __arm_2d_impl_rgb32_copy)( uint32_t *pwSource,
                                int16_t iSourceStride,
                                uint32_t *pwTarget,
                                int16_t iTargetStride,
                                arm_2d_size_t *ptCopySize)
{
    if(ptCopySize->iWidth <= 2) {
        /*
         * 32-bit Narrow copy case:
         * use column copy with scatter / gather
         */
        __arm_copy_32_mve_narrow(pwSource,
                                    iSourceStride,
                                    pwTarget,
                                    iTargetStride,
                                    ptCopySize);

    } else  if((((uint32_t)pwSource & 3) == 0) && (((uint32_t)pwTarget & 3) == 0)
        && ((iSourceStride & 3) == 0) && ((iTargetStride & 3) ==0)) {
        /*
         * source / dst & strides are 64-bit aligned
         * use scalar LDRD/STRD, faster than back to back vector VLDR/VSTR on M55
         */
        __asm volatile(
            "3:                                                          \n"
            "   mov                 r0, %[pwSource]                      \n"
            "   mov                 r1, %[pwTarget]                      \n"

            /* scalar version faster (no DTCM bank conflict)*/
            "   wls                 lr, %[iWidth], 1f                    \n"
            ".p2align 2                                                  \n"
            "2:                                                          \n"
            "   ldrd                r2, r3, [r0], #8                     \n"
            "   strd                r2, r3, [r1], #8                     \n"
            "   le                  lr, 2b                               \n"
            "1:                                                          \n"
           // tail
            "   wls                 lr, %[iWidthTail], 1f                \n"
            ".p2align 2                                                  \n"
            "2:                                                          \n"
            "   ldr                 r2, [r0], #4                         \n"
            "   str                 r2, [r1], #4                         \n"
            "   le                  lr, 2b                               \n"
            "1:                                                          \n"

            "   add                 %[pwSource], %[iSourceStride]        \n"
            "   add                 %[pwTarget], %[iTargetStride]        \n"
            "   subs                %[iHeight], #1                       \n"
            "   bne                 3b                                   \n"

            : [pwTarget] "+r"(pwTarget),  [pwSource] "+r"(pwSource)
            : [iHeight] "r"(ptCopySize->iHeight), [iWidth] "r" (ptCopySize->iWidth/2),
              [iWidthTail] "r" (ptCopySize->iWidth & 1),
              [iSourceStride] "r" (iSourceStride*sizeof(uint32_t)),
              [iTargetStride] "r" (iTargetStride*sizeof(uint32_t))
            : "r0", "r1", "r2", "r3", "q0", "memory", "r14", "cc"
            );
        }
        else
        {
        /*
         * generic column major 32-bit 2D copy
         */
        __asm volatile(
            "3:                                                     \n"

            "   mov                 r0, %[pwSource]                 \n"
            "   mov                 r1, %[pwTarget]                 \n"

            "   wlstp.32            lr, %[iWidth], 1f               \n"
            ".p2align 2                                             \n"
            "2:                                                     \n"
            "   vldrw.32           q0, [r0], #16                    \n"
            "   vstrw.32            q0, [r1], #16                   \n"
            "   letp                lr, 2b                          \n"
            "1:                                                     \n"
            "   add                 %[pwSource], %[iSourceStride]   \n"
            "   add                 %[pwTarget], %[iTargetStride]   \n"
            "   subs                %[iHeight], #1                  \n"
            "   bne                 3b                              \n"

            : [pwTarget] "+r"(pwTarget),  [pwSource] "+r"(pwSource)
            : [iHeight] "r"(ptCopySize->iHeight), [iWidth] "r" (ptCopySize->iWidth),
              [iSourceStride] "r" (iSourceStride*sizeof(uint32_t)),
              [iTargetStride] "r" (iTargetStride*sizeof(uint32_t))
            : "r0", "r1", "q0", "memory", "r14", "cc");
        }
}

/*----------------------------------------------------------------------------*
 * alpha blending                                                             *
 *----------------------------------------------------------------------------*/

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_tile_copy_opacity)(uint8_t * __RESTRICT pSourceBase,
                                        int16_t iSourceStride,
                                        uint8_t * __RESTRICT pTargetBase,
                                        int16_t iTargetStride,
                                        arm_2d_size_t * __RESTRICT ptCopySize,
                                        uint_fast16_t hwRatio)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif
    uint16_t        hwRatioCompl = 256 - hwRatio;

    for (int_fast16_t y = 0; y < iHeight; y++) {

        const uint8_t *pSource = pSourceBase;
        uint8_t       *pTarget = pTargetBase;
        int32_t         blkCnt = iWidth;

#ifdef USE_MVE_INTRINSICS
        do {
            mve_pred16_t    tailPred = vctp16q(blkCnt);
            uint16x8_t      vecTgt = vldrbq_z_u16(pTarget, tailPred);
            uint16x8_t      vecSrc = vldrbq_z_u16(pSource, tailPred);

            vecTgt = vmulq_x(vecTgt, hwRatioCompl, tailPred);
            vecTgt = vmlaq_m(vecTgt, vecSrc, (uint16_t)hwRatio, tailPred);
            vecTgt  = vecTgt  >> 8;

            vstrbq_p_u16(pTarget , vecTgt , tailPred);

            pSource += 8;
            pTarget += 8;
            blkCnt -= 8;
        }
        while (blkCnt > 0);

#else
        __asm volatile(
            "   vldrb.u16               q0, [%[pTarget]]             \n"
            ".p2align 2                                              \n"
            "   wls                     lr, %[loopCnt], 1f           \n"
            "2:                                                      \n"
            "   vmul.u16                q0, q0, %[hwRatioCompl]      \n"
            "   vldrb.u16               q1, [%[pSource]], #8         \n"
            "   vmla.s16                q0, q1, %[hwRatio]           \n"
            "   vldrb.u16               q2, [%[pTarget], #8]         \n"
            "   vshr.u16                q0, q0, #8                   \n"
            "   vstrb.16                q0, [%[pTarget]], #8         \n"
            "   vmul.u16                q2, q2, %[hwRatioCompl]      \n"
            "   vldrb.u16               q1, [%[pSource]], #8         \n"
            "   vmla.s16                q2, q1, %[hwRatio]           \n"
            "   vldrb.u16               q0, [%[pTarget], #8]         \n"
            "   vshr.u16                q2, q2, #8                   \n"
            "   vstrb.16                q2, [%[pTarget]], #8         \n"
            "   le                      lr, 2b                       \n"
            "1:                                                      \n"
            /* tail */
            "   wlstp.16                lr, %[tail], 1f              \n"
            "2:                                                      \n"
            "   vmul.u16                q0, q0, %[hwRatioCompl]      \n"
            "   vldrb.u16               q1, [%[pSource]], #8         \n"
            "   vmla.s16                q0, q1, %[hwRatio]           \n"
            "   vshr.u16                q1, q0, #8                   \n"
            "   vldrb.u16               q0, [%[pTarget], #8]         \n"
            "   vstrb.16                q1, [%[pTarget]], #8         \n"
            "   letp                    lr, 2b                       \n"
            "1:                                                      \n"

            : [pTarget] "+l"(pTarget),  [pSource] "+l" (pSource)
            : [hwRatio] "r" (hwRatio), [hwRatioCompl] "r" (hwRatioCompl),
              [loopCnt] "r"(blkCnt/16), [tail] "r"(blkCnt & 0xf)
            :"q0", "q1", "q2", "memory", "r14");
#endif
        pSourceBase += (iSourceStride);
        pTargetBase += (iTargetStride);
   }
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_tile_copy_colour_keying_opacity)(uint8_t * __RESTRICT pSourceBase,
                                                      int16_t iSourceStride,
                                                      uint8_t * __RESTRICT pTargetBase,
                                                      int16_t iTargetStride,
                                                      arm_2d_size_t *
                                                      __RESTRICT ptCopySize,
                                                      uint_fast16_t hwRatio,
                                                      uint8_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif
    uint16_t        hwRatioCompl = 256 - hwRatio;

    for (int_fast16_t y = 0; y < iHeight; y++) {

        const uint8_t *pSource = pSourceBase;
        uint8_t       *pTarget = pTargetBase;
        int32_t         blkCnt = iWidth;

#ifdef USE_MVE_INTRINSICS
        do {
            mve_pred16_t    tailPred = vctp16q(blkCnt);
            uint16x8_t      vecTgt = vldrbq_z_u16(pTarget, tailPred);
            uint16x8_t      vecSrc = vldrbq_z_u16(pSource, tailPred);

            vecTgt = vmulq_x(vecTgt, hwRatioCompl, tailPred);
            vecTgt = vmlaq_m(vecTgt, vecSrc, (uint16_t)hwRatio, tailPred);
            vecTgt  = vecTgt  >> 8;

            vstrbq_p_u16(pTarget , vecTgt ,
                vcmpneq_m_n_u16(vecSrc, (uint16_t)Colour, tailPred));

            pSource += 8;
            pTarget += 8;
            blkCnt -= 8;
        }
        while (blkCnt > 0);

#else
        __asm volatile(
            "   vldrb.u16               q0, [%[pTarget]]             \n"
            ".p2align 2                                              \n"
            "   wls                     lr, %[loopCnt], 1f           \n"
            "2:                                                      \n"
            "   vmul.u16                q0, q0, %[hwRatioCompl]      \n"
            "   vldrb.u16               q1, [%[pSource]], #8         \n"
            "   vmla.s16                q0, q1, %[hwRatio]           \n"
            "   vldrb.u16               q2, [%[pTarget], #8]         \n"
            "   vshr.u16                q0, q0, #8                   \n"
            "   vpt.i16                 ne, q1, %[Colour]            \n"
            "   vstrbt.16               q0, [%[pTarget]], #8         \n"
            "   vmul.u16                q2, q2, %[hwRatioCompl]      \n"
            "   vldrb.u16               q1, [%[pSource]], #8         \n"
            "   vmla.s16                q2, q1, %[hwRatio]           \n"
            "   vldrb.u16               q0, [%[pTarget], #8]         \n"
            "   vshr.u16                q2, q2, #8                   \n"
            "   vpt.i16                 ne, q1, %[Colour]            \n"
            "   vstrbt.16               q2, [%[pTarget]], #8         \n"
            "   le                      lr, 2b                       \n"
            "1:                                                      \n"
            /* tail */
            "   wlstp.16                lr, %[tail], 1f              \n"
            "2:                                                      \n"
            "   vmul.u16                q0, q0, %[hwRatioCompl]      \n"
            "   vldrb.u16               q1, [%[pSource]], #8         \n"
            "   vmla.s16                q0, q1, %[hwRatio]           \n"
            "   vshr.u16                q2, q0, #8                   \n"
            "   vldrb.u16               q0, [%[pTarget], #8]         \n"
            "   vpt.i16                 ne, q1, %[Colour]            \n"
            "   vstrbt.16               q2, [%[pTarget]], #8         \n"
            "   letp                    lr, 2b                       \n"
            "1:                                                      \n"

            : [pTarget] "+l"(pTarget),  [pSource] "+l" (pSource)
            : [hwRatio] "r" (hwRatio), [hwRatioCompl] "r" (hwRatioCompl),
              [loopCnt] "r"(blkCnt/16), [tail] "r"(blkCnt & 0xf),
              [Colour] "r" (Colour)
            :"q0", "q1", "q2", "memory", "r14");
#endif
        pSourceBase += (iSourceStride);
        pTargetBase += (iTargetStride);
   }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_with_opacity)(uint8_t * __restrict pTargetBase,
                                                     int16_t iTargetStride,
                                                     arm_2d_size_t *
                                                     __restrict ptCopySize,
                                                     uint8_t Colour,
                                                     uint_fast16_t hwRatio)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif

    uint16_t        hwRatioCompl = 256 - hwRatio;

    uint16x8_t      vecSrc = vdupq_n_u16(Colour);

    for (int_fast16_t y = 0; y < iHeight; y++) {

        uint8_t       *pTarget = pTargetBase;
        int32_t        blkCnt = iWidth;

#ifdef USE_MVE_INTRINSICS
        do {
            mve_pred16_t    tailPred = vctp16q(blkCnt);
            uint16x8_t      vecTgt = vldrbq_z_u16(pTarget, tailPred);

            vecTgt = vmulq_x(vecTgt, hwRatioCompl, tailPred);
            vecTgt = vmlaq_m(vecTgt, vecSrc, (uint16_t)hwRatio, tailPred);
            vecTgt  = vecTgt  >> 8;

            vstrbq_p_u16(pTarget , vecTgt , tailPred);

            pTarget += 8;
            blkCnt -= 8;
        }
        while (blkCnt > 0);

#else
        __asm volatile(
            "   vldrb.u16               q0, [%[pTarget]]             \n"
            "   vmul.u16                q0, q0, %[hwRatioCompl]      \n"
            ".p2align 2                                              \n"
            "   wls                     lr, %[loopCnt], 1f           \n"
            "2:                                                      \n"

            "   vmla.s16                q0, %q[vecSrc], %[hwRatio]   \n"
            "   vldrb.u16               q2, [%[pTarget], #8]         \n"
            "   vshr.u16                q0, q0, #8                   \n"
            "   vmul.u16                q2, q2, %[hwRatioCompl]      \n"
            "   vstrb.16                q0, [%[pTarget]], #8         \n"
            "   vmla.s16                q2, %q[vecSrc], %[hwRatio]   \n"
            "   vldrb.u16               q0, [%[pTarget], #8]         \n"
            "   vshr.u16                q2, q2, #8                   \n"
            "   vmul.u16                q0, q0, %[hwRatioCompl]      \n"
            "   vstrb.16                q2, [%[pTarget]], #8         \n"
            "   le                      lr, 2b                       \n"
            "1:                                                      \n"
            /* tail */
            "   wlstp.16                lr, %[tail], 1f              \n"
            "2:                                                      \n"

            "   vmla.s16                q0, %q[vecSrc], %[hwRatio]   \n"
            "   vshr.u16                q2, q0, #8                   \n"
            "   vldrb.u16               q0, [%[pTarget], #8]         \n"
            "   vmul.u16                q0, q0, %[hwRatioCompl]      \n"
            "   vstrb.16                q2, [%[pTarget]], #8         \n"
            "   letp                    lr, 2b                       \n"
            "1:                                                      \n"

            : [pTarget] "+l"(pTarget)
            : [hwRatio] "r" (hwRatio), [hwRatioCompl] "r" (hwRatioCompl),
              [loopCnt] "r"(blkCnt/16), [tail] "r"(blkCnt & 0xf),
              [vecSrc] "t" (vecSrc)
            :"q0", "q2", "memory", "r14");
#endif
        pTargetBase += (iTargetStride);
   }
}





__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_tile_copy_opacity)(   uint16_t *phwSourceBase,
                                            int16_t iSourceStride,
                                            uint16_t *phwTargetBase,
                                            int16_t iTargetStride,
                                            arm_2d_size_t *ptCopySize,
                                            uint_fast16_t hwRatio)
{
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif

#ifdef USE_MVE_INTRINSICS
    int32_t         blkCnt;
    uint16_t        ratio1x8 = hwRatio * 8;
    uint16_t        ratio1x4 = hwRatio * 4;
    uint16_t        ratio2x8 = (256 - hwRatio) * 8;
    uint16_t        ratio2x4 = (256 - hwRatio) * 4;

    uint16x8_t      vecMaskR = vdupq_n_u16(0x001f);
    uint16x8_t      vecMaskG = vdupq_n_u16(0x003f);
    uint16x8_t      vecMaskBpck = vdupq_n_u16(0x00f8);
    uint16x8_t      vecMaskGpck = vdupq_n_u16(0x00fc);


    for (int32_t y = 0; y < ptCopySize->iHeight; y++) {
        const uint16_t *phwSource = phwSourceBase;
        uint16_t       *phwTarget = phwTargetBase;

        blkCnt = ptCopySize->iWidth;
        do {

            uint16x8_t      vecIn;
            uint16x8_t      vecR0, vecB0, vecG0;
            uint16x8_t      vecR1, vecB1, vecG1;
            
            mve_pred16_t pred = vctp16q(blkCnt);
            
            /* unpack 1st stream */
            vecIn = vld1q_z(phwSource, pred);
            vecR0 = vecIn & vecMaskR;

            vecB0 = vecIn >> 11;

            vecG0 = vecIn >> 5;
            vecG0 = vecG0 & vecMaskG;


            /* unpack 2nd stream */
            vecIn = vld1q(phwTarget);
            vecR1 = vecIn & vecMaskR;

            vecB1 = vecIn >> 11;

            vecG1 = vecIn >> 5;
            vecG1 = vecG1 & vecMaskG;


            /* merge */
            vecR0 = vecR0 * ratio1x8 + vecR1 * ratio2x8;
            vecR0 = vecR0 >> 8;

            vecG0 = vecG0 * ratio1x4 + vecG1 * ratio2x4;
            vecG0 = vecG0 >> 8;

            vecB0 = vecB0 * ratio1x8 + vecB1 * ratio2x8;
            vecB0 = vecB0 >> 8;


            /* pack */
            uint16x8_t      vOut = vecR0 >> 3 | vmulq((vecG0 & vecMaskGpck), 8)
                | vmulq((vecB0 & vecMaskBpck), 256);


            vst1q_p(phwTarget, vOut, pred);

            phwSource += 8;
            phwTarget += 8;
            blkCnt -= 8;
        }
        while (blkCnt > 0);

        phwSourceBase += iSourceStride;
        phwTargetBase += iTargetStride;
    }

#else /* USE_MVE_INTRINSICS  */


    uint16_t        ratio1x8 = hwRatio * 8;
    uint16_t        ratio1x4 = hwRatio * 4;
    uint16_t        ratio2x8 = (256 - hwRatio) * 8;
    uint16_t        ratio2x4 = (256 - hwRatio) * 4;
    uint16x8_t      vecMaskR = vdupq_n_u16(0x001f);
    uint16x8_t      vecMaskG = vdupq_n_u16(0x003f);
    uint16x8_t      vecMaskBpck = vdupq_n_u16(0x00f8);
    uint32_t        iWidth = ptCopySize->iWidth;
    int32_t         row = ptCopySize->iHeight;
    uint16x8_t      scratch[1];

    vst1q((uint16_t *)scratch, vdupq_n_u16(0x00fc));

    do {
        const uint16_t *pSource = phwSourceBase;
        uint16_t       *pTarget = phwTargetBase;
        register unsigned loopCnt  __asm("lr");
        loopCnt = iWidth;

    __asm volatile(
        ".p2align 2                                              \n"
        "   vldrh.u16               q4, [%[pTarget]]             \n"
        "   vldrh.u16               q5, [%[pSource]], #16        \n"

        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        "2:                                                      \n"
        // B target extraction
        // right shift by 5 (x 1/32) for M55 friendly
        // IV / Mul pipe interleaving
        "   vqdmulh.s16             q2, q4, %[rshft5]            \n"
        "   vand                    q7, q4, %q[vecMaskR]         \n"

        "   vmul.i16                q6, q7, %[ratio2x8]          \n"
        // B source extraction
        "   vand                    q7, q5, %q[vecMaskR]         \n"
        // B mix
        "   vmla.s16                q6, q7, %[ratio1x8]          \n"
        // G extraction
        "   vand                    q2, q2, %q[vecMaskG]         \n"
        "   vshr.u16                q7, q5, #5                   \n"
        "   vmul.i16                q2, q2, %[ratio2x4]          \n"
        // G extraction
        "   vand                    q7, q7, %q[vecMaskG]         \n"
        // G mix
        "   vmla.s16                q2, q7, %[ratio1x4]          \n"
        // R extraction
        "   vshr.u16                q4, q4, #11                  \n"
        "   vmul.i16                q7, q4, %[ratio2x8]          \n"
        // R extraction
        "   vshr.u16                q5, q5, #11                  \n"
        // R mix
        "   vmla.s16                q7, q5, %[ratio1x8]          \n"

        "   vshr.u16                q2, q2, #8                   \n"
        "   vldrh.16                q5, [%[scratch]]             \n"

        "   vand                    q2, q2, q5                   \n"
        // vmulq((vecG0 & 0x00fc), 8)
        "   vmul.i16                q2, q2, %[eight]             \n"
        "   vshr.u16                q4, q7, #8                   \n"
        // schedule next source load
        "   vldrh.u16               q5, [%[pSource]], #16        \n"
        "   vand                    q7, q4, %q[vecMaskBpck]      \n"
        // pack R & G
        // vmulq((vecG0 & vecMaskGpck), 8) + vmulq((vecR0 & vecMaskRpck), 256)
        "   vmla.s16                q2, q7, %[twofiftysix]       \n"
        // downshift B ((vecB0 >> 8) >> 3)
        "   vshr.u16                q7, q6, #11                  \n"
        // schedule next target load (pre offset as target not imcrementred so far)
        "   vldrh.u16               q4, [%[pTarget], #16]        \n"
        // pack blue with R&G
        "   vorr                    q2, q2, q7                   \n"

        "   vstrh.16                q2, [%[pTarget]], #16        \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"

        : [pSource] "+r"(pSource),  [pTarget] "+r" (pTarget), [loopCnt] "+r"(loopCnt)
        : [vecMaskR] "t" (vecMaskR), [vecMaskG] "t" (vecMaskG),
          [vecMaskBpck] "t" (vecMaskBpck),
          [ratio1x8] "r" (ratio1x8), [ratio2x8] "r" (ratio2x8),
          [ratio1x4] "r" (ratio1x4), [ratio2x4] "r" (ratio2x4),
          [eight] "r" (8), [twofiftysix] "r" (256), [rshft5] "r" (1024), [scratch] "r" (scratch)
        : "q2", "q4", "q5", "q6", "q7", "memory" );

        phwSourceBase += iSourceStride;
        phwTargetBase += iTargetStride;
    } while (--row);
#endif /* USE_MVE_INTRINSICS */
}






__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_with_opacity)(
                                        uint16_t *__RESTRICT pTargetBase,
                                        int16_t iTargetStride,
                                        arm_2d_size_t *__RESTRICT ptCopySize,
                                        uint16_t Colour,
                                        uint_fast16_t hwRatio)
{

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif

#ifdef USE_MVE_INTRINSICS
    int32_t         blkCnt;
    uint16_t        ratio1x8 = hwRatio * 8;
    uint16_t        ratio1x4 = hwRatio * 4;
    uint16_t        ratio2x8 = (256 - hwRatio) * 8;
    uint16_t        ratio2x4 = (256 - hwRatio) * 4;

    uint16x8_t      vecMaskR = vdupq_n_u16(0x001f);
    uint16x8_t      vecMaskG = vdupq_n_u16(0x003f);
    uint16x8_t      vecMaskBpck = vdupq_n_u16(0x00f8);
    uint16x8_t      vecMaskGpck = vdupq_n_u16(0x00fc);
    uint16x8_t      vecIn;
    uint16x8_t      vecColorR, vecColorB, vecColorG;

    /* unpack color & scale */
    vecIn = vdupq_n_u16(Colour);
    vecColorR = (vecIn & vecMaskR) * ratio1x8;

    vecColorB = (vecIn >> 11) * ratio1x8;

    vecColorG = vecIn >> 5;
    vecColorG = (vecColorG & vecMaskG) * ratio1x4;

    for (int32_t y = 0; y < ptCopySize->iHeight; y++) {
        uint16_t       *phwTarget = pTargetBase;

        blkCnt = ptCopySize->iWidth;
        do {
            uint16x8_t      vecR0, vecB0, vecG0;
            uint16x8_t      vecR1, vecB1, vecG1;

            mve_pred16_t pred = vctp16q(blkCnt);

            /* unpack stream */
            vecIn = vld1q_z(phwTarget, pred);
            vecR1 = vecIn & vecMaskR;

            vecB1 = vecIn >> 11;

            vecG1 = vecIn >> 5;
            vecG1 = vecG1 & vecMaskG;


            /* merge */
            vecR0 = vecColorR + vecR1 * ratio2x8;
            vecR0 = vecR0 >> 8;

            vecG0 = vecColorG + vecG1 * ratio2x4;
            vecG0 = vecG0 >> 8;

            vecB0 = vecColorB + vecB1 * ratio2x8;
            vecB0 = vecB0 >> 8;

            /* pack */
            uint16x8_t      vOut = vecR0 >> 3 | vmulq((vecG0 & vecMaskGpck), 8)
                | vmulq((vecB0 & vecMaskBpck), 256);

            vst1q_p(phwTarget, vOut, pred);

            phwTarget += 8;
            blkCnt -= 8;
        }
        while (blkCnt > 0);

        pTargetBase += iTargetStride;
    }

#else /* USE_MVE_INTRINSICS  */

    uint16_t        ratio1x8 = hwRatio * 8;
    uint16_t        ratio1x4 = hwRatio * 4;
    uint16_t        ratio2x8 = (256 - hwRatio) * 8;
    uint16_t        ratio2x4 = (256 - hwRatio) * 4;
    uint16x8_t      vecMaskR = vdupq_n_u16(0x001f);
    uint16x8_t      vecMaskG = vdupq_n_u16(0x003f);
    uint16x8_t      vecMaskBpck = vdupq_n_u16(0x00f8);
    uint16x8_t      vecColorR, vecColorB, vecColorG;
    uint16x8_t      scratch[4];

    /* unpack color */
    uint16x8_t vecIn = vdupq_n_u16(Colour);
    vecColorR = vecIn & vecMaskR;
    vecColorB = vecIn >> 11;
    vecColorG = vecIn >> 5;
    vecColorG = vecColorG & vecMaskG;
    vst1q((uint16_t*)scratch, vecColorR * ratio1x8);
    vst1q((uint16_t*)&scratch[1], vecColorB * ratio1x8);
    vst1q((uint16_t*)&scratch[2], vecColorG * ratio1x4);
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0x00fc));

    int32_t         row = ptCopySize->iHeight;
    do {

        uint16_t       *phwTarget = pTargetBase;
        register unsigned loopCnt  __asm("lr");
        loopCnt = ptCopySize->iWidth;

    __asm volatile(
        "   vldrh.u16               q4, [%[phwTarget]]           \n"

        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        ".p2align 2                                              \n"
        "2:                                                      \n"
        // B target extraction
        "   vand                    q7, q4, %q[vecMaskR]         \n"
        "   vldrh.u16               q6, [%[scratch]]             \n"
        "   vshr.u16                q2, q4, #5                   \n"

        // B mix
        "   vmla.s16                q6, q7, %[ratio2x8]          \n"
        // G extraction
        "   vand                    q7, q2, %q[vecMaskG]         \n"

        // G extraction
        "   vldrh.u16               q2, [%[scratch], #32]        \n"
        // G mix
        "   vmla.s16                q2, q7, %[ratio2x4]          \n"

        "   vshr.u16                q4, q4, #11                  \n"
        // R extraction
        "   vldrh.u16               q7, [%[scratch], #16]        \n"
        "   vshr.u16                q2, q2, #8                   \n"
        // R mix
        "   vmla.s16                q7, q4, %[ratio2x8]          \n"
        "   vshr.u16                q4, q7, #8                   \n"

        // load duplicated 0xfc mask
        "   vldrh.u16               q7, [%[scratch], #48]        \n"
        "   vand                    q2, q2, q7                   \n"

        "   vmul.i16                q2, q2, %[eight]             \n"
        "   vand                    q7, q4, %q[vecMaskBpck]      \n"

        // pack R & G
        "   vmla.s16                q2, q7, %[twofiftysix]       \n"
        // downshift B ((vecB0 >> 8) >> 3)
        "   vshr.u16                q7, q6, #11                  \n"
        // schedule next target load
        "   vldrh.u16               q4, [%[phwTarget], #16]      \n"
        // pack blue with R&G
        "   vorr                    q2, q2, q7                   \n"
        "   vstrh.16                q2, [%[phwTarget]], #16      \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"
        : [phwTarget] "+r" (phwTarget), [loopCnt] "+r"(loopCnt)
        : [vecMaskR] "t" (vecMaskR), [vecMaskG] "t" (vecMaskG),
          [vecMaskBpck] "t" (vecMaskBpck),
          [ratio2x8] "r" (ratio2x8), [ratio2x4] "r" (ratio2x4),
          [eight] "r" (8), [twofiftysix] "r" (256), [scratch] "r" (scratch)
        : "q2", "q4", "q5", "q6", "q7", "memory");

        pTargetBase += iTargetStride;
    } while (--row);

#endif /* USE_MVE_INTRINSICS */

}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_tile_copy_colour_keying_opacity)(
                                                uint16_t * __RESTRICT phwSource,
                                                int16_t         iSourceStride,
                                                uint16_t * __RESTRICT phwTarget,
                                                int16_t         iTargetStride,
                                                arm_2d_size_t * __RESTRICT ptCopySize,
                                                uint_fast16_t hwRatio,
                                                uint16_t   hwColour)
{
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif

#ifdef USE_MVE_INTRINSICS
    uint32_t        iHeight = ptCopySize->iHeight;
    uint32_t        iWidth = ptCopySize->iWidth;

    int32_t         blkCnt;
    uint16_t        ratio1x8 = hwRatio * 8;
    uint16_t        ratio1x4 = hwRatio * 4;
    uint16_t        ratio2x8 = (256 - hwRatio) * 8;
    uint16_t        ratio2x4 = (256 - hwRatio) * 4;

    uint16x8_t      vecMaskR = vdupq_n_u16(0x001f);
    uint16x8_t      vecMaskG = vdupq_n_u16(0x003f);
    uint16x8_t      vecMaskBpck = vdupq_n_u16(0x00f8);
    uint16x8_t      vecMaskGpck = vdupq_n_u16(0x00fc);

    for (uint32_t y = 0; y < iHeight; y++) {
        // - inconditional blending + predicated dst update
        const uint16_t *pSource = phwSource;
        uint16_t       *pTarget = phwTarget;
        blkCnt = iWidth >> 3;

        while (blkCnt > 0) {
            uint16x8_t      vecInSrc, vecInDst;
            uint16x8_t      vecR0, vecB0, vecG0;
            uint16x8_t      vecR1, vecB1, vecG1;

            /* unpack 1st stream */
            vecInSrc = vld1q(pSource);
            vecR0 = vandq(vecInSrc, vecMaskR);
            vecB0 = vshrq(vecInSrc, 11);
            vecG0 = vshrq(vecInSrc, 5);
            vecG0 = vandq(vecG0, vecMaskG);

            /* unpack 2nd stream */
            vecInDst = vld1q(pTarget);
            vecR1 = vandq(vecInDst, vecMaskR);
            vecB1 = vshrq(vecInDst, 11);
            vecG1 = vshrq(vecInDst, 5);
            vecG1 = vandq(vecG1, vecMaskG);

            /* merge */
            vecR0 = vmlaq(vmulq(vecR0, ratio1x8), vecR1, ratio2x8);
            vecR0 = vshrq(vecR0, 8);
            vecG0 = vmlaq(vmulq(vecG0, ratio1x4), vecG1, ratio2x4);
            vecG0 = vshrq(vecG0, 8);
            vecB0 = vmlaq(vmulq(vecB0, ratio1x8), vecB1, ratio2x8);
            vecB0 = vshrq(vecB0, 8);

            /* pack */
            uint16x8_t      vOut = vorrq(vshrq(vecR0, 3),
                                         vmulq(vandq(vecG0, vecMaskGpck), 8));

            vOut = vorrq(vOut, vmulq(vandq(vecB0, vecMaskBpck), 256));

            vst1q_p(pTarget, vOut, vcmpneq_n_s16(vecInSrc, hwColour));

            pSource += 8;
            pTarget += 8;
            blkCnt--;

        }

        blkCnt = iWidth & 7;
        if (blkCnt > 0U) {
            mve_pred16_t pred = vctp16q(blkCnt);
            uint16x8_t      vecInSrc, vecInDst;
            uint16x8_t      vecR0, vecB0, vecG0;
            uint16x8_t      vecR1, vecB1, vecG1;

            /* unpack 1st stream */
            vecInSrc = vld1q_z(pSource, pred);
            vecR0 = vandq(vecInSrc, vecMaskR);
            vecB0 = vshrq(vecInSrc, 11);
            vecG0 = vshrq(vecInSrc, 5);
            vecG0 = vandq(vecG0, vecMaskG);

            /* unpack 2nd stream */
            vecInDst = vld1q_z(pTarget, pred);
            vecR1 = vandq(vecInDst, vecMaskR);
            vecB1 = vshrq(vecInDst, 11);
            vecG1 = vshrq(vecInDst, 5);
            vecG1 = vandq(vecG1, vecMaskG);

            /* merge */
            vecR0 = vmlaq(vmulq(vecR0, ratio1x8), vecR1, ratio2x8);
            vecR0 = vshrq(vecR0, 8);
            vecG0 = vmlaq(vmulq(vecG0, ratio1x4), vecG1, ratio2x4);
            vecG0 = vshrq(vecG0, 8);
            vecB0 = vmlaq(vmulq(vecB0, ratio1x8), vecB1, ratio2x8);
            vecB0 = vshrq(vecB0, 8);

            /* pack */
            uint16x8_t      vOut = vorrq(vshrq(vecR0, 3),
                                         vmulq(vandq(vecG0, vecMaskGpck), 8));

            vOut = vorrq(vOut,
                    vmulq(vandq(vecB0, vecMaskBpck), 256));

            vst1q_p(pTarget, vOut,
                    vcmpneq_m_n_s16(vecInSrc, hwColour, pred));

        }

        phwSource += iSourceStride;
        phwTarget += iTargetStride;
    }
#else
    uint32_t        iHeight = ptCopySize->iHeight;
    uint32_t        iWidth = ptCopySize->iWidth;

    uint16_t        ratio1x8 = hwRatio * 8;
    uint16_t        ratio1x4 = hwRatio * 4;
    uint16_t        ratio2x8 = (256 - hwRatio) * 8;
    uint16_t        ratio2x4 = (256 - hwRatio) * 4;

    uint16x8_t      vecMaskR = vdupq_n_u16(0x001f);
    uint16x8_t      vecMaskG = vdupq_n_u16(0x003f);
    uint16x8_t      vecMaskBpck = vdupq_n_u16(0x00f8);
    uint16x8_t      scratch[1];

    vst1q((uint16_t *)scratch, vdupq_n_u16(0x00fc));

    for (uint32_t y = 0; y < iHeight; y++) {

        const uint16_t *pSource = phwSource;
        uint16_t       *pTarget = phwTarget;
        register unsigned loopCnt  __asm("lr");
        loopCnt = iWidth;

    __asm volatile(
        ".p2align 2                                              \n"
        "   vldrh.u16               q4, [%[pTarget]]             \n"
        "   vldrh.u16               q5, [%[pSource]], #16        \n"
        "   vand                    q7, q4, %q[vecMaskR]         \n"
        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        "2:                                                      \n"
        // B target extraction
        "   vshr.u16                q2, q4, #5                   \n"
        "   vmul.i16                q6, q7, %[ratio2x8]          \n"
        // B source extraction
        "   vand                    q7, q5, %q[vecMaskR]         \n"
        // B mix
        "   vmla.s16                q6, q7, %[ratio1x8]          \n"
        // G extraction
        "   vand                    q2, q2, %q[vecMaskG]         \n"
        "   vshr.u16                q7, q5, #5                   \n"
        "   vmul.i16                q2, q2, %[ratio2x4]          \n"
        // G extraction
        "   vand                    q7, q7, %q[vecMaskG]         \n"
        // G mix
        "   vmla.s16                q2, q7, %[ratio1x4]          \n"
        // R extraction
        "   vshr.u16                q4, q4, #11                  \n"
        "   vmul.i16                q7, q4, %[ratio2x8]          \n"
        // R extraction
        "   vshr.u16                q5, q5, #11                  \n"
        // R mix
        "   vmla.s16                q7, q5, %[ratio1x8]          \n"

        "   vshr.u16                q2, q2, #8                   \n"
        "   vldrh.16                q5, [%[scratch]]             \n"

        "   vand                    q2, q2, q5                   \n"
        // vmulq((vecG0 & 0x00fc), 8)
        "   vmul.i16                q2, q2, %[eight]             \n"
        "   vshr.u16                q4, q7, #8                   \n"
        // schedule next source load
        "   vldrh.u16               q5, [%[pSource]], #16        \n"
        "   vand                    q7, q4, %q[vecMaskBpck]      \n"
        // pack R & G
        // vmulq((vecG0 & vecMaskGpck), 8) + vmulq((vecR0 & vecMaskRpck), 256)
        "   vmla.s16                q2, q7, %[twofiftysix]       \n"
        // downshift B ((vecB0 >> 8) >> 3)
        "   vshr.u16                q7, q6, #11                  \n"
        // schedule next target load (pre offset as target not imcrementred so far)
        "   vldrh.u16               q4, [%[pTarget], #16]        \n"
        // pack blue with R&G
        "   vorr                    q2, q2, q7                   \n"
        "   vldrh.u16               q6, [%[pSource], #-32]       \n"
        "   vand                    q7, q4, %q[vecMaskR]         \n"
        "   vpt.i16                 ne, q6, %[hwColour]          \n"
        "   vstrht.16               q2, [%[pTarget]], #16        \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"

        : [pSource] "+r"(pSource),  [pTarget] "+r" (pTarget), [loopCnt] "+r"(loopCnt)
        : [vecMaskR] "t" (vecMaskR), [vecMaskG] "t" (vecMaskG),
          [vecMaskBpck] "t" (vecMaskBpck),
          [ratio1x8] "r" (ratio1x8), [ratio2x8] "r" (ratio2x8),
          [ratio1x4] "r" (ratio1x4), [ratio2x4] "r" (ratio2x4),
          [eight] "r" (8), [twofiftysix] "r" (256), [hwColour] "r" (hwColour), [scratch] "r" (scratch)
        : "q2", "q4", "q5", "q6", "q7", "memory");

        phwSource += (iSourceStride);
        phwTarget += (iTargetStride);
    }
#endif
}




__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_tile_copy_opacity)(   uint32_t *pwSourceBase,
                                            int16_t iSourceStride,
                                            uint32_t *pwTargetBase,
                                            int16_t iTargetStride,
                                            arm_2d_size_t *ptCopySize,
                                            uint_fast16_t hwRatio)
{
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif
    uint16_t        hwRatioCompl = 256 - (uint16_t) hwRatio;

#ifdef USE_MVE_INTRINSICS
    int32_t         blkCnt;
    int32_t         row = ptCopySize->iHeight;

    while (row > 0) {

        const uint32_t *pwSource = pwSourceBase;
        uint32_t       *pwTarget = pwTargetBase;

        blkCnt = ptCopySize->iWidth * 4;

        while (blkCnt > 0) {
            mve_pred16_t    pred = vctp16q(blkCnt);

            /* byte extraction into 16-bit vector */
            uint16x8_t vecSrc = vldrbq_z_u16((const uint8_t *)pwSource, pred);
            uint16x8_t vecTrg = vldrbq_z_u16((const uint8_t *)pwTarget, pred);

            vstrbq_p_u16(   (uint8_t *)pwTarget,
                            vmlaq(vmulq(vecSrc, (uint16_t)hwRatio), vecTrg, hwRatioCompl) >> 8,
                            pred);

            pwTarget += 2;
            pwSource += 2;
            blkCnt -= 8;
        }

        pwSourceBase += iSourceStride;
        pwTargetBase += iTargetStride;
        row--;
    }
#else

    register unsigned blkCnt  __asm("lr");
    int32_t row = ptCopySize->iHeight;

    while(row > 0)
    {
        blkCnt = ptCopySize->iWidth*4;
        const uint32_t *pwSource = pwSourceBase;
        uint32_t *pwTarget = pwTargetBase;

        __asm volatile(
            "   vldrb.u16               q0, [%[pwSource]], #8          \n"
            "   vldrb.u16               q1, [%[pwTarget]]              \n"

            "   wlstp.16                lr, %[loopCnt], 1f             \n"
            "2:                                                        \n"
            "   vmul.u16                q2, q0, %[hwRatio]             \n"
            "   vldrb.u16               q0, [%[pwSource]], #8          \n"
            "   vmla.s16                q2, q1, %[hwRatioCompl]        \n"
            "   vldrb.u16               q1, [%[pwTarget], #8]          \n"
            "   vshr.u16                q2, q2, #8                     \n"
            "   vstrb.16                q2, [%[pwTarget]], #8          \n"
            "   letp                    lr, 2b                         \n"
            "1:                                                        \n"

            : [pwSource] "+l"(pwSource),  [pwTarget] "+l"(pwTarget),
              [loopCnt] "+r"(blkCnt)
            : [hwRatio] "r" (hwRatio), [hwRatioCompl] "r" (hwRatioCompl)
            : "q0", "q1", "q2", "memory");

        pwSourceBase += iSourceStride;
        pwTargetBase += iTargetStride;
        row--;
    }
#endif
}




__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_with_opacity)(
                                        uint32_t *__RESTRICT pTargetBase,
                                        int16_t iTargetStride,
                                        arm_2d_size_t *__RESTRICT ptCopySize,
                                        uint32_t Colour,
                                        uint_fast16_t hwRatio)
{
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif
    uint16_t        hwRatioCompl = 256 - (uint16_t) hwRatio;

#ifdef USE_MVE_INTRINSICS
    int32_t         blkCnt;
    int32_t         row = ptCopySize->iHeight;
    uint32_t        scratch[2];
    uint16x8_t      vColor;

    scratch[0] = scratch[1] = Colour;
    vColor = vldrbq_u16((uint8_t *) scratch);
    vColor = vColor * (uint16_t)hwRatio;

    while (row > 0) {
        uint32_t       *pTarget = pTargetBase;
        blkCnt = ptCopySize->iWidth * 4;

        while (blkCnt > 0) {
            mve_pred16_t    pred = vctp16q(blkCnt);
            /* byte extraction into 16-bit vector */
            uint16x8_t      vecTrg = vldrbq_z_u16((uint8_t *)pTarget, pred);

            vstrbq_p_u16((uint8_t *)pTarget, vmlaq(vColor, vecTrg, hwRatioCompl) >> 8, pred);

            pTarget += 2;
            blkCnt -= 8;
        }
        pTargetBase += iTargetStride;
        row--;
    }
#else /* USE_MVE_INTRINSICS  */

    int32_t         blkCnt;
    int32_t         row = ptCopySize->iHeight;
    uint32_t        scratch[2];
    uint16x8_t      vColor;

    scratch[0] = scratch[1] = Colour;
    vColor = vldrbq_u16((uint8_t *) scratch);
    vColor = vColor * (uint16_t)hwRatio;

    while (row > 0) {
        uint32_t       *pTarget = pTargetBase;
        blkCnt = ptCopySize->iWidth*4;

    __asm volatile(
        /* preload */
        "   vldrb.u16               q1, [%[pTarget]]               \n"

        "   wlstp.16                lr, %[loopCnt], 1f             \n"
        ".p2align 2                                                \n"
        "2:                                                        \n"
        "   vmov                    q2, %q[vColor]                 \n"
        "   vmla.s16                q2, q1, %[hwRatioCompl]        \n"
        "   vldrb.u16               q1, [%[pTarget], #8]           \n"
        "   vshr.u16                q2, q2, #8                     \n"
        "   vstrb.16                q2, [%[pTarget]], #8           \n"
        "   letp                    lr, 2b                         \n"
        "1:                                                        \n"
        : [pTarget] "+l"(pTarget)
        : [loopCnt] "r"(blkCnt), [hwRatioCompl] "r" (hwRatioCompl), [vColor] "t" (vColor)
        : "q0", "q1", "q2", "memory", "r14" );

        pTargetBase += iTargetStride;
        row--;
    }

#endif /* USE_MVE_INTRINSICS */
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_tile_copy_colour_keying_opacity)(uint32_t * __RESTRICT pSourceBase,
                                                       int16_t iSourceStride,
                                                       uint32_t * __RESTRICT pTargetBase,
                                                       int16_t iTargetStride,
                                                       arm_2d_size_t *
                                                       __RESTRICT ptCopySize,
                                                       uint_fast16_t hwRatio,
                                                       uint32_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
    hwRatio += (hwRatio == 255);
#endif
    uint16_t        hwRatioCompl = 256 - hwRatio;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint32_t *pSource = pSourceBase;
        uint32_t       *pTarget = pTargetBase;

#ifdef USE_MVE_INTRINSICS
        int32_t         blkCnt = iWidth;

        do {
            mve_pred16_t    p = vctp32q(blkCnt);

            uint8x16_t      vSrc8 = vld1q_z(pSource, p);
            uint8x16_t      vTrg8 = vld1q_z(pTarget, p);

            /* 16-bit expansion A/G src pixels */
            uint16x8_t      vSrc16b = vmovlbq_x(vSrc8, p);
            /* 16-bit expansion R/B src pixels */
            uint16x8_t      vSrc16t = vmovltq_x(vSrc8, p);

            /* 16-bit expansion A/G target pixels */
            uint16x8_t      vTrg16b = vmovlbq_x(vTrg8, p);
            /* 16-bit expansion R/B target pixels */
            uint16x8_t      vTrg16t = vmovltq_x(vTrg8, p);

            /* A/G blending */
            int16x8_t       vecOutb = vmlaq_m(vmulq_x(vSrc16b, (uint16_t)hwRatio, p), vTrg16b, hwRatioCompl, p);
            /* R/B blending */
            int16x8_t       vecOutt = vmlaq_m(vmulq_x(vSrc16t, (uint16_t)hwRatio, p), vTrg16t, hwRatioCompl, p);

            /* merge into 8-bit vector */
            int8x16_t       vecOut8 = vuninitializedq_s8();

            vecOut8 = vqshrnbq_m_n_s16(vecOut8, vecOutb, 8, p);
            vecOut8 = vqshrntq_m_n_s16(vecOut8, vecOutt, 8, p);

            // update if (*pSourceBase != Colour)
            vst1q_p_u32(pTarget, (uint32x4_t) vecOut8,
                        vcmpneq_m_n_u32((uint32x4_t) vSrc8, Colour, p));

            pSource += 4;
            pTarget += 4;
            blkCnt -= 4;
        }
        while (blkCnt > 0);

#else // USE_MVE_INTRINSICS

    __asm volatile (
        ".p2align 2                                 \n"
        /* preload uint32x4_t target vector */
        "   vldrw.u32       q2, [%[targ]]           \n"

        "   wlstp.32        lr, %[loopCnt], 1f      \n"
        "2:                                         \n"
        /* 16-bit expansion A/G target pixels */
        "   vmovlb.u8       q3, q2                  \n"
        "   vldrw.u32       q0, [%[src]], #16       \n"
        /* 16-bit expansion A/G source pixels */
        "   vmovlb.u8       q1, q0                  \n"
        "   vmul.i16        q1, q1, %[ratio]        \n"
        /* 16-bit expansion R/B target pixels */
        "   vmovlt.u8       q2, q2                  \n"
        /* A/G blending */
        "   vmla.s16        q1, q3, %[ratioCmp]     \n"
        /* 16-bit expansion R/B source pixels */
        "   vmovlt.u8       q3, q0                  \n"
        "   vmul.i16        q3, q3, %[ratio]        \n"
        /* merge A/G into 8-bit vector */
        "   vqshrnb.s16     q1, q1, #8              \n"
        /* R/B blending */
        "   vmla.s16        q3, q2, %[ratioCmp]     \n"
        /* preload next target */
        "   vldrw.u32       q2, [%[targ], #16]      \n"
        /* merge R/B into 8-bit vector */
        "   vqshrnt.s16     q1, q3, #8              \n"
        /* update if (*pSourceBase != Colour) */
        "   vpt.i32         ne, q0, %[color]        \n"
        "   vstrwt.32       q1, [%[targ]], #16      \n"
        "   letp            lr, 2b                  \n"
        "1:                                         \n"
        :[targ] "+r" (pTarget), [src] "+r" (pSource)
        :[loopCnt] "r" (iWidth), [ratio] "r" (hwRatio),
         [ratioCmp] "r" (hwRatioCompl), [color] "r" (Colour)
        :"r14", "q0", "q1", "q2", "q3", "memory", "r14");
#endif
        pSourceBase += (iSourceStride);
        pTargetBase += (iTargetStride);
    }
}

/* rgb8_draw_pattern helpers */

/*
 * enable to pick gather load offset based on initial offset
 * e.g. if iOffset = 3
 * will get {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2}
 */
static uint8_t __draw_pattern_src_incr_c8bit[32] = {
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1,
    2, 2, 2, 2, 2, 2, 2, 2,
    3, 3, 3, 3, 3, 3, 3, 3
};

/*
 * enable to pick vector bitmask based on initial offset
 * e.g. if iOffset = 3
 * will get {8, 16, 32, 64, 128, 1, 2, 4, 8, 16, 32, 64, 128, 1, 2, 4}
 */

static  uint8_t __draw_pattern_src_bitmask_c8bit[32] = {
    1, 2, 4, 8, 16, 32, 64, 128,
    1, 2, 4, 8, 16, 32, 64, 128,
    1, 2, 4, 8, 16, 32, 64, 128,
    1, 2, 4, 8, 16, 32, 64, 128,
};


/* rgb16_draw_pattern helpers */

/*
 * enable to pick gather load offset based on initial offset
 * e.g. if iOffset = 3
 * will get {0, 0, 0, 0, 0, 1, 1, 1}
 */
static uint16_t __draw_pattern_src_incr_rgb16[16] = {
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1
};

/*
 * enable to pick vector bitmask based on initial offset
 * e.g. if iOffset = 3
 * will get {8, 16, 32, 64, 128, 1, 2, 4}
 */

static  uint16_t __draw_pattern_src_bitmask_rgb16[16] = {
    1, 2, 4, 8, 16, 32, 64, 128,
    1, 2, 4, 8, 16, 32, 64, 128,
};


/* rgb32_draw_pattern helpers */

static uint32_t __draw_pattern_src_incr_rgb32[16] = {
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1
};


static  uint32_t __draw_pattern_src_bitmask_rgb32[16] = {
    1, 2, 4, 8, 16, 32, 64, 128,
    1, 2, 4, 8, 16, 32, 64, 128,
};



/*! adding support with c code template */
#define __API_COLOUR        c8bit
#define __API_ELT_SZ        8
#include "__arm_2d_ll_draw_pattern_helium.inc"


#define __API_COLOUR        rgb16
#define __API_ELT_SZ        16
#include "__arm_2d_ll_draw_pattern_helium.inc"


#define __API_COLOUR        rgb32
#define __API_ELT_SZ        32
#include "__arm_2d_ll_draw_pattern_helium.inc"



#define __API_COLOUR        c8bit
#define __API_ELT_SZ        8
#include "__arm_2d_ll_fill_colour_helium.inc"


#define __API_COLOUR        rgb16
#define __API_ELT_SZ        16
#include "__arm_2d_ll_fill_colour_helium.inc"


#define __API_COLOUR        rgb32
#define __API_ELT_SZ        32
#include "__arm_2d_ll_fill_colour_helium.inc"


/**
  8-bit pixel color fill alpha/channel mask with/without opacity MVE intrinsic generator
   - TRGT_LOAD is a contigous / strided target load function
        C8BIT_TRGT_LOAD / C8BIT_TRGT_LOAD_STRIDE
  - STRIDE is an optional vector of offset for gather load
  - SCAL_OPACITY is extra alpha scaling function
        C8BIT_SCAL_OPACITY_NONE / C8BIT_SCAL_OPACITY
  - OPACITY is an optinal 8-bit vector with duplicated opacity values
  (need vector format to be used with VMULH.U8)
  - ALPHA_SZ, alpha chan width (1 or 4 for resp. 8 or 32-bit type)

  Macro assumes pTarget8/ pAlpha are already setup
 */




#define C8BIT_COLOUR_FILLING_MASK_INNER_MVE(TRGT_LOAD, STRIDE, SCAL_OPACITY,                   \
                                                             OPACITY, ALPHA_SZ, COMPVAL)       \
        int32_t         blkCnt = iWidth;                                                       \
        do {                                                                                   \
            mve_pred16_t    tailPred = vctp16q(blkCnt);                                        \
                                                                                               \
            uint16x8_t      vecTarget = vldrbq_z_u16(pTarget8, tailPred);                      \
            uint16x8_t      vecTransp = TRGT_LOAD(pAlpha, STRIDE, tailPred);                   \
                                                                                               \
            vecTransp = SCAL_OPACITY(vecTransp, OPACITY, tailPred);                            \
                                                                                               \
            ALPHA_255_COMP_VEC16(vecTransp, COMPVAL);                                          \
                                                                                               \
            uint16x8_t      vecAlpha = vsubq_u16(v256, vecTransp);                             \
                                                                                               \
            vecTarget = vmulq(vecTarget, vecAlpha);                                            \
            vecTarget = vmlaq(vecTarget, vecTransp, (uint16_t) Colour);                        \
            vecTarget = vshrq(vecTarget, 8);                                                   \
                                                                                               \
            vstrbq_p_u16(pTarget8, vecTarget, tailPred);                                       \
                                                                                               \
            pAlpha += (8 * ALPHA_SZ);                                                          \
            pTarget8 += 8;                                                                     \
            blkCnt -= 8;                                                                       \
        }                                                                                      \
        while (blkCnt > 0);


/**
  RGB565 pixel color fill alpha/channel mask with/without opacity MVE intrinsic generator
   - TRGT_LOAD is a contigous / strided target load function
        RGB565_TRGT_LOAD / RGB565_TRGT_LOAD_STRIDE
  - STRIDE is an optional vector of offset for gather load
  - SCAL_OPACITY is extra alpha scaling function
        RGB565_SCAL_OPACITY_NONE / RGB565_SCAL_OPACITY
  - OPACITY is an optinal 8-bit vector with duplicated opacity values
  (need vector format to be used with VMULH.U8)
  - P_ALPHA, 8-bit or 32-bit alpha chan. pointer
  - ALPHA_SZ, alpha chan width (1 or 4 for resp. 8 or 32-bit type)

  Does not generate a tail-predicated loop as relying on pack/unpack functions.
  Predication is only applied in the final stage during pixel store.
 */

#define RGB565_COLOUR_FILLING_MASK_MVE(TRGT_LOAD, STRIDE, SCAL_OPACITY, OPACITY,               \
                                                            P_ALPHA,  ALPHA_SZ, COMPVAL)       \
    uint16x8_t      v256 = vdupq_n_u16(256);                                                   \
                                                                                               \
    for (int_fast16_t y = 0; y < iHeight; y++) {                                               \
        const uint8_t  *pAlpha = (const uint8_t *)P_ALPHA;                                     \
        uint16_t       *pCurTarget = pTarget;                                                  \
        int32_t         blkCnt = iWidth;                                                       \
                                                                                               \
        do {                                                                                   \
            mve_pred16_t    tailPred = vctp16q(blkCnt);                                        \
            uint16x8_t      vecTarget = vld1q_z(pCurTarget, tailPred);                         \
            uint16x8_t      vecTransp = TRGT_LOAD(pAlpha, STRIDE, tailPred);                   \
            vecTransp = SCAL_OPACITY(vecTransp, OPACITY);                                      \
                                                                                               \
            ALPHA_255_COMP_VEC16(vecTransp, COMPVAL);                                          \
                                                                                               \
            uint16x8_t      vecAlpha = vsubq_u16(v256, vecTransp);                             \
            uint16x8_t      vecR, vecG, vecB;                                                  \
                                                                                               \
            __arm_2d_rgb565_unpack_single_vec(vecTarget, &vecR, &vecG, &vecB);                 \
                                                                                               \
            /* blending using alpha vector weights */                                          \
            vecR = vmulq(vecR, vecAlpha);                                                      \
            vecR = vmlaq(vecR, vecTransp, (uint16_t) tSrcPix.R);                               \
            vecR = vecR >> 8;                                                                  \
                                                                                               \
            vecG = vmulq(vecG, vecAlpha);                                                      \
            vecG = vmlaq(vecG, vecTransp, (uint16_t) tSrcPix.G);                               \
            vecG = vecG >> 8;                                                                  \
                                                                                               \
            vecB = vmulq(vecB, vecAlpha);                                                      \
            vecB = vmlaq(vecB, vecTransp, (uint16_t) tSrcPix.B);                               \
            vecB = vecB >> 8;                                                                  \
                                                                                               \
            vecTarget = __arm_2d_rgb565_pack_single_vec(vecR, vecG, vecB);                     \
                                                                                               \
            /* tail predication */                                                             \
            vst1q_p_u16(pCurTarget, vecTarget, tailPred);                                      \
                                                                                               \
            pAlpha += (8 *  ALPHA_SZ);                                                         \
            pCurTarget += 8;                                                                   \
            blkCnt -= 8;                                                                       \
        }                                                                                      \
        while (blkCnt > 0);                                                                    \
                                                                                               \
        P_ALPHA += (iAlphaStride);                                                             \
        pTarget += (iTargetStride);                                                            \
    }


/**
  CCCN888 pixel color fill alpha/channel mask with/without opacity MVE intrinsic generator
   - TRGT_LOAD is a contigous / strided target load function
        CCCN888_TRGT_LOAD / CCCN888_TRGT_LOAD_STRIDE
  - STRIDE is an optional vector of offset for gather load
  - SCAL_OPACITY is extra alpha scaling function
        CCCN888_SCAL_OPACITY_NONE / CCCN888_SCAL_OPACITY
  - OPACITY is an optinal 8-bit vector with duplicated opacity values
  (need vector format to be used with VMULH.U8)
  - ALPHA_SZ, alpha chan width (1 or 4 for resp. 8 or 32-bit type)

  Macro assumes pTargetCh0/1/2 & pAlpha are already setup
 */

#define CCCN888_COLOUR_FILLING_MASK_INNER_MVE(TRGT_LOAD, STRIDE, SCAL_OPACITY,                 \
                                                                  OPACITY, ALPHA_SZ, COMPVAL)  \
        int32_t         blkCnt = iWidth;                                                       \
                                                                                               \
        do {                                                                                   \
            mve_pred16_t    tailPred = vctp16q(blkCnt);                                        \
                                                                                               \
            /* expand chan0, chan1, chan2 */                                                   \
            uint16x8_t      vecTargetC0 = vldrbq_gather_offset_z_u16(pTargetCh0, vStride4Offs, \
                tailPred);                                                                     \
            uint16x8_t      vecTargetC1 = vldrbq_gather_offset_z_u16(pTargetCh1, vStride4Offs, \
                tailPred);                                                                     \
            uint16x8_t      vecTargetC2 = vldrbq_gather_offset_z_u16(pTargetCh2, vStride4Offs, \
                tailPred);                                                                     \
            uint16x8_t      vecTransp = TRGT_LOAD(pAlpha, STRIDE, tailPred);                   \
                                                                                               \
            vecTransp = SCAL_OPACITY(vecTransp, OPACITY, tailPred);                            \
                                                                                               \
            ALPHA_255_COMP_VEC16(vecTransp, COMPVAL);                                          \
                                                                                               \
            uint16x8_t      vecAlpha = vsubq_u16(v256, vecTransp);                             \
                                                                                               \
                                                                                               \
            /*  scale ch0 vector with alpha vector */                                          \
            vecTargetC0 = vmulq(vecTargetC0, vecAlpha);                                        \
            /*  blend ch0 vector with input ch0 color*/                                        \
            vecTargetC0 = vmlaq(vecTargetC0, vecTransp, (uint16_t) c0);                        \
            vecTargetC0 = vecTargetC0 >> 8;                                                    \
                                                                                               \
            /* repeat for ch1 and ch2 */                                                       \
            vecTargetC1 = vmulq(vecTargetC1, vecAlpha);                                        \
            vecTargetC1 = vmlaq(vecTargetC1, vecTransp, (uint16_t) c1);                        \
            vecTargetC1 = vecTargetC1 >> 8;                                                    \
                                                                                               \
            vecTargetC2 = vmulq(vecTargetC2, vecAlpha);                                        \
            vecTargetC2 = vmlaq(vecTargetC2, vecTransp, (uint16_t) c2);                        \
            vecTargetC2 = vecTargetC2 >> 8;                                                    \
                                                                                               \
            /* store and merge chan0, chan1, chan2 */                                          \
            vstrbq_scatter_offset_p_u16(pTargetCh0, vStride4Offs, vecTargetC0, tailPred);      \
            vstrbq_scatter_offset_p_u16(pTargetCh1, vStride4Offs, vecTargetC1, tailPred);      \
            vstrbq_scatter_offset_p_u16(pTargetCh2, vStride4Offs, vecTargetC2, tailPred);      \
                                                                                               \
            pAlpha += 8 * ALPHA_SZ;                                                            \
            pTargetCh0 += 8*4;                                                                 \
            pTargetCh1 += 8*4;                                                                 \
            pTargetCh2 += 8*4;                                                                 \
            blkCnt -= 8;                                                                       \
        }                                                                                      \
        while (blkCnt > 0);



#define C8BIT_TRGT_LOAD(base, stride, pred)             vldrbq_z_u16(base, pred)
#define C8BIT_TRGT_LOAD_STRIDE(base, stride, pred)      vldrbq_gather_offset_z_u16(base, stride, pred);
#define C8BIT_SCAL_OPACITY_NONE(transp, opac, pred)     transp
//#define C8BIT_SCAL_OPACITY(transp, opac, pred)          (uint16x8_t) vmulhq_x((uint8x16_t) transp, opac, pred)
///* no high part extraction for A1 mask */
//#define C8BIT_SCAL_OPACITY_A1(transp, opac, pred)       (uint16x8_t) vmulq_x((uint8x16_t) transp, opac, pred)

#define C8BIT_SCAL_OPACITY(transp, opac, pred)          (uint16x8_t) vmulhq((uint8x16_t) transp, opac)
/* no high part extraction for A1 mask */
#define C8BIT_SCAL_OPACITY_A1(transp, opac, pred)       (uint16x8_t) vmulq((uint8x16_t) transp, opac)

#define RGB565_TRGT_LOAD(base, stride, pred)            vldrbq_z_u16(base, pred)
#define RGB565_TRGT_LOAD_STRIDE(base, stride, pred)     vldrbq_gather_offset_z_u16(base, stride, pred);
#define RGB565_SCAL_OPACITY_NONE(transp, opac)          transp
#define RGB565_SCAL_OPACITY(transp, opac)               (uint16x8_t) vmulhq((uint8x16_t) transp, opac)
#define RGB565_SCAL_OPACITY_A1(transp, opac)            (uint16x8_t) vmulq((uint8x16_t) transp, opac)

#define CCCN888_TRGT_LOAD(base, stride, pred)           vldrbq_z_u16(base, pred)
#define CCCN888_TRGT_LOAD_STRIDE(base, stride, pred)    vldrbq_gather_offset_z_u16(base, stride, pred);
#define CCCN888_SCAL_OPACITY_NONE(transp, opac, pred)   transp
//#define CCCN888_SCAL_OPACITY(transp, opac, pred)        (uint16x8_t) vmulhq_x((uint8x16_t) transp, opac, pred)
//#define CCCN888_SCAL_OPACITY_A1(transp, opac, pred)     (uint16x8_t) vmulq_x((uint8x16_t) transp, opac, pred)
#define CCCN888_SCAL_OPACITY(transp, opac, pred)        (uint16x8_t) vmulhq((uint8x16_t) transp, opac)
#define CCCN888_SCAL_OPACITY_A1(transp, opac, pred)     (uint16x8_t) vmulq((uint8x16_t) transp, opac)

/* 1, 2 and 4-bit alpha expansions helper tables */
static uint8_t A1_expand_offs[8*2]= {
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1,
    };

static uint8_t A1_masks[8*2]= {
    0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,
    0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80
    };

static int8_t A1_masks_shifts[8*2]= {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07
    };

static uint8_t A2_expand_offs[4*3]= {
    0, 0, 0, 0,
    1, 1, 1, 1,
    2, 2, 2, 2
    };

static uint8_t A2_masks[4*3]= {
    0x03, 0x0c, 0x30, 0xc0,
    0x03, 0x0c, 0x30, 0xc0,
    0x03, 0x0c, 0x30, 0xc0
    };

static int8_t A2_masks_shifts[4*3]= {
    0x00, 0x02, 0x04, 0x06,
    0x00, 0x02, 0x04, 0x06,
    0x00, 0x02, 0x04, 0x06,
    };


static uint8_t A4_expand_offs[4*3]= {
    0, 0, 1, 1,
    2, 2, 3, 3,
    4, 4, 5, 5
    };

static uint8_t A4_masks[4*3]= {
    0x0f, 0xf0, 0x0f, 0xf0,
    0x0f, 0xf0, 0x0f, 0xf0,
    0x0f, 0xf0, 0x0f, 0xf0
    };

static int8_t A4_masks_shifts[4*3]= {
    0x00, 0x04, 0x00, 0x04,
    0x00, 0x04, 0x00, 0x04,
    0x00, 0x04, 0x00, 0x04,
    };


/* 1-bit alpha expansion in a 8x16-bit vector */
/* ((gather_load(alpha, curA1Off) & curA1Masks) >> curA1MasksShift)  */
#define C8BIT_TRGT_LOAD_A1(base, stride, pred)  \
    vshlq_x_u16( \
        vandq_x(vldrbq_gather_offset_z_u16(base, curA1Offs, pred), curA1Masks, pred),\
        curA1MasksShift, pred)

#define RGB565_TRGT_LOAD_A1(base, stride, pred)  \
        vshlq_x_u16( \
            vandq_x(vldrbq_gather_offset_z_u16(base, curA1Offs, pred), curA1Masks, pred),\
            curA1MasksShift, pred)


/* 2-bit alpha expansion in a 8x16-bit vector */
/* ((gather_load(alpha, curA2Off) & curA2Masks) >> curA2MasksShift) * 85 */
#define C8BIT_TRGT_LOAD_A2(base, stride, pred)  \
    vmulq_x_n_u16( \
        vshlq_x_u16( \
            vandq_x(vldrbq_gather_offset_z_u16(base, curA2Offs, pred), curA2Masks, pred),\
            curA2MasksShift, pred), \
        85, pred)

#define RGB565_TRGT_LOAD_A2(base, stride, pred)  \
    vmulq_x_n_u16( \
        vshlq_x_u16( \
            vandq_x(vldrbq_gather_offset_z_u16(base, curA2Offs, pred), curA2Masks, pred),\
            curA2MasksShift, pred), \
        85, pred)

#define CCCN888_TRGT_LOAD_A2(base, stride, pred)  C8BIT_TRGT_LOAD_A2(base, stride, pred)
#define CCCN888_TRGT_LOAD_A1(base, stride, pred)  C8BIT_TRGT_LOAD_A1(base, stride, pred)


/* 4-bit alpha expansion in a 8x16-bit vector */
/* ((gather_load(alpha, curA4Off) & curA4Masks) >> curA4MasksShift) * 17 */
#define C8BIT_TRGT_LOAD_A4(base, stride, pred)  \
    vmulq_x_n_u16( \
        vshlq_x_u16( \
            vandq_x(vldrbq_gather_offset_z_u16(base, curA4Offs, pred), curA4Masks, pred),\
            curA4MasksShift, pred), \
        17, pred)

/* 4-bit alpha expansion in a 8x16-bit vector */
/* ((gather_load(alpha, curA4Off) & curA4Masks) >> curA4MasksShift) * 17 */
#define RGB565_TRGT_LOAD_A4(base, stride, pred)  \
    vmulq_x_n_u16( \
        vshlq_x_u16( \
            vandq_x(vldrbq_gather_offset_z_u16(base, curA4Offs, pred), curA4Masks, pred),\
            curA4MasksShift, pred), \
        17, pred)

#define CCCN888_TRGT_LOAD_A4(base, stride, pred)  C8BIT_TRGT_LOAD_A4(base, stride, pred)


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_a2_mask)(
                            uint8_t *__restrict pTargetBase,
                            int16_t iTargetStride,
                            uint8_t *__restrict pchAlpha,
                            int16_t iAlphaStride,
                            int32_t nAlphaOffset,
                            arm_2d_size_t *__restrict ptCopySize,
                            uint8_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

    nAlphaOffset &= 0x03;
    iAlphaStride = (iAlphaStride + 3) & ~0x03;
    iAlphaStride >>= 2;

    uint16x8_t      v256 = vdupq_n_u16(256);

    /* 2-bit alpha relative byte location offsets */
    uint16x8_t      curA2Offs = vldrbq_u16(A2_expand_offs + nAlphaOffset);
    /* 2-bit alpha byte masks */
    uint16x8_t      curA2Masks = vldrbq_u16(A2_masks + nAlphaOffset);
    /* 2-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA2MasksShift =
        vnegq_s16(vldrbq_s16(A2_masks_shifts + nAlphaOffset));


    for (int_fast16_t y = 0; y < iHeight; y++) {

        const uint8_t  *pAlpha = pchAlpha;
        uint8_t        *pTarget8 = pTargetBase;


        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD_A2, _,
                                            /* advance alpha ptr by a quarter of byte */
                                            C8BIT_SCAL_OPACITY_NONE, _, 1 / 4, 255);

        pchAlpha += (iAlphaStride);
        pTargetBase += (iTargetStride);
    }
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_a4_mask)(
                            uint8_t *__restrict pTargetBase,
                            int16_t iTargetStride,
                            uint8_t *__restrict pchAlpha,
                            int16_t iAlphaStride,
                            int32_t nAlphaOffset,
                            arm_2d_size_t *__restrict ptCopySize,
                            uint8_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

    nAlphaOffset &= 0x01;
    iAlphaStride = (iAlphaStride + 1) & ~0x01;
    iAlphaStride >>= 1;
    uint16x8_t      v256 = vdupq_n_u16(256);

    /* 4-bit alpha relative byte location offsets */
    uint16x8_t      curA4Offs = vldrbq_u16(A4_expand_offs + nAlphaOffset);
    /* 4-bit alpha byte masks */
    uint16x8_t      curA4Masks = vldrbq_u16(A4_masks + nAlphaOffset);
    /* 4-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA4MasksShift =
        vnegq_s16(vldrbq_s16(A4_masks_shifts + nAlphaOffset));


    for (int_fast16_t y = 0; y < iHeight; y++) {

        const uint8_t  *pAlpha = pchAlpha;
        uint8_t        *pTarget8 = pTargetBase;


        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD_A4, _,
                                            /* advance alpha ptr by a half a byte */
                                            C8BIT_SCAL_OPACITY_NONE, _, 1 / 2, 255);

        pchAlpha += (iAlphaStride);
        pTargetBase += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_mask)(uint8_t * __RESTRICT pTarget,
                                                       int16_t iTargetStride,
                                                       uint8_t * __RESTRICT pchAlpha,
                                                       int16_t iAlphaStride,
                                                       arm_2d_size_t * __RESTRICT ptCopySize,
                                                       uint8_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTarget8 = pTarget;

#ifdef USE_MVE_INTRINSICS
        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD, _,
                                        C8BIT_SCAL_OPACITY_NONE, _, 1, 255);
#else
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
            "vecAlphaCompl            .req q2                        \n"

            ".p2align 2                                              \n"
            "   vldrb.u16               q0, [%[pTarget]]             \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
            "   wlstp.16                lr, %[loopCnt], 1f           \n"
            "2:                                                      \n"
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if alpha == 255, boost to 256 */
            "   vpt.i16                 eq, q1, %[alph255]           \n"
            "   vmovt.i16               q1, #256                     \n"
#endif

            "   vsub.i16                vecAlphaCompl, %q[vec256], q1\n"
            "   vmul.u16                q3, q0, vecAlphaCompl        \n"
            "   vldrb.u16               q0, [%[pTarget], #8]         \n"
            "   vmla.u16                q3, q1, %[Colour]            \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
            "   vshr.u16                q3, q3, #8                   \n"
            "   vstrb.16                q3, [%[pTarget]], #8         \n"
            "   letp                    lr, 2b                       \n"
            "1:                                                      \n"

            " .unreq vecAlphaCompl                                   \n"
            : [pTarget] "+l"(pTarget8),  [pAlpha] "+l" (pAlpha), [loopCnt] "+r"(blkCnt)
            :[vec256] "t"   (v256),[Colour] "r"(Colour)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            ,[alph255] "r" (255)
#endif
            :"q0", "q1", "q2", "q3", "memory");
#endif
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_a1_mask_opacity)(uint8_t * __RESTRICT pTarget,
                                                               int16_t iTargetStride,
                                                               uint8_t * __RESTRICT pchAlpha,
                                                               int16_t iAlphaStride,
                                                               int32_t nAlphaOffset,
                                                               arm_2d_size_t *
                                                               __RESTRICT ptCopySize,
                                                               uint8_t Colour,
                                                               uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

    nAlphaOffset &= 0x07;
    iAlphaStride = (iAlphaStride + 7) & ~0x07;
    iAlphaStride >>= 3;

    uint16x8_t      v256 = vdupq_n_u16(256);

    /* 1-bit alpha relative byte location offsets */
    uint16x8_t      curA1Offs = vldrbq_u16(A1_expand_offs + nAlphaOffset);
    /* 1-bit alpha byte masks */
    uint16x8_t      curA1Masks = vldrbq_u16(A1_masks + nAlphaOffset);
    /* 1-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA1MasksShift =
        vnegq_s16(vldrbq_s16(A1_masks_shifts + nAlphaOffset));

    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);


    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTarget8 = pTarget;


        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD_A1, _,
                                        /* advance alpha ptr by a quarter of byte */
                                        C8BIT_SCAL_OPACITY_A1, vOpacity, 1 / 8, 254);
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_a2_mask_opacity)(uint8_t * __RESTRICT pTarget,
                                                               int16_t iTargetStride,
                                                               uint8_t * __RESTRICT pchAlpha,
                                                               int16_t iAlphaStride,
                                                               int32_t nAlphaOffset,
                                                               arm_2d_size_t *
                                                               __RESTRICT ptCopySize,
                                                               uint8_t Colour,
                                                               uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

    nAlphaOffset &= 0x03;
    iAlphaStride = (iAlphaStride + 3) & ~0x03;
    iAlphaStride >>= 2;

    uint16x8_t      v256 = vdupq_n_u16(256);

    /* 2-bit alpha relative byte location offsets */
    uint16x8_t      curA2Offs = vldrbq_u16(A2_expand_offs + nAlphaOffset);
    /* 2-bit alpha byte masks */
    uint16x8_t      curA2Masks = vldrbq_u16(A2_masks + nAlphaOffset);
    /* 2-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA2MasksShift =
        vnegq_s16(vldrbq_s16(A2_masks_shifts + nAlphaOffset));

    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);


    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTarget8 = pTarget;

#if 1//def USE_MVE_INTRINSICS
        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD_A2, _,
                                        /* advance alpha ptr by a quarter of byte */
                                        C8BIT_SCAL_OPACITY, vOpacity, 1 / 4, 254);
#else
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
        "vecAlphaCompl            .req q2                        \n"

        ".p2align 2                                              \n"
        "   vldrb.u16               q0, [%[pTarget]]             \n"
        "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        "2:                                                      \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
        /* if vOpacity == 254, boost to 256 */
        "   vpt.i16                 eq, q1, %[opa254]            \n"
        "   vmovt.i16               q1, #256                     \n"
#endif

        "   vsub.i16                vecAlphaCompl, %q[vec256], q1\n"
        "   vmul.u16                q3, q0, vecAlphaCompl        \n"
        "   vldrb.u16               q0, [%[pTarget], #8]         \n"
        "   vmla.u16                q3, q1, %[Colour]            \n"
        "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   vshr.u16                q3, q3, #8                   \n"
        "   vstrb.16                q3, [%[pTarget]], #8         \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"

        " .unreq vecAlphaCompl                                   \n"
        : [pTarget] "+l"(pTarget8),  [pAlpha] "+l" (pAlpha), [loopCnt] "+r"(blkCnt)
        :[vec256] "t"   (v256),[Colour] "r"(Colour),[vOpacity] "t"(vOpacity)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
         ,[opa254] "r" (254)
#endif
        :"q0", "q1", "q2", "q3", "memory", "r14");

#endif
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_a4_mask_opacity)(uint8_t * __RESTRICT pTarget,
                                                               int16_t iTargetStride,
                                                               uint8_t * __RESTRICT pchAlpha,
                                                               int16_t iAlphaStride,
                                                               int32_t nAlphaOffset,
                                                               arm_2d_size_t *
                                                               __RESTRICT ptCopySize,
                                                               uint8_t Colour,
                                                               uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;

    nAlphaOffset &= 0x01;
    iAlphaStride = (iAlphaStride + 1) & ~0x01;
    iAlphaStride >>= 1;

    uint16x8_t      v256 = vdupq_n_u16(256);

    /* 2-bit alpha relative byte location offsets */
    uint16x8_t      curA4Offs = vldrbq_u16(A4_expand_offs + nAlphaOffset);
    /* 2-bit alpha byte masks */
    uint16x8_t      curA4Masks = vldrbq_u16(A4_masks + nAlphaOffset);
    /* 2-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA4MasksShift =
        vnegq_s16(vldrbq_s16(A4_masks_shifts + nAlphaOffset));

    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);


    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTarget8 = pTarget;

#if 1//def USE_MVE_INTRINSICS
        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD_A4, _,
                                        /* advance alpha ptr by a quarter of byte */
                                        C8BIT_SCAL_OPACITY, vOpacity, 1 / 2, 254);
#else
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
        "vecAlphaCompl            .req q2                        \n"

        ".p2align 2                                              \n"
        "   vldrb.u16               q0, [%[pTarget]]             \n"
        "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        "2:                                                      \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
        /* if vOpacity == 254, boost to 256 */
        "   vpt.i16                 eq, q1, %[opa254]            \n"
        "   vmovt.i16               q1, #256                     \n"
#endif

        "   vsub.i16                vecAlphaCompl, %q[vec256], q1\n"
        "   vmul.u16                q3, q0, vecAlphaCompl        \n"
        "   vldrb.u16               q0, [%[pTarget], #8]         \n"
        "   vmla.u16                q3, q1, %[Colour]            \n"
        "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   vshr.u16                q3, q3, #8                   \n"
        "   vstrb.16                q3, [%[pTarget]], #8         \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"

        " .unreq vecAlphaCompl                                   \n"
        : [pTarget] "+l"(pTarget8),  [pAlpha] "+l" (pAlpha), [loopCnt] "+r"(blkCnt)
        :[vec256] "t"   (v256),[Colour] "r"(Colour),[vOpacity] "t"(vOpacity)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
         ,[opa254] "r" (254)
#endif
        :"q0", "q1", "q2", "q3", "memory", "r14");

#endif
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_mask_opacity)(uint8_t * __RESTRICT pTarget,
                                                               int16_t iTargetStride,
                                                               uint8_t * __RESTRICT pchAlpha,
                                                               int16_t iAlphaStride,
                                                               arm_2d_size_t *
                                                               __RESTRICT ptCopySize,
                                                               uint8_t Colour,
                                                               uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    uint16x8_t      v256 = vdupq_n_u16(256);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTarget8 = pTarget;

#ifdef USE_MVE_INTRINSICS
        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD, _,
                                        C8BIT_SCAL_OPACITY, vOpacity, 1, 254);
#else
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
        "vecAlphaCompl            .req q2                        \n"

        ".p2align 2                                              \n"
        "   vldrb.u16               q0, [%[pTarget]]             \n"
        "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        "2:                                                      \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
        /* if vOpacity == 254, boost to 256 */
        "   vpt.i16                 eq, q1, %[opa254]            \n"
        "   vmovt.i16               q1, #256                     \n"
#endif

        "   vsub.i16                vecAlphaCompl, %q[vec256], q1\n"
        "   vmul.u16                q3, q0, vecAlphaCompl        \n"
        "   vldrb.u16               q0, [%[pTarget], #8]         \n"
        "   vmla.u16                q3, q1, %[Colour]            \n"
        "   vldrb.u16               q1, [%[pAlpha]], #8          \n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   vshr.u16                q3, q3, #8                   \n"
        "   vstrb.16                q3, [%[pTarget]], #8         \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"

        " .unreq vecAlphaCompl                                   \n"
        : [pTarget] "+l"(pTarget8),  [pAlpha] "+l" (pAlpha), [loopCnt] "+r"(blkCnt)
        :[vec256] "t"   (v256),[Colour] "r"(Colour),[vOpacity] "t"(vOpacity)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
         ,[opa254] "r" (254)
#endif
        :"q0", "q1", "q2", "q3", "memory");

#endif
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_channel_mask)(uint8_t * __RESTRICT pTarget,
                                                         int16_t iTargetStride,
                                                         uint32_t * __RESTRICT pwAlpha,
                                                         int16_t iAlphaStride,
                                                         arm_2d_size_t * __RESTRICT ptCopySize,
                                                         uint8_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = (const uint8_t *)pwAlpha;
        uint8_t *       pTarget8 = pTarget;

#ifdef USE_MVE_INTRINSICS
        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD_STRIDE, vStride4Offs,
                                        C8BIT_SCAL_OPACITY_NONE, _, 4, 255);
#else
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
        "vecAlphaCompl            .req q2                        \n"

        ".p2align 2                                              \n"
        "   vldrb.u16               q0, [%[pTarget]]             \n"
        "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]\n"
        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        "2:                                                      \n"
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
        /* if alpha == 255, boost to 256 */
        "   vpt.i16                 eq, q1, %[alph255]           \n"
        "   vmovt.i16               q1, #256                     \n"
#endif

        "   add                     %[pAlpha], %[pAlpha], #(8*4) \n"
        "   vsub.i16                vecAlphaCompl, %q[vec256], q1\n"
        "   vmul.u16                q3, q0, vecAlphaCompl        \n"
        "   vldrb.u16               q0, [%[pTarget], #8]         \n"
        "   vmla.s16                q3, q1, %[Colour]            \n"
        "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]\n"
        "   vshr.u16                q3, q3, #8                   \n"
        "   vstrb.16                q3, [%[pTarget]], #8         \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"

        " .unreq vecAlphaCompl                                   \n"
        : [pTarget] "+l"(pTarget8),  [pAlpha] "+r" (pAlpha), [loopCnt] "+r"(blkCnt)
        :[vec256] "t"   (v256),[Colour] "r"(Colour),[str4Offs] "t"(vStride4Offs)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
        ,[alph255] "r" (255)
#endif
        :"q0", "q1", "q2", "q3", "memory");

#endif
        pwAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}




__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_gray8_colour_filling_channel_mask_opacity)(uint8_t * __RESTRICT pTarget,
                                                                 int16_t iTargetStride,
                                                                 uint32_t * __RESTRICT pwAlpha,
                                                                 int16_t iAlphaStride,
                                                                 arm_2d_size_t *
                                                                 __RESTRICT ptCopySize,
                                                                 uint8_t Colour,
                                                                 uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = (const uint8_t *)pwAlpha;
        uint8_t        *pTarget8 = pTarget;

#ifdef USE_MVE_INTRINSICS
        C8BIT_COLOUR_FILLING_MASK_INNER_MVE(C8BIT_TRGT_LOAD_STRIDE, vStride4Offs,
                                        C8BIT_SCAL_OPACITY, vOpacity, 4, 254);
#else
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
        "vecAlphaCompl            .req q2                        \n"

        ".p2align 2                                              \n"
        "   vldrb.u16               q0, [%[pTarget]]             \n"
        "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]\n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   wlstp.16                lr, %[loopCnt], 1f           \n"
        "2:                                                      \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
        /* if vOpacity == 254, boost to 256 */
        "   vpt.i16                 eq, q1, %[opa254]            \n"
        "   vmovt.i16               q1, #256                     \n"
#endif

        "   add                     %[pAlpha], %[pAlpha], #(8*4) \n"

        "   vsub.i16                vecAlphaCompl, %q[vec256], q1\n"
        "   vmul.u16                q3, q0, vecAlphaCompl        \n"
        "   vldrb.u16               q0, [%[pTarget], #8]         \n"
        "   vmla.s16                q3, q1, %[Colour]            \n"
        "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]\n"
        "   vmulh.u8                q1, q1, %q[vOpacity]         \n"
        "   vshr.u16                q3, q3, #8                   \n"
        "   vstrb.16                q3, [%[pTarget]], #8         \n"
        "   letp                    lr, 2b                       \n"
        "1:                                                      \n"

        " .unreq vecAlphaCompl                                   \n"
        : [pTarget] "+l"(pTarget8),  [pAlpha] "+r" (pAlpha), [loopCnt] "+r"(blkCnt)
        :[vec256] "t"   (v256),[Colour] "r"(Colour),[vOpacity] "t"(vOpacity),
         [str4Offs] "t"(vStride4Offs)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
         ,[opa254] "r" (254)
#endif
        :"q0", "q1", "q2", "q3", "memory");

#endif
        pwAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER(__arm_2d_impl_rgb565_colour_filling_a2_mask)(uint16_t * __RESTRICT pTarget,
                                                 int16_t iTargetStride,
                                                 uint8_t * __RESTRICT pchAlpha,
                                                 int16_t iAlphaStride,
                                                 int32_t nAlphaOffset,
                                                 arm_2d_size_t *
                                                 __RESTRICT ptCopySize,
                                                 uint16_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    __arm_2d_color_fast_rgb_t tSrcPix;
    nAlphaOffset &= 0x03;
    iAlphaStride = (iAlphaStride + 3) & ~0x03;
    iAlphaStride >>= 2;

    /* 2-bit alpha relative byte location offsets */
    uint16x8_t      curA2Offs = vldrbq_u16(A2_expand_offs + nAlphaOffset);
    /* 2-bit alpha byte masks */
    uint16x8_t      curA2Masks = vldrbq_u16(A2_masks + nAlphaOffset);
    /* 2-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA2MasksShift =
        vnegq_s16(vldrbq_s16(A2_masks_shifts + nAlphaOffset));

    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#if 1 //def USE_MVE_INTRINSICS
    RGB565_COLOUR_FILLING_MASK_MVE( RGB565_TRGT_LOAD_A2, _,
                                    RGB565_SCAL_OPACITY_NONE, _, pchAlpha, 1/4, 255);
#else
    /* RGB565 pack/unpack Masks */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[5];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = pchAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"
            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if alpha == 255, boost to 256 */
            "   vpt.i16                 eq, q1, %[alph255]         \n"
            "   vmovt.i16               q1, #256                   \n"
#endif

            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* combined (R >> 8) >> 3 */
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+l"(pCurTarget),[pAlpha] "+l"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            ,[alph255] "r" (255)
#endif
            :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory", "r14");

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}


__OVERRIDE_WEAK
void __MVE_WRAPPER(__arm_2d_impl_rgb565_colour_filling_a4_mask)(uint16_t * __RESTRICT pTarget,
                                                 int16_t iTargetStride,
                                                 uint8_t * __RESTRICT pchAlpha,
                                                 int16_t iAlphaStride,
                                                 int32_t nAlphaOffset,
                                                 arm_2d_size_t *
                                                 __RESTRICT ptCopySize,
                                                 uint16_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    __arm_2d_color_fast_rgb_t tSrcPix;
    nAlphaOffset &= 0x01;
    iAlphaStride = (iAlphaStride + 1) & ~0x01;
    iAlphaStride >>= 1;

    /* 4-bit alpha relative byte location offsets */
    uint16x8_t      curA4Offs = vldrbq_u16(A4_expand_offs + nAlphaOffset);
    /* 4-bit alpha byte masks */
    uint16x8_t      curA4Masks = vldrbq_u16(A4_masks + nAlphaOffset);
    /* 4-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA4MasksShift =
        vnegq_s16(vldrbq_s16(A4_masks_shifts + nAlphaOffset));

    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#if 1//def USE_MVE_INTRINSICS
    RGB565_COLOUR_FILLING_MASK_MVE( RGB565_TRGT_LOAD_A4, _,
                                    RGB565_SCAL_OPACITY_NONE, _, pchAlpha, 1/2, 255);
#else
    /* RGB565 pack/unpack Masks */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[5];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = pchAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"
            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if alpha == 255, boost to 256 */
            "   vpt.i16                 eq, q1, %[alph255]         \n"
            "   vmovt.i16               q1, #256                   \n"
#endif

            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* combined (R >> 8) >> 3 */
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+l"(pCurTarget),[pAlpha] "+l"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            ,[alph255] "r" (255)
#endif
            :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory", "r14");

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_mask)(uint16_t * __RESTRICT pTarget,
                                                    int16_t iTargetStride,
                                                    uint8_t * __RESTRICT pchAlpha,
                                                    int16_t iAlphaStride,
                                                    arm_2d_size_t * __RESTRICT ptCopySize,
                                                    uint16_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    __arm_2d_color_fast_rgb_t tSrcPix;

    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#ifdef USE_MVE_INTRINSICS
    RGB565_COLOUR_FILLING_MASK_MVE( RGB565_TRGT_LOAD, _,
                                    RGB565_SCAL_OPACITY_NONE, _, pchAlpha, 1, 255);
#else
    /* RGB565 pack/unpack Masks */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[5];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = pchAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"
            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if alpha == 255, boost to 256 */
            "   vpt.i16                 eq, q1, %[alph255]         \n"
            "   vmovt.i16               q1, #256                   \n"
#endif

            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* combined (R >> 8) >> 3 */
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+l"(pCurTarget),[pAlpha] "+l"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            ,[alph255] "r" (255)
#endif
            :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory");

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_a1_mask_opacity)(uint16_t * __RESTRICT pTarget,
                                                    int16_t iTargetStride,
                                                    uint8_t * __RESTRICT pchAlpha,
                                                    int16_t iAlphaStride,
                                                    int32_t nAlphaOffset,
                                                    arm_2d_size_t * __RESTRICT ptCopySize,
                                                    uint16_t Colour,
                                                    uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    __arm_2d_color_fast_rgb_t tSrcPix;

    nAlphaOffset &= 0x07;
    iAlphaStride = (iAlphaStride + 7) & ~0x07;
    iAlphaStride >>= 3;

    /* 1-bit alpha relative byte location offsets */
    uint16x8_t      curA1Offs = vldrbq_u16(A1_expand_offs + nAlphaOffset);
    /* 1-bit alpha byte masks */
    uint16x8_t      curA1Masks = vldrbq_u16(A1_masks + nAlphaOffset);
    /* 1-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA1MasksShift =
        vnegq_s16(vldrbq_s16(A1_masks_shifts + nAlphaOffset));


    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);


    RGB565_COLOUR_FILLING_MASK_MVE( RGB565_TRGT_LOAD_A1, _,
                                    RGB565_SCAL_OPACITY_A1, vOpacity, pchAlpha, 1/8, 254);
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_a2_mask_opacity)(uint16_t * __RESTRICT pTarget,
                                                    int16_t iTargetStride,
                                                    uint8_t * __RESTRICT pchAlpha,
                                                    int16_t iAlphaStride,
                                                    int32_t nAlphaOffset,
                                                    arm_2d_size_t * __RESTRICT ptCopySize,
                                                    uint16_t Colour,
                                                    uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    __arm_2d_color_fast_rgb_t tSrcPix;
    nAlphaOffset &= 0x03;
    iAlphaStride = (iAlphaStride + 3) & ~0x03;
    iAlphaStride >>= 2;

    /* 2-bit alpha relative byte location offsets */
    uint16x8_t      curA2Offs = vldrbq_u16(A2_expand_offs + nAlphaOffset);
    /* 2-bit alpha byte masks */
    uint16x8_t      curA2Masks = vldrbq_u16(A2_masks + nAlphaOffset);
    /* 2-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA2MasksShift =
        vnegq_s16(vldrbq_s16(A2_masks_shifts + nAlphaOffset));


    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#if 1//def USE_MVE_INTRINSICS
    RGB565_COLOUR_FILLING_MASK_MVE( RGB565_TRGT_LOAD_A2, _,
                                    RGB565_SCAL_OPACITY, vOpacity, pchAlpha, 1/4, 254);
#else
    /* RGB565 pack/unpack Masks + opacity */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[6];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));
    // opacity
    vst1q((uint16_t*)&scratch[4], (uint16x8_t)vOpacity);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = pchAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"
            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            /* opacity vector */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if vOpacity == 254, boost to 256 */
            "   vpt.i16                 eq, q1, %[opa254]          \n"
            "   vmovt.i16               q1, #256                   \n"
#endif
            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* reload opacity and scale alpha */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"

            /* combined (R >> 8) >> 3 */
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+r"(pCurTarget),[pAlpha] "+l"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
             ,[opa254] "r" (254)
#endif
            :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory", "r14");

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_a4_mask_opacity)(uint16_t * __RESTRICT pTarget,
                                                    int16_t iTargetStride,
                                                    uint8_t * __RESTRICT pchAlpha,
                                                    int16_t iAlphaStride,
                                                    int32_t nAlphaOffset,
                                                    arm_2d_size_t * __RESTRICT ptCopySize,
                                                    uint16_t Colour,
                                                    uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    __arm_2d_color_fast_rgb_t tSrcPix;
    nAlphaOffset &= 0x01;
    iAlphaStride = (iAlphaStride + 1) & ~0x01;
    iAlphaStride >>= 1;

    /* 4-bit alpha relative byte location offsets */
    uint16x8_t      curA4Offs = vldrbq_u16(A4_expand_offs + nAlphaOffset);
    /* 4-bit alpha byte masks */
    uint16x8_t      curA4Masks = vldrbq_u16(A4_masks + nAlphaOffset);
    /* 4-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA4MasksShift =
        vnegq_s16(vldrbq_s16(A4_masks_shifts + nAlphaOffset));


    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#if 1//def USE_MVE_INTRINSICS
    RGB565_COLOUR_FILLING_MASK_MVE( RGB565_TRGT_LOAD_A4, _,
                                    RGB565_SCAL_OPACITY, vOpacity, pchAlpha, 1/2, 254);
#else
    /* RGB565 pack/unpack Masks + opacity */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[6];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));
    // opacity
    vst1q((uint16_t*)&scratch[4], (uint16x8_t)vOpacity);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = pchAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"
            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            /* opacity vector */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if vOpacity == 254, boost to 256 */
            "   vpt.i16                 eq, q1, %[opa254]          \n"
            "   vmovt.i16               q1, #256                   \n"
#endif
            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* reload opacity and scale alpha */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"

            /* combined (R >> 8) >> 3 */
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+r"(pCurTarget),[pAlpha] "+l"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
             ,[opa254] "r" (254)
#endif
            :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory", "r14");

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_mask_opacity)(uint16_t * __RESTRICT pTarget,
                                                    int16_t iTargetStride,
                                                    uint8_t * __RESTRICT pchAlpha,
                                                    int16_t iAlphaStride,
                                                    arm_2d_size_t * __RESTRICT ptCopySize,
                                                    uint16_t Colour,
                                                    uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);

    __arm_2d_color_fast_rgb_t tSrcPix;

    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#ifdef USE_MVE_INTRINSICS
    RGB565_COLOUR_FILLING_MASK_MVE( RGB565_TRGT_LOAD, _,
                                    RGB565_SCAL_OPACITY, vOpacity, pchAlpha, 1, 254);
#else
    /* RGB565 pack/unpack Masks + opacity */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[6];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));
    // opacity
    vst1q((uint16_t*)&scratch[4], (uint16x8_t)vOpacity);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = pchAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"
            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            /* opacity vector */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if vOpacity == 254, boost to 256 */
            "   vpt.i16                 eq, q1, %[opa254]          \n"
            "   vmovt.i16               q1, #256                   \n"
#endif
            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1, [%[pAlpha]], #8        \n"
            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* reload opacity and scale alpha */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"

            /* combined (R >> 8) >> 3 */
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+r"(pCurTarget),[pAlpha] "+l"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
             ,[opa254] "r" (254)
#endif
            :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory");

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_channel_mask)(uint16_t * __RESTRICT pTarget,
                                                      int16_t iTargetStride,
                                                      uint32_t * __RESTRICT pwAlpha,
                                                      int16_t iAlphaStride,
                                                      arm_2d_size_t * __RESTRICT ptCopySize,
                                                      uint16_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    __arm_2d_color_fast_rgb_t tSrcPix;

    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#ifdef USE_MVE_INTRINSICS
    RGB565_COLOUR_FILLING_MASK_MVE(RGB565_TRGT_LOAD_STRIDE, vStride4Offs,
                                            RGB565_SCAL_OPACITY_NONE, _, pwAlpha, 4, 1);
#else
    /* RGB565 pack/unpack Masks  */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[4];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint32_t  *pAlpha = pwAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"

            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1,[%[pAlpha],%q[str4Offs]]\n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"
            "   add                     %[pAlpha], %[pAlpha],#(8*4)\n"
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if alpha == 255, boost to 256 */
            "   vpt.i16                 eq, q1, %[alph255]         \n"
            "   vmovt.i16               q1, #256                   \n"
#endif
            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1,[%[pAlpha],%q[str4Offs]]\n"

            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* combined (R >> 8) >> 3 */
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+r"(pCurTarget),[pAlpha] "+r"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch), [str4Offs] "t"(vStride4Offs)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            ,[alph255] "r" (255)
#endif
            :"q0", "q1", "q2", "q4", "q5", "q6", "q7", "memory");

        pwAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_rgb565_colour_filling_channel_mask_opacity)(uint16_t * __RESTRICT pTarget,
                                                              int16_t iTargetStride,
                                                              uint32_t * __RESTRICT pwAlpha,
                                                              int16_t iAlphaStride,
                                                              arm_2d_size_t * __RESTRICT ptCopySize,
                                                              uint16_t Colour,
                                                              uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    __arm_2d_color_fast_rgb_t tSrcPix;

    __arm_2d_rgb565_unpack(*(&Colour), &tSrcPix);

#ifdef USE_MVE_INTRINSICS

    RGB565_COLOUR_FILLING_MASK_MVE(RGB565_TRGT_LOAD_STRIDE, vStride4Offs,
                                            RGB565_SCAL_OPACITY, vOpacity, pwAlpha, 4, 2);
#else
    /* RGB565 pack/unpack Masks + opacity */
    /* use memory rather than vmov to optimize Helium operations interleaving */
    uint16x8_t scratch[5];

    // Unpacking Mask Red
    vst1q((uint16_t*)&scratch[0], vdupq_n_u16(0x1f));
    // Unpacking Mask Green
    vst1q((uint16_t*)&scratch[1], vdupq_n_u16(0x3f));
    // packing Mask Green
    vst1q((uint16_t*)&scratch[2], vdupq_n_u16(0xfc));
    // packing Mask Blue
    vst1q((uint16_t*)&scratch[3], vdupq_n_u16(0xf8));
    // opacity
    vst1q((uint16_t*)&scratch[4], (uint16x8_t)vOpacity);

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint32_t  *pAlpha = pwAlpha;
        uint16_t       *pCurTarget = pTarget;
        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

       __asm volatile  (
            ".p2align 2                                            \n"
            /* load scheduling */
            "   vldrh.u16               q0, [%[pTarget]]           \n"

            "   vmov.i16                q7, #0x0100                \n"
            "   vldrb.u16               q1,[%[pAlpha],%q[str4Offs]]\n"
            /* opacity vector */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"

            "   wlstp.16                lr, %[loopCnt], 1f         \n"
            "2:                                                    \n"
            "   add                     %[pAlpha], %[pAlpha],#(8*4)\n"
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if vOpacity == 254, boost to 256 */
            "   vpt.i16                 eq, q1, %[opa254]          \n"
            "   vmovt.i16               q1, #256                   \n"
#endif
            // vecAlpha
            "   vsub.i16                q2, q7, q1                 \n"

            /*  RGB565 unpack          */

            /* vecAlpha * 4 for G channel upscale */
            "   vmul.i16                q2, q2, %[four]            \n"
            /* G channel extract */
            "   vshr.u16                q5, q0, #5                 \n"

            /* load Unpacking Mask for R channel */
            "   vldrh.u16               q7, [%[scratch], #(0*16)]  \n"
            "   vand                    q4, q0, q7                 \n"

            /* load Unpacking Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(1*16)]  \n"
            "   vand                    q5, q5, q7                 \n"
            /*  scale G vector with alpha vector */
            "   vmul.u16                q5, q5, q2                 \n"

            /* B channel */
            "   vshr.u16                q6, q0, #11                \n"

            /*  blend G vector with input G color*/
            "   vmla.s16                q5, q1, %[G]               \n"

            /* vecAlpha * 8 for R & B  upscale */
            "   vshl.i16                q2, q2, #1                 \n"

            /*  scale R vector with alpha vec */
            "   vmul.u16                q4, q4, q2                 \n"

            "   vshr.u16                q5, q5, #8                 \n"

            /*  blend R vector with input R color*/
            "   vmla.s16                q4, q1, %[B]               \n"

            /* load packing Mask for G channel */
            "   vldrh.u16               q7, [%[scratch], #(2*16)]  \n"

            /*  scale B vector with alpha vector */
            "   vmul.u16                q6, q6, q2                 \n"
            "   vand                    q5, q5, q7                 \n"

            /*  blend B vector with input B color*/
            "   vmla.s16                q6, q1, %[R]               \n"

            /* load packing Mask for B channel */
            "   vldrh.u16               q7, [%[scratch], #(3*16)]  \n"

            "   vshr.u16                q6, q6, #8                 \n"

           /* RGB 565 pack */

            /* (G & 0x00fc), 8) */
            "   vmul.i16                q5, q5, %[eight]           \n"

            /* (B & 0x00f8) */
            "   vand                    q6, q6, q7                 \n"

            /* load next alpha vector */
            "   vldrb.u16               q1,[%[pAlpha],%q[str4Offs]]\n"

            "   vmov.i16                q7, #0x0100                \n"

            /* pack G & B */
            "   vmla.s16                q5, q6, %[twofiftysix]     \n"
            /* combined (R >> 8) >> 3 */
            "   vldrh.u16               q6, [%[scratch], #(4*16)]  \n"
            "   vmulh.u8                q1, q1, q6                 \n"
            "   vshr.u16                q4, q4, #11                \n"

            /* load next target */
            "   vldrh.u16               q0, [%[pTarget], #16]      \n"

            /*  pack R */
            "   vorr                    q4, q4, q5                 \n"
            "   vstrh.16                q4, [%[pTarget]], #16      \n"
            "   letp                    lr, 2b                     \n"
            "1:                                                    \n"
            :[pTarget]"+r"(pCurTarget),[pAlpha] "+r"(pAlpha),[loopCnt] "+r"(blkCnt)
            :[Colour] "r"(Colour), [eight] "r" (8), [four] "r" (4),
            [R] "r" (tSrcPix.R), [G] "r" (tSrcPix.G), [B] "r" (tSrcPix.B),
            [twofiftysix] "r" (256), [scratch] "r" (scratch), [str4Offs] "t"(vStride4Offs)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
             ,[opa254] "r" (254)
#endif
            :"q0", "q1", "q2", "q4", "q5", "q6", "q7", "memory");

        pwAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
#endif
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_a2_mask)(uint32_t * __RESTRICT pTarget,
                                                     int16_t iTargetStride,
                                                     uint8_t * __RESTRICT pchAlpha,
                                                     int16_t iAlphaStride,
                                                     int32_t nAlphaOffset,
                                                     arm_2d_size_t * __RESTRICT ptCopySize,
                                                     uint32_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint16_t        c0, c1, c2;

    nAlphaOffset &= 0x03;
    iAlphaStride = (iAlphaStride + 3) & ~0x03;
    iAlphaStride >>= 2;


    /* 2-bit alpha relative byte location offsets */
    uint16x8_t      curA2Offs = vldrbq_u16(A2_expand_offs + nAlphaOffset);
    /* 2-bit alpha byte masks */
    uint16x8_t      curA2Masks = vldrbq_u16(A2_masks + nAlphaOffset);
    /* 2-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA2MasksShift =
        vnegq_s16(vldrbq_s16(A2_masks_shifts + nAlphaOffset));

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;

        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD_A2, _,
                                        CCCN888_SCAL_OPACITY_NONE, _, 1/4, 255);

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_a4_mask)(uint32_t * __RESTRICT pTarget,
                                                     int16_t iTargetStride,
                                                     uint8_t * __RESTRICT pchAlpha,
                                                     int16_t iAlphaStride,
                                                     int32_t nAlphaOffset,
                                                     arm_2d_size_t * __RESTRICT ptCopySize,
                                                     uint32_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint16_t        c0, c1, c2;

    nAlphaOffset &= 0x01;
    iAlphaStride = (iAlphaStride + 1) & ~0x01;
    iAlphaStride >>= 1;

    /* 4-bit alpha relative byte location offsets */
    uint16x8_t      curA4Offs = vldrbq_u16(A4_expand_offs + nAlphaOffset);
    /* 4-bit alpha byte masks */
    uint16x8_t      curA4Masks = vldrbq_u16(A4_masks + nAlphaOffset);
    /* 4-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA4MasksShift =
        vnegq_s16(vldrbq_s16(A4_masks_shifts + nAlphaOffset));

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;

        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD_A4, _,
                                        CCCN888_SCAL_OPACITY_NONE, _, 1/2, 255);

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_mask)(uint32_t * __RESTRICT pTarget,
                                                     int16_t iTargetStride,
                                                     uint8_t * __RESTRICT pchAlpha,
                                                     int16_t iAlphaStride,
                                                     arm_2d_size_t * __RESTRICT ptCopySize,
                                                     uint32_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint16_t        c0, c1, c2;

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;

#ifdef USE_MVE_INTRINSICS

        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD, _,
                                        CCCN888_SCAL_OPACITY_NONE, _, 1, 255);
#else

        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
            "vecAlphaCompl            .req q2                             \n"

            ".p2align 2                                                   \n"
            /* expand chan0 */
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8               \n"

            "   wlstp.16                lr, %[loopCnt], 1f                \n"
            "2:                                                           \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if alpha == 255, boost to 256 */
            "   vpt.i16                 eq, q1, %[alph255]                \n"
            "   vmovt.i16               q1, #256                          \n"
#endif

            "   vsub.i16                vecAlphaCompl, %q[vec256], q1     \n"
            /*  scale ch0 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan1 */
            "   vldrb.u16               q0, [%[pTargetCh1], %q[str4Offs]] \n"
            /*  blend ch0 vector with input ch0 color*/
            "   vmla.s16                q3, q1, %[c0]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"

            "   vstrb.16                q3, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  scale ch1 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan2 */
            "   vldrb.u16               q0, [%[pTargetCh2], %q[str4Offs]] \n"
            /*  blend ch1 vector with input ch1 color*/
            "   vmla.s16                q3, q1, %[c1]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh1], %q[str4Offs]] \n"

            "   adds                    %[pTargetCh0], #32                \n"
            "   adds                    %[pTargetCh1], #32                \n"

            /*  scale ch2 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  blend ch2 vector with input ch2 color*/
            "   vmla.s16                q3, q1, %[c2]                     \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8               \n"

            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh2], %q[str4Offs]] \n"

            "   add.w                   %[pTargetCh2], %[pTargetCh2], #32 \n"

            "   letp                    lr, 2b                            \n"
            "1:                                                           \n"

            " .unreq vecAlphaCompl                                        \n"

            :[pTargetCh0] "+r"(pTargetCh0),  [pTargetCh1] "+r"(pTargetCh1),
             [pTargetCh2] "+r"(pTargetCh2), [pAlpha] "+l" (pAlpha), [loopCnt] "+r"(blkCnt)
            :[vec256] "t" (v256),[str4Offs] "t" (vStride4Offs),
             [c0] "r"(c0), [c1] "r"(c1), [c2] "r"(c2)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            ,[alph255] "r" (255)
#endif
            :"q0", "q1", "q2", "q3", "memory", "cc");

#endif
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_a1_mask_opacity)(uint32_t * __RESTRICT pTarget,
                                                             int16_t iTargetStride,
                                                             uint8_t * __RESTRICT pchAlpha,
                                                             int16_t iAlphaStride,
                                                             int32_t nAlphaOffset,
                                                             arm_2d_size_t * __RESTRICT ptCopySize,
                                                             uint32_t Colour,
                                                             uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    uint16_t        c0, c1, c2;

    nAlphaOffset &= 0x07;
    iAlphaStride = (iAlphaStride + 7) & ~0x07;
    iAlphaStride >>= 3;


    /* 1-bit alpha relative byte location offsets */
    uint16x8_t      curA1Offs = vldrbq_u16(A1_expand_offs + nAlphaOffset);
    /* 1-bit alpha byte masks */
    uint16x8_t      curA1Masks = vldrbq_u16(A1_masks + nAlphaOffset);
    /* 1-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA1MasksShift =
        vnegq_s16(vldrbq_s16(A1_masks_shifts + nAlphaOffset));

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;


        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD_A1, _,
                                        CCCN888_SCAL_OPACITY_A1, vOpacity, 1/8, 254);
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_a2_mask_opacity)(uint32_t * __RESTRICT pTarget,
                                                             int16_t iTargetStride,
                                                             uint8_t * __RESTRICT pchAlpha,
                                                             int16_t iAlphaStride,
                                                             int32_t nAlphaOffset,
                                                             arm_2d_size_t * __RESTRICT ptCopySize,
                                                             uint32_t Colour,
                                                             uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    uint16_t        c0, c1, c2;

    nAlphaOffset &= 0x03;
    iAlphaStride = (iAlphaStride + 3) & ~0x03;
    iAlphaStride >>= 2;


    /* 2-bit alpha relative byte location offsets */
    uint16x8_t      curA2Offs = vldrbq_u16(A2_expand_offs + nAlphaOffset);
    /* 2-bit alpha byte masks */
    uint16x8_t      curA2Masks = vldrbq_u16(A2_masks + nAlphaOffset);
    /* 2-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA2MasksShift =
        vnegq_s16(vldrbq_s16(A2_masks_shifts + nAlphaOffset));

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;

        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD_A2, _,
                                        CCCN888_SCAL_OPACITY, vOpacity, 1/4, 254);

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}

__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_a4_mask_opacity)(uint32_t * __RESTRICT pTarget,
                                                             int16_t iTargetStride,
                                                             uint8_t * __RESTRICT pchAlpha,
                                                             int16_t iAlphaStride,
                                                             int32_t nAlphaOffset,
                                                             arm_2d_size_t * __RESTRICT ptCopySize,
                                                             uint32_t Colour,
                                                             uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    uint16_t        c0, c1, c2;

    nAlphaOffset &= 0x01;
    iAlphaStride = (iAlphaStride + 1) & ~0x01;
    iAlphaStride >>= 1;

    /* 4-bit alpha relative byte location offsets */
    uint16x8_t      curA4Offs = vldrbq_u16(A4_expand_offs + nAlphaOffset);
    /* 4-bit alpha byte masks */
    uint16x8_t      curA4Masks = vldrbq_u16(A4_masks + nAlphaOffset);
    /* 4-bit alpha byte shift, negated to be used with vector-based vector left shift */
    int16x8_t       curA4MasksShift =
        vnegq_s16(vldrbq_s16(A4_masks_shifts + nAlphaOffset));

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;


        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD_A4, _,
                                        CCCN888_SCAL_OPACITY, vOpacity, 1/2, 254);

        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_mask_opacity)(uint32_t * __RESTRICT pTarget,
                                                             int16_t iTargetStride,
                                                             uint8_t * __RESTRICT pchAlpha,
                                                             int16_t iAlphaStride,
                                                             arm_2d_size_t * __RESTRICT ptCopySize,
                                                             uint32_t Colour,
                                                             uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    uint16_t        c0, c1, c2;

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t * pAlpha = pchAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;

#ifdef USE_MVE_INTRINSICS

        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD, _,
                                        CCCN888_SCAL_OPACITY, vOpacity, 1, 254);
#else

        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
            "vecAlphaCompl            .req q2                             \n"

            ".p2align 2                                                   \n"
            /* expand chan0 */
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8               \n"
            "   vmulh.u8                q1, q1, %q[vOpacity]              \n"

            "   wlstp.16                lr, %[loopCnt], 1f                \n"
            "2:                                                           \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if vOpacity == 254, boost to 256 */
            "   vpt.i16                 eq, q1, %[opa254]                 \n"
            "   vmovt.i16               q1, #256                          \n"
#endif

            "   vsub.i16                vecAlphaCompl, %q[vec256], q1     \n"
            /*  scale ch0 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan1 */
            "   vldrb.u16               q0, [%[pTargetCh1], %q[str4Offs]] \n"
            /*  blend ch0 vector with input ch0 color*/
            "   vmla.s16                q3, q1, %[c0]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"

            "   vstrb.16                q3, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  scale ch1 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan2 */
            "   vldrb.u16               q0, [%[pTargetCh2], %q[str4Offs]] \n"
            /*  blend ch1 vector with input ch1 color*/
            "   vmla.s16                q3, q1, %[c1]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh1], %q[str4Offs]] \n"

            "   adds                    %[pTargetCh0], #32                \n"
            "   adds                    %[pTargetCh1], #32                \n"

            /*  scale ch2 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  blend ch2 vector with input ch2 color*/
            "   vmla.s16                q3, q1, %[c2]                     \n"
            "   vldrb.u16               q1, [%[pAlpha]], #8               \n"
            "   vmulh.u8                q1, q1, %q[vOpacity]              \n"

            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh2], %q[str4Offs]] \n"

            "   add.w                   %[pTargetCh2], %[pTargetCh2], #32 \n"

            "   letp                    lr, 2b                            \n"
            "1:                                                           \n"

            :[pTargetCh0] "+r"(pTargetCh0),  [pTargetCh1] "+r"(pTargetCh1),
             [pTargetCh2] "+r"(pTargetCh2), [pAlpha] "+l" (pAlpha), [loopCnt] "+r"(blkCnt)
            :[vec256] "t" (v256),[str4Offs] "t" (vStride4Offs),
             [vOpacity] "t"(vOpacity),
             [c0] "r"(c0), [c1] "r"(c1), [c2] "r"(c2)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
             ,[opa254] "r" (254)
#endif
            :"q0", "q1", "q2", "q3", "memory", "cc");

#endif
        pchAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_channel_mask)(uint32_t * __RESTRICT pTarget,
                                                       int16_t iTargetStride,
                                                       uint32_t * __RESTRICT pwAlpha,
                                                       int16_t iAlphaStride,
                                                       arm_2d_size_t * __RESTRICT ptCopySize,
                                                       uint32_t Colour)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint16_t        c0, c1, c2;

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t *pAlpha = (const uint8_t *)pwAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;

#ifdef USE_MVE_INTRINSICS

        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD_STRIDE, vStride4Offs,
                                        CCCN888_SCAL_OPACITY_NONE, _, 4, 255);
#else

        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
            "vecAlphaCompl            .req q2                             \n"

            ".p2align 2                                                   \n"
            /* expand chan0 */
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"
            "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]     \n"

            "   wlstp.16                lr, %[loopCnt], 1f                \n"
            "2:                                                           \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if alpha == 255, boost to 256 */
            "   vpt.i16                 eq, q1, %[alph255]                \n"
            "   vmovt.i16               q1, #256                          \n"
#endif
            "   vsub.i16                vecAlphaCompl, %q[vec256], q1     \n"

            /*  scale ch0 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan1 */
            "   vldrb.u16               q0, [%[pTargetCh1], %q[str4Offs]] \n"
            /*  blend ch0 vector with input ch0 color*/
            "   vmla.s16                q3, q1, %[c0]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"

            "   vstrb.16                q3, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  scale ch1 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan2 */
            "   vldrb.u16               q0, [%[pTargetCh2], %q[str4Offs]] \n"
            /*  blend ch1 vector with input ch1 color*/
            "   vmla.s16                q3, q1, %[c1]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh1], %q[str4Offs]] \n"

            "   adds                    %[pAlpha], #32                    \n"
            "   adds                    %[pTargetCh0], #32                \n"


            /*  scale ch2 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  blend ch2 vector with input ch2 color*/
            "   vmla.s16                q3, q1, %[c2]                     \n"
            "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]     \n"

            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh2], %q[str4Offs]] \n"

            "   adds                    %[pTargetCh1], #32                \n"
            "   adds                    %[pTargetCh2], #32                \n"

            "   letp                    lr, 2b                            \n"
            "1:                                                           \n"

            :[pTargetCh0] "+r"(pTargetCh0),  [pTargetCh1] "+r"(pTargetCh1),
             [pTargetCh2] "+r"(pTargetCh2), [pAlpha] "+r" (pAlpha), [loopCnt] "+r"(blkCnt)
            :[vec256] "t" (v256),[str4Offs] "t" (vStride4Offs),
             [c0] "r"(c0), [c1] "r"(c1), [c2] "r"(c2)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            ,[alph255] "r" (255)
#endif
            :"q0", "q1", "q2", "q3", "memory", "cc");

#endif
        pwAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}



__OVERRIDE_WEAK
void __MVE_WRAPPER( __arm_2d_impl_cccn888_colour_filling_channel_mask_opacity)(uint32_t * __RESTRICT pTarget,
                                                               int16_t iTargetStride,
                                                               uint32_t * __RESTRICT pwAlpha,
                                                               int16_t iAlphaStride,
                                                               arm_2d_size_t *
                                                               __RESTRICT ptCopySize,
                                                               uint32_t Colour,
                                                               uint_fast16_t hwOpacity)
{
    int_fast16_t    iHeight = ptCopySize->iHeight;
    int_fast16_t    iWidth = ptCopySize->iWidth;
    uint16x8_t      v256 = vdupq_n_u16(256);
    uint16x8_t      vStride4Offs = vidupq_n_u16(0, 4);
    uint8x16_t      vOpacity = vdupq_n_u8(hwOpacity);
    uint16_t        c0, c1, c2;

    c0 = Colour & 0xff;
    c1 = (Colour >> 8) & 0xff;
    c2 = (Colour >> 16) & 0xff;

    for (int_fast16_t y = 0; y < iHeight; y++) {
        const uint8_t  *pAlpha = (const uint8_t *)pwAlpha;
        uint8_t *       pTargetCh0 = (uint8_t*)pTarget;
        uint8_t *       pTargetCh1 = pTargetCh0 + 1;
        uint8_t *       pTargetCh2 = pTargetCh0 + 2;

#ifdef USE_MVE_INTRINSICS

        CCCN888_COLOUR_FILLING_MASK_INNER_MVE(CCCN888_TRGT_LOAD_STRIDE, vStride4Offs,
                                        CCCN888_SCAL_OPACITY, vOpacity, 4, 254);
#else

        register unsigned blkCnt __asm("lr");
        blkCnt = iWidth;

    __asm volatile(
            "vecAlphaCompl            .req q2                             \n"

            ".p2align 2                                                   \n"
            /* expand chan0 */
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"
            "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]     \n"
            "   vmulh.u8                q1, q1, %q[vOpacity]              \n"

            "   wlstp.16                lr, %[loopCnt], 1f                \n"
            "2:                                                           \n"

#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
            /* if vOpacity == 254, boost to 256 */
            "   vpt.i16                 eq, q1, %[opa254]                 \n"
            "   vmovt.i16               q1, #256                          \n"
#endif

            "   vsub.i16                vecAlphaCompl, %q[vec256], q1     \n"
            /*  scale ch0 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan1 */
            "   vldrb.u16               q0, [%[pTargetCh1], %q[str4Offs]] \n"
            /*  blend ch0 vector with input ch0 color*/
            "   vmla.s16                q3, q1, %[c0]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"

            "   vstrb.16                q3, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  scale ch1 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"

            /* expand chan2 */
            "   vldrb.u16               q0, [%[pTargetCh2], %q[str4Offs]] \n"
            /*  blend ch1 vector with input ch1 color*/
            "   vmla.s16                q3, q1, %[c1]                     \n"
            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh1], %q[str4Offs]] \n"

            "   adds                    %[pAlpha], #32                    \n"
            "   adds                    %[pTargetCh0], #32                \n"


            /*  scale ch2 vector with alpha vector */
            "   vmul.u16                q3, q0, vecAlphaCompl             \n"
            "   vldrb.u16               q0, [%[pTargetCh0], %q[str4Offs]] \n"

            /*  blend ch2 vector with input ch2 color*/
            "   vmla.s16                q3, q1, %[c2]                     \n"
            "   vldrb.u16               q1, [%[pAlpha], %q[str4Offs]]     \n"
            "   vmulh.u8                q1, q1, %q[vOpacity]              \n"

            "   vshr.u16                q3, q3, #8                        \n"
            "   vstrb.16                q3, [%[pTargetCh2], %q[str4Offs]] \n"

            "   adds                    %[pTargetCh1], #32                \n"
            "   adds                    %[pTargetCh2], #32                \n"

            "   letp                    lr, 2b                            \n"
            "1:                                                           \n"

            :[pTargetCh0] "+r"(pTargetCh0),  [pTargetCh1] "+r"(pTargetCh1),
             [pTargetCh2] "+r"(pTargetCh2), [pAlpha] "+r" (pAlpha), [loopCnt] "+r"(blkCnt)
            :[vec256] "t" (v256),[str4Offs] "t" (vStride4Offs), [vOpacity] "t"(vOpacity),
             [c0] "r"(c0), [c1] "r"(c1), [c2] "r"(c2)
#if !defined(__ARM_2D_CFG_UNSAFE_IGNORE_ALPHA_255_COMPENSATION__)
             ,[opa254] "r" (254)
#endif
            :"q0", "q1", "q2", "q3", "memory", "cc");

#endif
        pwAlpha += (iAlphaStride);
        pTarget += (iTargetStride);
    }
}


/* use macro expansion of fill/copy with masking */

#define __API_CAFWM_COLOUR                      gray8

#include "__arm_2d_ll_alpha_mask_helium.inc"

#define __API_CAFWM_CFG_1_HORIZONTAL_LINE       1
#define __API_CAFWM_COLOUR                      gray8

#include "__arm_2d_ll_alpha_mask_helium.inc"

#define __API_CAFWM_CFG_CHANNEL_8in32_SUPPORT   1
#define __API_CAFWM_COLOUR                      gray8

#include "__arm_2d_ll_alpha_mask_helium.inc"



#define __API_CAFWM_COLOUR                      rgb565

#include "__arm_2d_ll_alpha_mask_helium.inc"

#define __API_CAFWM_CFG_1_HORIZONTAL_LINE       1
#define __API_CAFWM_COLOUR                      rgb565

#include "__arm_2d_ll_alpha_mask_helium.inc"

#define __API_CAFWM_CFG_CHANNEL_8in32_SUPPORT   1
#define __API_CAFWM_COLOUR                      rgb565

#include "__arm_2d_ll_alpha_mask_helium.inc"




#define __API_CAFWM_COLOUR                      cccn888

#include "__arm_2d_ll_alpha_mask_helium.inc"

#define __API_CAFWM_CFG_1_HORIZONTAL_LINE       1
#define __API_CAFWM_COLOUR                      cccn888

#include "__arm_2d_ll_alpha_mask_helium.inc"

#define __API_CAFWM_CFG_CHANNEL_8in32_SUPPORT   1
#define __API_CAFWM_COLOUR                      cccn888

#include "__arm_2d_ll_alpha_mask_helium.inc"



/*----------------------------------------------------------------------------*
 * Assembly Patches                                                           *
 *----------------------------------------------------------------------------*/

#if defined(__IS_COMPILER_GCC__) && __IS_COMPILER_GCC__

__OVERRIDE_WEAK
void ARM_2D_WRAP_FUNC(  __MVE_WRAPPER( __arm_2d_impl_rgb565_masks_fill))(
                         uint16_t * __RESTRICT ptSourceBase,
                         int16_t iSourceStride,
                         arm_2d_size_t * __RESTRICT ptSourceSize,
                         uint8_t * __RESTRICT pchSourceMaskBase,
                         int16_t iSourceMaskStride,
                         arm_2d_size_t * __RESTRICT ptSourceMaskSize,
                         uint16_t * __RESTRICT ptTargetBase,
                         int16_t iTargetStride,
                         arm_2d_size_t * __RESTRICT ptTargetSize,
                         uint8_t * __RESTRICT pchTargetMaskBase,
                         int16_t iTargetMaskStride,
                         arm_2d_size_t * __RESTRICT ptTargetMaskSize)
{
    uint8_t        *__RESTRICT pchTargetMaskLineBase = pchTargetMaskBase;
    uint16x8_t      v256 = vdupq_n_u16(256);

#ifndef USE_MVE_INTRINSICS
    uint16x8_t      scratch[5];

    /* vector of 256 avoiding use of vdup to increase overlap efficiency*/
    vst1q((uint16_t *) & scratch[0], v256);
    /* scratch[1] is temporary for blended Red chan. vector */

    /* Unpacking Mask Red */
    vst1q((uint16_t *) & scratch[2], vdupq_n_u16(0x00fc));
    /* B channel packing mask */
    vst1q((uint16_t *) & scratch[3], vdupq_n_u16(0xf800));
    /* G channel packing Mask */
    vst1q((uint16_t *) & scratch[4], vdupq_n_u16(0x07e0));

    /* use of fixed point mult instead of vshr to increase overlap efficiency */
    const int16_t   inv_2pow3 = 1 << (15 - 3);  /* 1/(2^3) in Q.15 */
#endif

    for (int_fast16_t iTargetY = 0; iTargetY < ptTargetSize->iHeight;) {
        uint16_t       *__RESTRICT ptSource = ptSourceBase;
        uint8_t        *pchSourceMask = pchSourceMaskBase;
    #if __API_CAFWM_CFG_SUPPORT_SRC_MSK_WRAPING
        int_fast16_t    iSourceMaskY = 0;
    #endif

        for (int_fast16_t iSourceY = 0; iSourceY < ptSourceSize->iHeight; iSourceY++) {
            uint16_t       *__RESTRICT ptTarget = ptTargetBase;
            uint8_t        *__RESTRICT pchTargetMask = pchTargetMaskLineBase;
            uint_fast32_t   wLengthLeft = ptTargetSize->iWidth;

            do {
                uint_fast32_t   wLength = MIN(wLengthLeft, ptSourceSize->iWidth);
                uint16_t       *__RESTRICT ptSrc = ptSource;
                uint8_t        *__RESTRICT pchSrcMsk = pchSourceMask;
                uint16_t       *__RESTRICT ptTargetCur = ptTarget;
                uint8_t        *__RESTRICT pchTargetMaskCur = pchTargetMask;

#ifdef USE_MVE_INTRINSICS
                int32_t         blkCnt = wLength;

                do {
                    mve_pred16_t    pred = vctp16q(blkCnt);
                    uint16x8_t      vecTarget = vld1q_z(ptTargetCur, pred);
                    uint16x8_t      vecSource = vld1q_z(ptSrc, pred);
                    uint16x8_t      vecSrcMsk = vldrbq_z_u16(pchSrcMsk, pred);
                    uint16x8_t      vecTargetMask = vldrbq_z_u16(pchTargetMaskCur, pred);
                    uint16x8_t      vecHwOpacity =
                        vsubq_u16(v256, (vecSrcMsk * vecTargetMask) >> 8);

                    vecTarget = __arm_2d_rgb565_blending_opacity_single_vec(
                                                    vecTarget, vecSource, vecHwOpacity);
                    /* tail predication */
                    vst1q_p_u16(ptTargetCur, vecTarget, pred);

                    pchSrcMsk += 8;
                    pchTargetMaskCur += 8;
                    ptTargetCur += 8;
                    ptSrc += 8;

                    blkCnt -= 8;
                }
                while (blkCnt > 0);

#else
                register unsigned blkCnt __asm("lr");
                blkCnt = wLength;

                __asm volatile  (
                    /* R & B mask */
                    "vecRBUnpackMask    .req q7                               \n"
                    "vecAlpha           .req q5                               \n"
                    "vecHwOpacity       .req q3                               \n"

                    /* preload */
                    "   vldrb.u16           q0, [%[pchSrcMsk]], #8            \n"
                    "   vmov.i16            vecRBUnpackMask, #0x00f8          \n"
                    "   vldrb.u16           q5, [%[pchTargetMask]], #8        \n"

                    ".p2align 2                                               \n"
                    "   wlstp.16            lr, %[loopCnt], 1f                \n"
                    "2:                                                       \n"
                    /* vecSrcMsk * vecTargetMask */
                    "   vmul.i16            q0, q5, q0                        \n"
                    "   vldrh.u16           q6, [%[ptTarget]]                 \n"
                    "   vshr.u16            vecAlpha, q0, #8                  \n"
                    /* 256-dup vector */
                    "   vldrh.u16           q1, [%[scratch], #(16*0)]         \n"
                    /* vecHwOpacity =
                          vsubq_u16(v256, (vecSrcMsk * vecTargetMask) >> 8) */
                    "   vsub.i16            vecHwOpacity, q1, vecAlpha        \n"
                    "   vldrh.u16           q1, [%[ptSrc]], #16               \n"
                    /* mimic vshl #3 */
                    "   vshl.u16            q0, q6, #3                        \n"
                    "   vmul.i16            q4, q1, %[eight]                  \n"
                    /* vecR extract and scale */
                    "   vand                q0, q0, vecRBUnpackMask           \n"
                    "   vmul.i16            q0, vecHwOpacity, q0              \n"
                    /* vecSrcR extract and scale */
                    "   vand                q4, q4, vecRBUnpackMask           \n"
                    "   vmul.i16            q4, vecAlpha, q4                  \n"
                    /* 0xfc G-mask */
                    "   vldrw.u32           q2, [%[scratch], #(16*2)]         \n"
                    "   vadd.i16            q4, q0, q4                        \n"
                    /* push blended R  */
                    "   vstrw.32            q4, [%[scratch], #(16*1)]         \n"
                    /*  mimic vshr.u16            q4, q6, #3 */
                    "   vqdmulh.s16         q4, q6, %[inv_2pow3]              \n"
                    "   vshr.u16            q0, q1, #3                        \n"
                    /* vecG extract and scale */
                    "   vand                q4, q4, q2                        \n"
                    "   vmul.i16            q4, vecHwOpacity, q4              \n"
                    /* vecSrcG extract and scale */
                    "   vand                q0, q0, q2                        \n"
                    "   vmul.i16            q2, vecAlpha, q0                  \n"
                    "   vshr.u16            q0, q1, #8                        \n"
                    /* blended G */
                    /* vadd.i16            q2, q4, q2
                       addition using vmla for more efficient overlap */
                    "   vmla.s16            q2, q4, %[one]                    \n"
                    /* vecB extract and scale */
                    "   vshr.u16            q4, q6, #8                        \n"
                    "   vand                q4, q4, vecRBUnpackMask           \n"
                    "   vmul.i16            q4, vecHwOpacity, q4              \n"
                    /* vecSrcB extract and scale */
                    "   vand                q0, q0, vecRBUnpackMask           \n"
                    "   vmul.i16            q0, vecAlpha, q0                  \n"

                    ".unreq vecAlpha                                          \n"
                    ".unreq vecHwOpacity                                      \n"
                    ".unreq vecRBUnpackMask                                   \n"

                    /* reload blended R */
                    "   vldrw.u32           q1, [%[scratch], #(16*1)]         \n"
                    /* blended B
                       vadd.i16            q0, q4, q0
                       addition using vmla for more efficient overlap */
                    "   vmla.s16            q0, q4, %[one]                    \n"
                    /* pack R */
                    "   vshr.u16            q3, q1, #11                       \n"
                    /* B channel packing mask 0xf800 */
                    "   vldrw.u32           q4, [%[scratch], #(16*3)]         \n"
                    "   vand                q0, q0, q4                        \n"
                    /* accumulate R & B */
                    "   vorr                q4, q0, q3                        \n"
                    /* G channel packing mask 0x07e0 */
                    "   vldrw.u32           q3, [%[scratch], #(16*4)]         \n"
                    "   vshr.u16            q2, q2, #5                        \n"
                    /* load next source mask */
                    "   vldrb.u16           q0, [%[pchSrcMsk]], #8            \n"
                    /* G channel masking */
                    "   vand                q2, q2, q3                        \n"
                    /* load next target mask */
                    "   vldrb.u16           q5, [%[pchTargetMask]], #8        \n"
                    /* pack G with R.B */
                    "   vorr                q4, q4, q2                        \n"
                    "   vstrh.16            q4, [%[ptTarget]], #16            \n"
                    "   letp                lr, 2b                            \n"
                    "1:                                                       \n"
                    :[ptTarget] "+r"(ptTargetCur),[ptSrc] "+r"(ptSrc),
                     [pchTargetMask] "+l"(pchTargetMaskCur),[pchSrcMsk] "+l"(pchSrcMsk),
                     [loopCnt] "+r"(blkCnt)
                    :[scratch] "r"  (scratch),[eight] "r"(8),[inv_2pow3] "r"(inv_2pow3),
                     [one] "r" (1)
                    :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory", "r14");

#endif
                ptTarget += wLength;
                pchTargetMask += wLength;

                wLengthLeft -= wLength;
            } while (wLengthLeft);

            ptSource += iSourceStride;
            ptTargetBase += iTargetStride;
        #if __API_CAFWM_CFG_SUPPORT_SRC_MSK_WRAPING
            iSourceMaskY++;
            //! handle source mask
            if (    (iSourceMaskY >= ptSourceMaskSize->iHeight)
               ||   (iSourceMaskY >= ptSourceSize->iHeight)) {
                pchSourceMask = pchSourceMaskBase;
                iSourceMaskY = 0;
            } else {
                pchSourceMask += iSourceMaskStride;
            }
        #else
            pchSourceMask += iSourceMaskStride;
        #endif

            pchTargetMaskLineBase += iTargetMaskStride;

            iTargetY++;
            if (iTargetY >= ptTargetSize->iHeight) {
                break;
            }
        }
    }
}



__OVERRIDE_WEAK
void ARM_2D_WRAP_FUNC(  __MVE_WRAPPER( __arm_2d_impl_rgb565_src_msk_1h_des_msk_fill))(
                        uint16_t * __RESTRICT ptSourceBase,
                        int16_t iSourceStride,
                        arm_2d_size_t * __RESTRICT ptSourceSize,
                        uint8_t * __RESTRICT pchSourceMaskBase,
                        int16_t iSourceMaskStride,
                        arm_2d_size_t * __RESTRICT ptSourceMaskSize,
                        uint16_t * __RESTRICT ptTargetBase,
                        int16_t iTargetStride,
                        arm_2d_size_t * __RESTRICT ptTargetSize,
                        uint8_t * __RESTRICT pchTargetMaskBase,
                        int16_t iTargetMaskStride,
                        arm_2d_size_t * __RESTRICT ptTargetMaskSize)
{
    uint8_t        *__RESTRICT pchTargetMaskLineBase = pchTargetMaskBase;
    uint16x8_t      v256 = vdupq_n_u16(256);

#ifndef USE_MVE_INTRINSICS
    uint16x8_t      scratch[5];

    /* vector of 256 avoiding use of vdup to increase overlap efficiency*/
    vst1q((uint16_t *) & scratch[0], v256);
    /* scratch[1] is temporary for blended Red chan. vector */

    /* Unpacking Mask Red */
    vst1q((uint16_t *) & scratch[2], vdupq_n_u16(0x00fc));
    /* B channel packing mask */
    vst1q((uint16_t *) & scratch[3], vdupq_n_u16(0xf800));
    /* G channel packing Mask */
    vst1q((uint16_t *) & scratch[4], vdupq_n_u16(0x07e0));

    /* use of fixed point mult instead of vshr to increase overlap efficiency */
    const int16_t   inv_2pow3 = 1 << (15 - 3);  /* 1/(2^3) in Q.15 */
#endif

    for (int_fast16_t iTargetY = 0; iTargetY < ptTargetSize->iHeight;) {
        uint16_t       *__RESTRICT ptSource = ptSourceBase;
        uint8_t        *pchSourceMask = pchSourceMaskBase;
    #if __API_CAFWM_CFG_SUPPORT_SRC_MSK_WRAPING
        int_fast16_t    iSourceMaskY = 0;
    #endif

        for (int_fast16_t iSourceY = 0; iSourceY < ptSourceSize->iHeight; iSourceY++) {
            uint16_t       *__RESTRICT ptTarget = ptTargetBase;
            uint8_t        *__RESTRICT pchTargetMask = pchTargetMaskLineBase;
            uint_fast32_t   wLengthLeft = ptTargetSize->iWidth;

            do {
                uint_fast32_t   wLength = MIN(wLengthLeft, ptSourceSize->iWidth);
                uint16_t       *__RESTRICT ptSrc = ptSource;
                uint8_t        *__RESTRICT pchSrcMsk = pchSourceMask;
                uint16_t       *__RESTRICT ptTargetCur = ptTarget;
                uint8_t        *__RESTRICT pchTargetMaskCur = pchTargetMask;

#ifdef USE_MVE_INTRINSICS
                int32_t         blkCnt = wLength;

                do {
                    mve_pred16_t    pred = vctp16q(blkCnt);
                    uint16x8_t      vecTarget = vld1q_z(ptTargetCur, pred);
                    uint16x8_t      vecSource = vld1q_z(ptSrc, pred);
                    uint16x8_t      vecSrcMsk = vldrbq_z_u16(pchSrcMsk, pred);
                    uint16x8_t      vecTargetMask = vldrbq_z_u16(pchTargetMaskCur, pred);
                    uint16x8_t      vecHwOpacity =
                        vsubq_u16(v256, (vecSrcMsk * vecTargetMask) >> 8);

                    vecTarget = __arm_2d_rgb565_blending_opacity_single_vec(
                                                    vecTarget, vecSource, vecHwOpacity);
                    /* tail predication */
                    vst1q_p_u16(ptTargetCur, vecTarget, pred);

                    pchSrcMsk += 8;
                    pchTargetMaskCur += 8;
                    ptTargetCur += 8;
                    ptSrc += 8;

                    blkCnt -= 8;
                }
                while (blkCnt > 0);

#else
                register unsigned blkCnt __asm("lr");
                blkCnt = wLength;

                __asm volatile  (
                    /* R & B mask */
                    "vecRBUnpackMask    .req q7                               \n"
                    "vecAlpha           .req q5                               \n"
                    "vecHwOpacity       .req q3                               \n"

                    /* preload */
                    "   vldrb.u16           q0, [%[pchSrcMsk]], #8            \n"
                    "   vmov.i16            vecRBUnpackMask, #0x00f8          \n"
                    "   vldrb.u16           q5, [%[pchTargetMask]], #8        \n"

                    ".p2align 2                                               \n"
                    "   wlstp.16            lr, %[loopCnt], 1f                \n"
                    "2:                                                       \n"
                    /* vecSrcMsk * vecTargetMask */
                    "   vmul.i16            q0, q5, q0                        \n"
                    "   vldrh.u16           q6, [%[ptTarget]]                 \n"
                    "   vshr.u16            vecAlpha, q0, #8                  \n"
                    /* 256-dup vector */
                    "   vldrh.u16           q1, [%[scratch], #(16*0)]         \n"
                    /* vecHwOpacity =
                          vsubq_u16(v256, (vecSrcMsk * vecTargetMask) >> 8) */
                    "   vsub.i16            vecHwOpacity, q1, vecAlpha        \n"
                    "   vldrh.u16           q1, [%[ptSrc]], #16               \n"
                    /* mimic vshl #3 */
                    "   vshl.u16            q0, q6, #3                        \n"
                    "   vmul.i16            q4, q1, %[eight]                  \n"
                    /* vecR extract and scale */
                    "   vand                q0, q0, vecRBUnpackMask           \n"
                    "   vmul.i16            q0, vecHwOpacity, q0              \n"
                    /* vecSrcR extract and scale */
                    "   vand                q4, q4, vecRBUnpackMask           \n"
                    "   vmul.i16            q4, vecAlpha, q4                  \n"
                    /* 0xfc G-mask */
                    "   vldrw.u32           q2, [%[scratch], #(16*2)]         \n"
                    "   vadd.i16            q4, q0, q4                        \n"
                    /* push blended R  */
                    "   vstrw.32            q4, [%[scratch], #(16*1)]         \n"
                    /*  mimic vshr.u16            q4, q6, #3 */
                    "   vqdmulh.s16         q4, q6, %[inv_2pow3]              \n"
                    "   vshr.u16            q0, q1, #3                        \n"
                    /* vecG extract and scale */
                    "   vand                q4, q4, q2                        \n"
                    "   vmul.i16            q4, vecHwOpacity, q4              \n"
                    /* vecSrcG extract and scale */
                    "   vand                q0, q0, q2                        \n"
                    "   vmul.i16            q2, vecAlpha, q0                  \n"
                    "   vshr.u16            q0, q1, #8                        \n"
                    /* blended G */
                    /* vadd.i16            q2, q4, q2
                       addition using vmla for more efficient overlap */
                    "   vmla.s16            q2, q4, %[one]                    \n"
                    /* vecB extract and scale */
                    "   vshr.u16            q4, q6, #8                        \n"
                    "   vand                q4, q4, vecRBUnpackMask           \n"
                    "   vmul.i16            q4, vecHwOpacity, q4              \n"
                    /* vecSrcB extract and scale */
                    "   vand                q0, q0, vecRBUnpackMask           \n"
                    "   vmul.i16            q0, vecAlpha, q0                  \n"

                    ".unreq vecAlpha                                          \n"
                    ".unreq vecHwOpacity                                      \n"
                    ".unreq vecRBUnpackMask                                   \n"

                    /* reload blended R */
                    "   vldrw.u32           q1, [%[scratch], #(16*1)]         \n"
                    /* blended B
                       vadd.i16            q0, q4, q0
                       addition using vmla for more efficient overlap */
                    "   vmla.s16            q0, q4, %[one]                    \n"
                    /* pack R */
                    "   vshr.u16            q3, q1, #11                       \n"
                    /* B channel packing mask 0xf800 */
                    "   vldrw.u32           q4, [%[scratch], #(16*3)]         \n"
                    "   vand                q0, q0, q4                        \n"
                    /* accumulate R & B */
                    "   vorr                q4, q0, q3                        \n"
                    /* G channel packing mask 0x07e0 */
                    "   vldrw.u32           q3, [%[scratch], #(16*4)]         \n"
                    "   vshr.u16            q2, q2, #5                        \n"
                    /* load next source mask */
                    "   vldrb.u16           q0, [%[pchSrcMsk]], #8            \n"
                    /* G channel masking */
                    "   vand                q2, q2, q3                        \n"
                    /* load next target mask */
                    "   vldrb.u16           q5, [%[pchTargetMask]], #8        \n"
                    /* pack G with R.B */
                    "   vorr                q4, q4, q2                        \n"
                    "   vstrh.16            q4, [%[ptTarget]], #16            \n"
                    "   letp                lr, 2b                            \n"
                    "1:                                                       \n"
                    :[ptTarget] "+r"(ptTargetCur),[ptSrc] "+r"(ptSrc),
                     [pchTargetMask] "+l"(pchTargetMaskCur),[pchSrcMsk] "+l"(pchSrcMsk),
                     [loopCnt] "+r"(blkCnt)
                    :[scratch] "r"  (scratch),[eight] "r"(8),[inv_2pow3] "r"(inv_2pow3),
                     [one] "r" (1)
                    :"q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "memory", "r14");

#endif
                ptTarget += wLength;
                pchTargetMask += wLength;

                wLengthLeft -= wLength;
            } while (wLengthLeft);

            ptSource += iSourceStride;
            ptTargetBase += iTargetStride;
        #if __API_CAFWM_CFG_SUPPORT_SRC_MSK_WRAPING
            iSourceMaskY++;
            //! handle source mask
            if (    (iSourceMaskY >= ptSourceMaskSize->iHeight)
               ||   (iSourceMaskY >= ptSourceSize->iHeight)) {
                pchSourceMask = pchSourceMaskBase;
                iSourceMaskY = 0;
            } else {
                pchSourceMask += iSourceMaskStride;
            }
        #else
            pchSourceMask += iSourceMaskStride;
        #endif

            pchTargetMaskLineBase = pchTargetMaskBase;

            iTargetY++;
            if (iTargetY >= ptTargetSize->iHeight) {
                break;
            }
        }
    }
}

#endif

#ifdef   __cplusplus
}
#endif

#endif // __ARM_2D_HAS_HELIUM__
