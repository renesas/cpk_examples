/*
 * Copyright (c) 2009-2024 Arm Limited. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*============================ INCLUDES ======================================*/
#define __SPIN_ZOOM_WIDGET_IMPLEMENT__

#include "./arm_2d_example_controls.h"
#include "./__common.h"
#include "arm_2d.h"
#include "arm_2d_helper.h"
#include "spin_zoom_widget.h"
#include <assert.h>
#include <string.h>

#if defined(RTE_Acceleration_Arm_2D_Transform)

#if defined(__clang__)
#   pragma clang diagnostic push
#   pragma clang diagnostic ignored "-Wunknown-warning-option"
#   pragma clang diagnostic ignored "-Wreserved-identifier"
#   pragma clang diagnostic ignored "-Wdeclaration-after-statement"
#   pragma clang diagnostic ignored "-Wsign-conversion"
#   pragma clang diagnostic ignored "-Wpadded"
#   pragma clang diagnostic ignored "-Wcast-qual"
#   pragma clang diagnostic ignored "-Wcast-align"
#   pragma clang diagnostic ignored "-Wmissing-field-initializers"
#   pragma clang diagnostic ignored "-Wgnu-zero-variadic-macro-arguments"
#   pragma clang diagnostic ignored "-Wmissing-braces"
#   pragma clang diagnostic ignored "-Wunused-const-variable"
#   pragma clang diagnostic ignored "-Wmissing-declarations"
#   pragma clang diagnostic ignored "-Wmissing-variable-declarations"
#endif

/*============================ MACROS ========================================*/

#if __GLCD_CFG_COLOUR_DEPTH__ == 8


#elif __GLCD_CFG_COLOUR_DEPTH__ == 16


#elif __GLCD_CFG_COLOUR_DEPTH__ == 32

#else
#   error Unsupported colour depth!
#endif

#undef this
#define this    (*ptThis)

/*============================ MACROFIED FUNCTIONS ===========================*/
/*============================ TYPES =========================================*/
/*============================ PROTOTYPES ====================================*/

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_fill_colour( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);


static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_fill_colour_with_target_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_and_source_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_source_mask_and_target_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_and_target_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_tile_with_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_tile_only( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_tile_colour_keying( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity);

/*============================ LOCAL VARIABLES ===============================*/
/*============================ GLOBAL VARIABLES ==============================*/

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_FILL_COLOUR = {
    .fnTransform = &__spin_zoom_widget_transform_mode_fill_colour,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_FILL_COLOUR_WITH_TARGET_MASK = {
    .fnTransform = &__spin_zoom_widget_transform_mode_fill_colour_with_target_mask,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_EXTRA_TILE_COPY_WITH_TRANSFORMED_MASK_SOURCE_MASK_AND_TARGET_MASK = {
    .fnTransform = &__spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_source_mask_and_target_mask,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_EXTRA_TILE_COPY_WITH_TRANSFORMED_MASK_AND_SOURCE_MASK = {
    .fnTransform = &__spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_and_source_mask,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_EXTRA_TILE_COPY_WITH_TRANSFORMED_MASK_AND_TARGET_MASK = {
    .fnTransform = &__spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_and_target_mask,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_EXTRA_TILE_COPY_WITH_TRANSFORMED_MASK = {
    .fnTransform = &__spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_TILE_WITH_MASK = {
    .fnTransform = &__spin_zoom_widget_transform_mode_tile_with_mask,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_TILE_ONLY = {
    .fnTransform = &__spin_zoom_widget_transform_mode_tile_only,
};

spin_zoom_widget_mode_t SPIN_ZOOM_MODE_TILE_WITH_COLOUR_KEYING = {
    .fnTransform = &__spin_zoom_widget_transform_mode_tile_colour_keying,
};

/*============================ IMPLEMENTATION ================================*/

ARM_NONNULL(1,2)
void spin_zoom_widget_init( spin_zoom_widget_t *ptThis,
                            spin_zoom_widget_cfg_t *ptCFG)
{
    assert(NULL!= ptThis);
    memset(ptThis, 0, sizeof(spin_zoom_widget_t));
    this.tCFG = *ptCFG;

    /* initialize op */
    ARM_2D_OP_INIT(this.OPCODE);
}

ARM_NONNULL(1)
void spin_zoom_widget_depose( spin_zoom_widget_t *ptThis)
{
    assert(NULL != ptThis);
    
    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_depose(&this.tHelper);
    }

    /* depose op */
    ARM_2D_OP_DEPOSE(this.OPCODE);
}

ARM_NONNULL(1)
void spin_zoom_widget_on_load( spin_zoom_widget_t *ptThis)
{
    assert(NULL != ptThis);

    float fAngleStep = 0.05f;
    float fScaleStep = 0.01f;

    if (this.tCFG.Indicator.Step.fAngle > 0.0f) {
        fAngleStep = this.tCFG.Indicator.Step.fAngle;
    }

    if (this.tCFG.Indicator.Step.fScale > 0.0f) {
        fScaleStep = this.tCFG.Indicator.Step.fScale;
    }
    
    if (NULL != this.tCFG.ptScene) {
        /* initialize transform helper */
        arm_2d_helper_dirty_region_transform_init(
                                    &this.tHelper,
                                    &this.tCFG.ptScene->tDirtyRegionHelper,
                                    (arm_2d_op_t *)&this.OPCODE,
                                    fAngleStep,
                                    fScaleStep);
    }
}

ARM_NONNULL(1)
void spin_zoom_widget_on_frame_start_xy(spin_zoom_widget_t *ptThis, 
                                        int32_t nValue, 
                                        float fScaleX, 
                                        float fScaleY)
{
    assert(NULL != ptThis);
    
    int32_t nDelta = nValue - this.tCFG.Indicator.LowerLimit.nValue;
    float fDegreeDistance = this.tCFG.Indicator.UpperLimit.fAngleInDegree
                          - this.tCFG.Indicator.LowerLimit.fAngleInDegree;
    int32_t nValueDistance = this.tCFG.Indicator.UpperLimit.nValue
                           - this.tCFG.Indicator.LowerLimit.nValue;
    
    float fAngle = (((float)nDelta / (float)nValueDistance) * fDegreeDistance)
                 + this.tCFG.Indicator.LowerLimit.fAngleInDegree
                 + this.Request.fAngleOffset;

    /* update helper with new values*/
    arm_2d_helper_dirty_region_transform_update_value(&this.tHelper, fAngle, fScaleX, fScaleY);

    /* call helper's on-frame-start event handler */
    arm_2d_helper_dirty_region_transform_on_frame_start(&this.tHelper);

    if (NULL != this.Request.ptTransformMode) {
        this.tCFG.ptTransformMode = this.Request.ptTransformMode;
        this.Request.ptTransformMode = NULL;
    }
}

ARM_NONNULL(1)
void spin_zoom_widget_on_frame_start( spin_zoom_widget_t *ptThis, int32_t nValue, float fScale)
{
    spin_zoom_widget_on_frame_start_xy(ptThis, nValue, fScale, fScale);
}

static
float __spin_zoom_valid_value(spin_zoom_widget_t *ptThis, float fValue)
{
    if (this.tCFG.bValueSaturation) {
        float fLowLimit = this.tCFG.Indicator
                                    .LowerLimit
                                        .nValue;

        float fUpperLimit = this.tCFG.Indicator
                                    .UpperLimit
                                        .nValue;
        
        fValue = MAX(fValue, fLowLimit);
        fValue = MIN(fValue, fUpperLimit);
    }

    return fValue;
}

ARM_NONNULL(1)
float spin_zoom_valid_value(spin_zoom_widget_t *ptThis, float fValue)
{
    assert(NULL != ptThis);
    return __spin_zoom_valid_value(ptThis, fValue);
}

ARM_NONNULL(1)
void spin_zoom_widget_on_frame_start_xy_f32(spin_zoom_widget_t *ptThis, 
                                            float fValue, 
                                            float fScaleX, 
                                            float fScaleY)
{
    assert(NULL != ptThis);
    
    fValue = __spin_zoom_valid_value(ptThis, fValue);

    float fDelta = fValue - (float)this.tCFG.Indicator.LowerLimit.nValue;
    float fDegreeDistance = this.tCFG.Indicator.UpperLimit.fAngleInDegree
                          - this.tCFG.Indicator.LowerLimit.fAngleInDegree;
    int32_t nValueDistance = this.tCFG.Indicator.UpperLimit.nValue
                           - this.tCFG.Indicator.LowerLimit.nValue;
    
    float fAngle = ((fDelta / (float)nValueDistance) * fDegreeDistance)
                 + this.tCFG.Indicator.LowerLimit.fAngleInDegree
                 + this.Request.fAngleOffset;

    /* update helper with new values*/
    arm_2d_helper_dirty_region_transform_update_value(&this.tHelper, fAngle, fScaleX, fScaleY);

    /* call helper's on-frame-start event handler */
    arm_2d_helper_dirty_region_transform_on_frame_start(&this.tHelper);

    if (NULL != this.Request.ptTransformMode) {
        this.tCFG.ptTransformMode = this.Request.ptTransformMode;
        this.Request.ptTransformMode = NULL;
    }
}

ARM_NONNULL(1)
void spin_zoom_widget_on_frame_start_f32( spin_zoom_widget_t *ptThis, float fValue, float fScale)
{
    spin_zoom_widget_on_frame_start_xy_f32(ptThis, fValue, fScale, fScale);
}

ARM_NONNULL(1)
void spin_zoom_widget_on_frame_complete(spin_zoom_widget_t *ptThis)
{
    assert(NULL != ptThis);

}

ARM_NONNULL(1,2)
void spin_zoom_widget_update_transform_mode(
                                    spin_zoom_widget_t *ptThis, 
                                    spin_zoom_widget_mode_t *ptTransformMode)
{
    assert(NULL != ptThis);
    assert(NULL != ptTransformMode);

    this.Request.ptTransformMode = ptTransformMode;
}

ARM_NONNULL(1)
void spin_zoom_widget_set_angle_offset(
                                    spin_zoom_widget_t *ptThis, 
                                    float fAngleOffset)
{
    assert(NULL != ptThis);

    this.Request.fAngleOffset = fAngleOffset;
}


ARM_NONNULL(1,2)
void spin_zoom_widget_show_with_normal_pivot(   spin_zoom_widget_t *ptThis,
                                                const arm_2d_tile_t *ptTile,
                                                const arm_2d_region_t *ptRegion,
                                                const arm_2d_location_t *ptPivot,
                                                uint8_t chOpacity)
{
    if (-1 == (intptr_t)ptTile) {
        ptTile = arm_2d_get_default_frame_buffer();
    }

    if (NULL == ptTile) {
        return ;
    }

    assert(NULL != ptThis);
    assert(NULL != this.tCFG.ptTransformMode);

    arm_2d_point_float_t tPivot;
    arm_2d_point_float_t *ptPivotFloat = NULL;
    if (NULL != ptPivot) {
        tPivot.fX = ptPivot->iX;
        tPivot.fY = ptPivot->iY;
        ptPivotFloat = &tPivot;
    }
    
    ARM_2D_INVOKE( this.tCFG.ptTransformMode->fnTransform,
        ARM_2D_PARAM(
            ptThis, 
            ptTile,
            ptRegion,
            ptPivotFloat,
            chOpacity
        ));
}

ARM_NONNULL(1,2)
void spin_zoom_widget_show_with_fp_pivot( spin_zoom_widget_t *ptThis,
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    if (-1 == (intptr_t)ptTile) {
        ptTile = arm_2d_get_default_frame_buffer();
    }

    if (NULL == ptTile) {
        return ;
    }

    assert(NULL != ptThis);
    assert(NULL != this.tCFG.ptTransformMode);
    
    ARM_2D_INVOKE( this.tCFG.ptTransformMode->fnTransform,
        ARM_2D_PARAM(
            ptThis, 
            ptTile,
            ptRegion,
            ptPivot,
            chOpacity
        ));
}

ARM_NONNULL(1)
void spin_zoom_widget_set_colour( spin_zoom_widget_t *ptThis, COLOUR_INT tColour)
{
    assert(NULL != ptThis);
    this.tCFG.Source.tColourToFill = tColour;
}

ARM_NONNULL(1)
void spin_zoom_widget_set_source(   spin_zoom_widget_t  *ptThis, 
                                    const arm_2d_tile_t *ptSource,
                                    const arm_2d_tile_t *ptMask,
                                    arm_2d_location_t   tCentre)
{
    assert(NULL != ptThis);

    this.tCFG.Source.ptMask = ptMask;
    this.tCFG.Source.ptSource = ptSource;
    this.tCFG.Source.tCentre = tCentre;
    this.tCFG.bUseFloatPointInCentre = false;
}

ARM_NONNULL(1)
void spin_zoom_widget_set_source_f32(   spin_zoom_widget_t *ptThis, 
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptMask,
                                        arm_2d_point_float_t tCentre)
{
    assert(NULL != ptThis);

    this.tCFG.Source.ptMask = ptMask;
    this.tCFG.Source.ptSource = ptSource;
    this.tCFG.Source.tCentreFloat = tCentre;
    this.tCFG.bUseFloatPointInCentre = true;
}



ARM_NONNULL(1)
float spin_zoom_widget_get_current_angle(spin_zoom_widget_t *ptThis)
{
    assert(NULL != ptThis);
    return this.tHelper.fAngle - this.Request.fAngleOffset;
}

ARM_NONNULL(1)
float spin_zoom_widget_get_actual_angle(spin_zoom_widget_t *ptThis)
{
    assert(NULL != ptThis);
    return this.tHelper.fAngle;
}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_fill_colour_with_target_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    /* draw pointer */
    arm_2dp_fill_colour_with_transformed_mask_target_mask_and_opacity(
            &this.OPCODE.tFillColourTransformTargetMask,
            this.tCFG.Source.ptMask,
            ptTile,
            this.tCFG.Target.ptMask,
            ptRegion,
            tCentre,
            ARM_2D_ANGLE(this.tHelper.fAngle),
            this.tHelper.fScaleX,
            this.tHelper.fScaleY,
            this.tCFG.Source.tColourToFill,
            chOpacity,
            ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;

}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_source_mask_and_target_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    arm_2dp_tile_copy_with_transformed_mask_source_mask_target_mask_and_opacity(
            &this.OPCODE.tTileCopyWithTransformedMask,
            this.tCFG.Source.ptMask,
            this.tCFG.Extra.ptTile,
            this.tCFG.Extra.ptMask,
            ptTile,
            this.tCFG.Target.ptMask,
            ptRegion,
            tCentre,
            ARM_2D_ANGLE(this.tHelper.fAngle),
            this.tHelper.fScaleX,
            this.tHelper.fScaleY,
            chOpacity,
            ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;
}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_and_target_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    arm_2dp_tile_copy_with_transformed_mask_target_mask_and_opacity(
            &this.OPCODE.tTileCopyWithTransformedMask,
            this.tCFG.Source.ptMask,
            this.tCFG.Extra.ptTile,
            ptTile,
            this.tCFG.Target.ptMask,
            ptRegion,
            tCentre,
            ARM_2D_ANGLE(this.tHelper.fAngle),
            this.tHelper.fScaleX,
            this.tHelper.fScaleY,
            chOpacity,
            ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;
}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask_and_source_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    arm_2dp_tile_copy_with_transformed_mask_source_mask_and_opacity(
            &this.OPCODE.tTileCopyWithTransformedMask,
            this.tCFG.Source.ptMask,
            this.tCFG.Extra.ptTile,
            this.tCFG.Extra.ptMask,
            ptTile,
            ptRegion,
            tCentre,
            ARM_2D_ANGLE(this.tHelper.fAngle),
            this.tHelper.fScaleX,
            this.tHelper.fScaleY,
            chOpacity,
            ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;
}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_extra_tile_copy_with_transformed_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    arm_2dp_tile_copy_with_transformed_mask_and_opacity(
            &this.OPCODE.tTileCopyWithTransformedMask,
            this.tCFG.Source.ptMask,
            this.tCFG.Extra.ptTile,
            ptTile,
            ptRegion,
            tCentre,
            ARM_2D_ANGLE(this.tHelper.fAngle),
            this.tHelper.fScaleX,
            this.tHelper.fScaleY,
            chOpacity,
            ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;
}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_fill_colour( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    /* draw pointer */
    arm_2dp_fill_colour_with_mask_opacity_and_transform_xy(
                        &this.OPCODE.tFillColourTransform,
                        this.tCFG.Source.ptMask,
                        ptTile,
                        ptRegion,
                        tCentre,
                        ARM_2D_ANGLE(this.tHelper.fAngle),
                        this.tHelper.fScaleX,
                        this.tHelper.fScaleY,
                        this.tCFG.Source.tColourToFill,
                        chOpacity,
                        ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;

}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_tile_with_mask( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    arm_2dp_tile_transform_xy_with_src_mask_and_opacity(
                                                &this.OPCODE.tTileTransform,
                                                this.tCFG.Source.ptSource,
                                                this.tCFG.Source.ptMask,
                                                ptTile,
                                                ptRegion,
                                                tCentre,
                                                ARM_2D_ANGLE(this.tHelper.fAngle),
                                                this.tHelper.fScaleX,
                                                this.tHelper.fScaleY,
                                                chOpacity,
                                                ptPivot);
    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;

}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_tile_only( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    arm_2dp_tile_transform_xy_only_with_opacity(&this.OPCODE.tTile,
                                                this.tCFG.Source.ptSource,
                                                ptTile,
                                                ptRegion,
                                                tCentre,
                                                ARM_2D_ANGLE(this.tHelper.fAngle),
                                                this.tHelper.fScaleX,
                                                this.tHelper.fScaleY,
                                                chOpacity,
                                                ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;

}

static
arm_fsm_rt_t __spin_zoom_widget_transform_mode_tile_colour_keying( 
                                            spin_zoom_widget_t *ptThis, 
                                            const arm_2d_tile_t *ptTile,
                                            const arm_2d_region_t *ptRegion,
                                            const arm_2d_point_float_t *ptPivot,
                                            uint8_t chOpacity)
{
    assert(NULL != ptThis);
    assert(NULL != ptTile);

    bool bIsNewFrame = (ARM_2D_RT_FALSE != arm_2d_target_tile_is_new_frame(ptTile));

    arm_2d_point_float_t tCentre = this.tCFG.Source.tCentreFloat;
    if (!this.tCFG.bUseFloatPointInCentre) {
        tCentre.fX = this.tCFG.Source.tCentre.iX;
        tCentre.fY = this.tCFG.Source.tCentre.iY;
    }

    arm_2dp_tile_transform_xy_with_opacity( &this.OPCODE.tTile,
                                            this.tCFG.Source.ptSource,
                                            ptTile,
                                            ptRegion,
                                            tCentre,
                                            ARM_2D_ANGLE(this.tHelper.fAngle),
                                            this.tHelper.fScaleX,
                                            this.tHelper.fScaleY,
                                            this.tCFG.Source.tColourForKeying,
                                            chOpacity,
                                            ptPivot);

    if (NULL != this.tCFG.ptScene) {
        arm_2d_helper_dirty_region_transform_update(&this.tHelper,
                                                    ptRegion,
                                                    bIsNewFrame);
    }

    ARM_2D_OP_WAIT_ASYNC(&this.OPCODE);

    return arm_fsm_rt_cpl;

}

#if defined(__clang__)
#   pragma clang diagnostic pop
#endif

#else

spin_zoom_widget_mode_t __SPIN_ZOOM_MODE_NULL = {0};

#endif /* defined(RTE_Acceleration_Arm_2D_Transform) */
