/*
 * Copyright (C) 2022 Arm Limited or its affiliates. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ----------------------------------------------------------------------
 * Project:      Arm-2D Library
 * Title:        arm_2d_alpha_blending.h
 * Description:  Public header file to contain the alpha related APIs
 *
 * $Date:        02 Dec 2025
 * $Revision:    V.1.15.0
 *
 * Target Processor:  Cortex-M cores
 * -------------------------------------------------------------------- */
 
#ifndef __ARM_2D_ALPHA_BLENDING_H__
#define __ARM_2D_ALPHA_BLENDING_H__

/*============================ INCLUDES ======================================*/

#include "arm_2d_types.h"

#ifdef   __cplusplus
extern "C" {
#endif

#if defined(__clang__)
#   pragma clang diagnostic push
#   pragma clang diagnostic ignored "-Wunknown-warning-option"
#   pragma clang diagnostic ignored "-Wreserved-identifier"
#   pragma clang diagnostic ignored "-Wmissing-declarations"
#   pragma clang diagnostic ignored "-Wpadded"
#   pragma clang diagnostic ignored "-Wc11-extensions"
#endif

/*============================ MACROS ========================================*/

/*!
 * \addtogroup Deprecated
 * @{
 */
#define arm_2d_rgb565_fill_colour_with_alpha                                    \
            arm_2d_rgb565_fill_colour_with_opacity

#define arm_2d_rgb888_fill_colour_with_alpha                                    \
            arm_2d_rgb888_fill_colour_with_opacity

#define arm_2d_cccn888_fill_colour_with_alpha                                   \
            arm_2d_cccn888_fill_colour_with_opacity

#define arm_2d_gray8_fill_colour_with_alpha_mask                                \
            arm_2d_gray8_fill_colour_with_mask

#define arm_2d_rgb565_fill_colour_with_alpha_mask                               \
            arm_2d_rgb565_fill_colour_with_mask

#define arm_2d_rgb888_fill_colour_with_alpha_mask                               \
            arm_2d_rgb888_fill_colour_with_mask

#define arm_2d_cccn888_fill_colour_with_alpha_mask                              \
            arm_2d_cccn888_fill_colour_with_mask

#define arm_2d_gray8_fill_colour_with_alpha_mask_and_opacity                    \
            arm_2d_gray8_fill_colour_with_mask_and_opacity

#define arm_2d_rgb565_fill_colour_with_alpha_mask_and_opacity                   \
            arm_2d_rgb565_fill_colour_with_mask_and_opacity

#define arm_2d_rgb888_fill_colour_with_alpha_mask_and_opacity                   \
            arm_2d_rgb888_fill_colour_with_mask_and_opacity

#define arm_2d_cccn888_fill_colour_with_alpha_mask_and_opacity                  \
            arm_2d_cccn888_fill_colour_with_mask_and_opacity

#define arm_2d_gray8_alpha_blending_with_colour_masking                         \
            arm_2d_gray8_tile_copy_with_colour_keying_and_opacity

#define arm_2d_rgb565_alpha_blending_with_colour_masking                        \
            arm_2d_rgb565_tile_copy_with_colour_keying_and_opacity

#define arm_2d_rgb888_alpha_blending_with_colour_masking                        \
            arm_2d_rgb888_tile_copy_with_colour_keying_and_opacity

#define arm_2d_cccn888_alpha_blending_with_colour_masking                       \
            arm_2d_cccn888_tile_copy_with_colour_keying_and_opacity

#define arm_2d_gray8_tile_copy_with_alpha_masks                                 \
            arm_2d_gray8_tile_copy_with_masks

#define arm_2d_rgb565_tile_copy_with_alpha_masks                                \
            arm_2d_rgb565_tile_copy_with_masks

#define arm_2d_cccn888_tile_copy_with_alpha_masks                               \
            arm_2d_cccn888_tile_copy_with_masks

#define arm_2d_rgb888_tile_copy_with_alpha_mask                                 \
            arm_2d_rgb888_tile_copy_with_masks


#define arm_2dp_gray8_alpha_blending    arm_2dp_gray8_tile_copy_with_opacity_only
#define arm_2dp_rgb565_alpha_blending   arm_2dp_rgb565_tile_copy_with_opacity_only
#define arm_2dp_cccn888_alpha_blending  arm_2dp_cccn888_tile_copy_with_opacity_only
#define arm_2dp_rgb888_alpha_blending   arm_2dp_cccn888_tile_copy_with_opacity_only
#define arm_2d_gray8_alpha_blending     arm_2d_gray8_tile_copy_with_opacity_only
#define arm_2d_rgb565_alpha_blending    arm_2d_rgb565_tile_copy_with_opacity_only
#define arm_2d_cccn888_alpha_blending   arm_2d_cccn888_tile_copy_with_opacity_only
#define arm_2d_rgb888_alpha_blending    arm_2d_cccn888_tile_copy_with_opacity_only

#define arm_2d_gray8_tile_copy_with_opacity     arm_2d_gray8_tile_copy_with_opacity_only
#define arm_2d_rgb565_tile_copy_with_opacity    arm_2d_rgb565_tile_copy_with_opacity_only
#define arm_2d_rgb888_tile_copy_with_opacity    arm_2d_rgb888_tile_copy_with_opacity_only
#define arm_2d_cccn888_tile_copy_with_opacity   arm_2d_cccn888_tile_copy_with_opacity_only

#define arm_2dp_gray8_tile_copy_with_opacity    arm_2dp_gray8_tile_copy_with_opacity_only
#define arm_2dp_rgb565_tile_copy_with_opacity   arm_2dp_rgb565_tile_copy_with_opacity_only
#define arm_2dp_cccn888_tile_copy_with_opacity  arm_2dp_cccn888_tile_copy_with_opacity_only

#define arm_2dp_gray8_alpha_blending_with_colour_keying                         \
            arm_2dp_gray8_tile_copy_with_colour_keying_and_opacity
#define arm_2dp_rgb565_alpha_blending_with_colour_keying                        \
            arm_2dp_rgb565_tile_copy_with_colour_keying_and_opacity
#define arm_2dp_cccn888_alpha_blending_with_colour_keying                       \
            arm_2dp_cccn888_tile_copy_with_colour_keying_and_opacity
#define arm_2d_gray8_alpha_blending_with_colour_keying                          \
            arm_2d_gray8_tile_copy_with_colour_keying_and_opacity
#define arm_2d_rgb565_alpha_blending_with_colour_keying                         \
            arm_2d_rgb565_tile_copy_with_colour_keying_and_opacity
#define arm_2d_cccn888_alpha_blending_with_colour_keying                        \
            arm_2d_cccn888_tile_copy_with_colour_keying_and_opacity

/*! @} */

/*!
 * \addtogroup gAlpha 4 Alpha Blending Operations
 * @{
 */

/*============================ MACROFIED FUNCTIONS ===========================*/

#define arm_2d_gray8_tile_copy_with_opacity_only(                               \
                                        __SRC_ADDR,   /* source tile address */ \
                                        __DES_ADDR,   /* target tile address */ \
                                        __REGION_ADDR,/* region address */      \
                                        __ALPHA)      /* alpha */               \
            arm_2dp_gray8_tile_copy_with_opacity_only(  NULL,                   \
                                            (__SRC_ADDR),                       \
                                            (__DES_ADDR),                       \
                                            (__REGION_ADDR),                    \
                                            (__ALPHA))

#define arm_2d_rgb565_tile_copy_with_opacity_only(                              \
                                        __SRC_ADDR,   /* source tile address */ \
                                        __DES_ADDR,   /* target tile address */ \
                                        __REGION_ADDR,/* region address */      \
                                        __ALPHA)      /* alpha */               \
            arm_2dp_rgb565_tile_copy_with_opacity_only(  NULL,                  \
                                            (__SRC_ADDR),                       \
                                            (__DES_ADDR),                       \
                                            (__REGION_ADDR),                    \
                                            (__ALPHA))
                                            
#define arm_2d_rgb888_tile_copy_with_opacity_only(                              \
                                        __SRC_ADDR,   /* source tile address */ \
                                        __DES_ADDR,   /* target tile address */ \
                                        __REGION_ADDR,/* region address */      \
                                        __ALPHA)      /* alpha */               \
            arm_2dp_cccn888_tile_copy_with_opacity_only(  NULL,                 \
                                            (__SRC_ADDR),                       \
                                            (__DES_ADDR),                       \
                                            (__REGION_ADDR),                    \
                                            (__ALPHA))

#define arm_2d_cccn888_tile_copy_with_opacity_only(                             \
                                        __SRC_ADDR,   /* source tile address */ \
                                        __DES_ADDR,   /* target tile address */ \
                                        __REGION_ADDR,/* region address */      \
                                        __ALPHA)      /* alpha */               \
            arm_2dp_cccn888_tile_copy_with_opacity_only(  NULL,                 \
                                            (__SRC_ADDR),                       \
                                            (__DES_ADDR),                       \
                                            (__REGION_ADDR),                    \
                                            (__ALPHA))


#define arm_2d_gray8_fill_colour_with_opacity(                                  \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __COLOUR,     /*   colour */              \
                                      __ALPHA)      /*   alpha */               \
            arm_2dp_gray8_fill_colour_with_opacity(  NULL,                      \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__COLOUR),                    \
                                                 (__ALPHA))

#define arm_2d_rgb565_fill_colour_with_opacity(                                 \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __COLOUR,     /*   colour */              \
                                      __ALPHA)      /*   alpha */               \
            arm_2dp_rgb565_fill_colour_with_opacity(  NULL,                     \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__COLOUR),                    \
                                                 (__ALPHA))

#define arm_2d_rgb888_fill_colour_with_opacity(                                 \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __COLOUR,     /*   colour */              \
                                      __ALPHA)      /*   alpha */               \
            arm_2dp_cccn888_fill_colour_with_opacity(  NULL,                    \
                                 (__DES_ADDR),                                  \
                                 (__REGION_ADDR),                               \
                                 (arm_2d_color_cccn888_t){(__COLOUR).tValue},   \
                                 (__ALPHA))


#define arm_2d_cccn888_fill_colour_with_opacity(                                \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __COLOUR,     /*   colour */              \
                                      __ALPHA)      /*   alpha */               \
            arm_2dp_cccn888_fill_colour_with_opacity(  NULL,                    \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__COLOUR),                    \
                                                 (__ALPHA))

#define arm_2d_gray8_fill_colour_with_a1_mask(                                  \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_gray8_fill_colour_with_a1_mask(                             \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_rgb565_fill_colour_with_a1_mask(                                 \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_rgb565_fill_colour_with_a1_mask(                            \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_rgb888_fill_colour_with_a1_mask(                                 \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_cccn888_fill_colour_with_a1_mask(                           \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (arm_2d_color_cccn888_t){(__COLOUR).tValue})

#define arm_2d_cccn888_fill_colour_with_a1_mask(                                \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_cccn888_fill_colour_with_a1_mask(                           \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_gray8_fill_colour_with_a2_mask(                                  \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_gray8_fill_colour_with_a2_mask(                             \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_rgb565_fill_colour_with_a2_mask(                                 \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_rgb565_fill_colour_with_a2_mask(                            \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_rgb888_fill_colour_with_a2_mask(                                 \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_cccn888_fill_colour_with_a2_mask(                           \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (arm_2d_color_cccn888_t){(__COLOUR).tValue})

#define arm_2d_cccn888_fill_colour_with_a2_mask(                                \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_cccn888_fill_colour_with_a2_mask(                           \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_gray8_fill_colour_with_a4_mask(                                  \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_gray8_fill_colour_with_a4_mask(                             \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_rgb565_fill_colour_with_a4_mask(                                 \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_rgb565_fill_colour_with_a4_mask(                            \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_rgb888_fill_colour_with_a4_mask(                                 \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_cccn888_fill_colour_with_a4_mask(                           \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (arm_2d_color_cccn888_t){(__COLOUR).tValue})

#define arm_2d_cccn888_fill_colour_with_a4_mask(                                \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_cccn888_fill_colour_with_a4_mask(                           \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR))

#define arm_2d_rgb888_fill_colour_with_mask(                                    \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR)       /*   colour */              \
            arm_2dp_cccn888_fill_colour_with_mask_only(                         \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (arm_2d_color_cccn888_t){(__COLOUR).tValue})
                                     
#define arm_2d_gray8_fill_colour_with_a8_mask                                   \
            arm_2d_gray8_fill_colour_with_mask
#define arm_2d_rgb565_fill_colour_with_a8_mask                                  \
            arm_2d_rgb565_fill_colour_with_mask
#define arm_2d_rgb888_fill_colour_with_a8_mask                                  \
            arm_2d_rgb888_fill_colour_with_mask
#define arm_2d_cccn888_fill_colour_with_a8_mask                                 \
            arm_2d_cccn888_fill_colour_with_mask

#define arm_2d_gray8_fill_colour_with_a1_mask_and_opacity(                      \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_gray8_fill_colour_with_a1_mask_and_opacity(                 \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_rgb565_fill_colour_with_a1_mask_and_opacity(                     \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_rgb565_fill_colour_with_a1_mask_and_opacity(                \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_rgb888_fill_colour_with_a1_mask_and_opacity(                     \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_cccn888_fill_colour_with_a1_mask_and_opacity(               \
                                  NULL,                                         \
                                 (__TARGET_ADDR),                               \
                                 (__REGION_ADDR),                               \
                                 (__ALPHA_ADDR),                                \
                                 (arm_2d_color_cccn888_t){(__COLOUR).tValue},   \
                                 (__OPACITY))

#define arm_2d_cccn888_fill_colour_with_a1_mask_and_opacity(                    \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_cccn888_fill_colour_with_a1_mask_and_opacity(               \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_gray8_fill_colour_with_a2_mask_and_opacity(                      \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_gray8_fill_colour_with_a2_mask_and_opacity(                 \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_rgb565_fill_colour_with_a2_mask_and_opacity(                     \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_rgb565_fill_colour_with_a2_mask_and_opacity(                \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_rgb888_fill_colour_with_a2_mask_and_opacity(                     \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_cccn888_fill_colour_with_a2_mask_and_opacity(               \
                                  NULL,                                         \
                                 (__TARGET_ADDR),                               \
                                 (__REGION_ADDR),                               \
                                 (__ALPHA_ADDR),                                \
                                 (arm_2d_color_cccn888_t){(__COLOUR).tValue},   \
                                 (__OPACITY))

#define arm_2d_cccn888_fill_colour_with_a2_mask_and_opacity(                    \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_cccn888_fill_colour_with_a2_mask_and_opacity(               \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_gray8_fill_colour_with_a4_mask_and_opacity(                      \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_gray8_fill_colour_with_a4_mask_and_opacity(                 \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_rgb565_fill_colour_with_a4_mask_and_opacity(                     \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_rgb565_fill_colour_with_a4_mask_and_opacity(                \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_rgb888_fill_colour_with_a4_mask_and_opacity(                     \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_cccn888_fill_colour_with_a4_mask_and_opacity(               \
                                  NULL,                                         \
                                 (__TARGET_ADDR),                               \
                                 (__REGION_ADDR),                               \
                                 (__ALPHA_ADDR),                                \
                                 (arm_2d_color_cccn888_t){(__COLOUR).tValue},   \
                                 (__OPACITY))

#define arm_2d_cccn888_fill_colour_with_a4_mask_and_opacity(                    \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_cccn888_fill_colour_with_a4_mask_and_opacity(               \
                                      NULL,                                     \
                                     (__TARGET_ADDR),                           \
                                     (__REGION_ADDR),                           \
                                     (__ALPHA_ADDR),                            \
                                     (__COLOUR),                                \
                                     (__OPACITY))

#define arm_2d_rgb888_fill_colour_with_mask_and_opacity(                        \
                                    __TARGET_ADDR,  /*   target tile address*/  \
                                    __REGION_ADDR,  /*   target region address*/\
                                    __ALPHA_ADDR,   /*   alpha tile address */  \
                                    __COLOUR,       /*   colour */              \
                                    __OPACITY)                                  \
            arm_2dp_cccn888_fill_colour_with_mask_and_opacity_only(             \
                                  NULL,                                         \
                                 (__TARGET_ADDR),                               \
                                 (__REGION_ADDR),                               \
                                 (__ALPHA_ADDR),                                \
                                 (arm_2d_color_cccn888_t){(__COLOUR).tValue},   \
                                 (__OPACITY))


#define arm_2d_gray8_fill_colour_with_a8_mask_and_opacity                       \
            arm_2d_gray8_fill_colour_with_mask_and_opacity
#define arm_2d_rgb565_fill_colour_with_a8_mask_and_opacity                      \
            arm_2d_rgb565_fill_colour_with_mask_and_opacity
#define arm_2d_rgb888_fill_colour_with_a8_mask_and_opacity                      \
            arm_2d_rgb888_fill_colour_with_mask_and_opacity
#define arm_2d_cccn888_fill_colour_with_a8_mask_and_opacity                     \
            arm_2d_cccn888_fill_colour_with_mask_and_opacity

#define arm_2d_gray8_tile_copy_with_colour_keying_and_opacity(                  \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,      /*   colour */              \
                                      __COLOUR)     /*   alpha */               \
            arm_2dp_gray8_tile_copy_with_colour_keying_and_opacity(             \
                                                    NULL,                       \
                                                 (__SRC_ADDR),                  \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__ALPHA),                     \
                                                 (__COLOUR))

#define arm_2d_rgb565_tile_copy_with_colour_keying_and_opacity(                 \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,      /*   colour */              \
                                      __COLOUR)     /*   alpha */               \
            arm_2dp_rgb565_tile_copy_with_colour_keying_and_opacity(            \
                                                    NULL,                       \
                                                 (__SRC_ADDR),                  \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__ALPHA),                     \
                                                 (__COLOUR))

#define arm_2d_rgb888_tile_copy_with_colour_keying_and_opacity(                 \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,      /*   colour */              \
                                      __COLOUR)     /*   alpha */               \
            arm_2dp_cccn888_tile_copy_with_colour_keying_and_opacity(           \
                                        NULL,                                   \
                                    (__SRC_ADDR),                               \
                                    (__DES_ADDR),                               \
                                    (__REGION_ADDR),                            \
                                    (__ALPHA),                                  \
                                    (arm_2d_color_cccn888_t){(__COLOUR).tValue})

#define arm_2d_cccn888_tile_copy_with_colour_keying_and_opacity(                \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,      /*   colour */              \
                                      __COLOUR)     /*   alpha */               \
            arm_2dp_cccn888_tile_copy_with_colour_keying_and_opacity(           \
                                                    NULL,                       \
                                                 (__SRC_ADDR),                  \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__ALPHA),                     \
                                                 (__COLOUR))

#define arm_2d_gray8_tile_copy_with_colour_keying_and_opacity(                  \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,     /*   colour */               \
                                      __COLOUR)      /*   alpha */              \
            arm_2dp_gray8_tile_copy_with_colour_keying_and_opacity(             \
                                                    NULL,                       \
                                                 (__SRC_ADDR),                  \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__ALPHA),                     \
                                                 (__COLOUR))

#define arm_2d_rgb565_tile_copy_with_colour_keying_and_opacity(                 \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,      /*   colour */              \
                                      __COLOUR)     /*   alpha */               \
            arm_2dp_rgb565_tile_copy_with_colour_keying_and_opacity(            \
                                                    NULL,                       \
                                                 (__SRC_ADDR),                  \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__ALPHA),                     \
                                                 (__COLOUR))

#define arm_2d_rgb888_tile_copy_with_colour_keying_and_opacity(                 \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,      /*   colour */              \
                                      __COLOUR)     /*   alpha */               \
            arm_2dp_cccn888_tile_copy_with_colour_keying_and_opacity(           \
                                        NULL,                                   \
                                    (__SRC_ADDR),                               \
                                    (__DES_ADDR),                               \
                                    (__REGION_ADDR),                            \
                                    (__ALPHA),                                  \
                                    (arm_2d_color_cccn888_t){(__COLOUR).tValue})

#define arm_2d_cccn888_tile_copy_with_colour_keying_and_opacity(                \
                                      __SRC_ADDR,   /*   source tile address */ \
                                      __DES_ADDR,   /*   target tile address */ \
                                      __REGION_ADDR,/*   region address */      \
                                      __ALPHA,      /*   colour */              \
                                      __COLOUR)     /*   alpha */               \
            arm_2dp_cccn888_tile_copy_with_colour_keying_and_opacity(           \
                                                    NULL,                       \
                                                 (__SRC_ADDR),                  \
                                                 (__DES_ADDR),                  \
                                                 (__REGION_ADDR),               \
                                                 (__ALPHA),                     \
                                                 (__COLOUR))

#define arm_2d_gray8_tile_copy_with_masks(                                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   region address */      \
                                    ...)            /*   copy mode */           \
            arm_2dp_gray8_tile_copy_with_masks(                                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

#define arm_2d_rgb565_tile_copy_with_masks(                                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   region address */      \
                                    ...)            /*   copy mode */           \
            arm_2dp_rgb565_tile_copy_with_masks(                                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

#define arm_2d_rgb888_tile_copy_with_masks                                      \
            arm_2d_cccn888_tile_copy_with_masks

#define arm_2d_cccn888_tile_copy_with_masks(                                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   region address */      \
                                    ...)            /*   copy mode */           \
            arm_2dp_cccn888_tile_copy_with_masks(                               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

#define arm_2dp_gray8_tile_fill_with_masks(                                     \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_gray8_tile_fill_with_masks_only(                  \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_gray8_tile_fill_with_masks_and_x_mirror(          \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_gray8_tile_fill_with_masks_and_y_mirror(          \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_gray8_tile_fill_with_masks_and_xy_mirror(         \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_gray8_tile_fill_with_masks(                                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_gray8_tile_fill_with_masks(                                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

#define arm_2dp_rgb565_tile_fill_with_masks(                                    \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_rgb565_tile_fill_with_masks_only(                 \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_rgb565_tile_fill_with_masks_and_x_mirror(         \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_rgb565_tile_fill_with_masks_and_y_mirror(         \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_rgb565_tile_fill_with_masks_and_xy_mirror(        \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_rgb565_tile_fill_with_masks(                                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_rgb565_tile_fill_with_masks(                                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

#define arm_2dp_cccn888_tile_fill_with_masks(                                   \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_cccn888_tile_fill_with_masks_only(                \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_cccn888_tile_fill_with_masks_and_x_mirror(        \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_cccn888_tile_fill_with_masks_and_y_mirror(        \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_cccn888_tile_fill_with_masks_and_xy_mirror(       \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_cccn888_tile_fill_with_masks(                                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_cccn888_tile_fill_with_masks(                               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

/*!
 * \brief copy a source tile to a target tile with masks and an optional mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __SRC_MSK_ADDR the mask on the source side
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_gray8_tile_copy_with_masks(                                     \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_gray8_tile_fill_with_masks(                           \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_gray8_tile_copy_with_masks_only(              \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_gray8_tile_copy_with_masks_and_x_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_gray8_tile_copy_with_masks_and_y_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_gray8_tile_copy_with_masks_and_xy_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

/*!
 * \brief copy a source tile to a target tile with masks and an optional mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __SRC_MSK_ADDR the mask on the source side
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_rgb565_tile_copy_with_masks(                                    \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_rgb565_tile_fill_with_masks(                          \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_rgb565_tile_copy_with_masks_only(             \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_rgb565_tile_copy_with_masks_and_x_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_rgb565_tile_copy_with_masks_and_y_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_rgb565_tile_copy_with_masks_and_xy_mirror(    \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

/*!
 * \brief copy a source tile to a target tile with masks and an optional mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __SRC_MSK_ADDR the mask on the source side
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_cccn888_tile_copy_with_masks(                                   \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_cccn888_tile_fill_with_masks(                         \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_cccn888_tile_copy_with_masks_only(            \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_cccn888_tile_copy_with_masks_and_x_mirror(    \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_cccn888_tile_copy_with_masks_and_y_mirror(    \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_cccn888_tile_copy_with_masks_and_xy_mirror(   \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

/*!
 * \brief copy a source tile to a target tile with a source mask and an optional
 *         mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __SRC_MSK_ADDR the mask on the source side
 * \param[in] __DES_ADDR the target tile
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_gray8_tile_copy_with_src_mask(                                  \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_gray8_tile_fill_with_src_mask(                        \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_gray8_tile_copy_with_src_mask_only(           \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_gray8_tile_copy_with_src_mask_and_x_mirror(   \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_gray8_tile_copy_with_src_mask_and_y_mirror(   \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_gray8_tile_copy_with_src_mask_and_xy_mirror(  \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

#define arm_2d_gray8_tile_copy_with_src_mask(                                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_gray8_tile_copy_with_src_mask(NULL,                         \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

/*!
 * \brief copy a source tile to a target tile with a source mask and an optional
 *         mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __SRC_MSK_ADDR the mask on the source side
 * \param[in] __DES_ADDR the target tile
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_rgb565_tile_copy_with_src_mask(                                 \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_rgb565_tile_fill_with_src_mask(                       \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_rgb565_tile_copy_with_src_mask_only(          \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_rgb565_tile_copy_with_src_mask_and_x_mirror(  \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_rgb565_tile_copy_with_src_mask_and_y_mirror(  \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_rgb565_tile_copy_with_src_mask_and_xy_mirror( \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

#define arm_2d_rgb565_tile_copy_with_src_mask(                                  \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_rgb565_tile_copy_with_src_mask(NULL,                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

/*!
 * \brief copy a source tile to a target tile with a source mask and an optional
 *         mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __SRC_MSK_ADDR the mask on the source side
 * \param[in] __DES_ADDR the target tile
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_cccn888_tile_copy_with_src_mask(                                \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_cccn888_tile_fill_with_src_mask(                      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_cccn888_tile_copy_with_src_mask_only(         \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_cccn888_tile_copy_with_src_mask_and_x_mirror( \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_cccn888_tile_copy_with_src_mask_and_y_mirror( \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_cccn888_tile_copy_with_src_mask_and_xy_mirror(\
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

#define arm_2d_cccn888_tile_copy_with_src_mask(                                 \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_cccn888_tile_copy_with_src_mask(NULL,                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

#define arm_2d_rgb888_tile_copy_with_src_mask                                   \
            arm_2d_cccn888_tile_copy_with_src_mask

#define arm_2dp_gray8_tile_fill_with_src_mask(                                  \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_gray8_tile_fill_with_src_mask_only(               \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_gray8_tile_fill_with_src_mask_and_x_mirror(       \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_gray8_tile_fill_with_src_mask_and_y_mirror(       \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_gray8_tile_fill_with_src_mask_and_xy_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_gray8_tile_fill_with_src_mask(                                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_gray8_tile_fill_with_src_mask(NULL,                         \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

#define arm_2dp_rgb565_tile_fill_with_src_mask(                                 \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_rgb565_tile_fill_with_src_mask_only(              \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_rgb565_tile_fill_with_src_mask_and_x_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_rgb565_tile_fill_with_src_mask_and_y_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_rgb565_tile_fill_with_src_mask_and_xy_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_rgb565_tile_fill_with_src_mask(                                  \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_rgb565_tile_fill_with_src_mask(NULL,                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

#define arm_2dp_cccn888_tile_fill_with_src_mask(                                \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_cccn888_tile_fill_with_src_mask_only(             \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_cccn888_tile_fill_with_src_mask_and_x_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_cccn888_tile_fill_with_src_mask_and_y_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_cccn888_tile_fill_with_src_mask_and_xy_mirror(    \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_cccn888_tile_fill_with_src_mask(                                 \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_cccn888_tile_fill_with_src_mask(NULL,                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

#define arm_2d_gray8_tile_copy_with_src_mask_only(                              \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_src_mask_only(                         \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_rgb565_tile_copy_with_src_mask_only(                             \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_src_mask_only(                        \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_src_mask_only                              \
            arm_2d_cccn888_tile_copy_with_src_mask_only

#define arm_2d_cccn888_tile_copy_with_src_mask_only(                            \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_src_mask_only(                       \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_src_mask_and_x_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_src_mask_and_x_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_src_mask_and_x_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_src_mask_and_x_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_src_mask_and_x_mirror                      \
            arm_2d_cccn888_tile_copy_with_src_mask_and_x_mirror

#define arm_2d_cccn888_tile_copy_with_src_mask_and_x_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_src_mask_and_x_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_src_mask_and_y_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_src_mask_and_y_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_src_mask_and_y_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_src_mask_and_y_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_src_mask_and_y_mirror                      \
            arm_2d_cccn888_tile_copy_with_src_mask_and_y_mirror

#define arm_2d_cccn888_tile_copy_with_src_mask_and_y_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_src_mask_and_y_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_src_mask_and_xy_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_src_mask_and_xy_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_src_mask_and_xy_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_src_mask_and_xy_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_src_mask_and_xy_mirror                     \
            arm_2d_cccn888_tile_copy_with_src_mask_and_xy_mirror

#define arm_2d_cccn888_tile_copy_with_src_mask_and_xy_mirror(                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_src_mask_and_xy_mirror(              \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_src_mask_only(                              \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_src_mask_only(                         \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_src_mask_only(                             \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_src_mask_only(                        \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_src_mask_only                              \
            arm_2d_cccn888_tile_fill_with_src_mask_only

#define arm_2d_cccn888_tile_fill_with_src_mask_only(                            \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_src_mask_only(                       \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_src_mask_and_x_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_src_mask_and_x_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_src_mask_and_x_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_src_mask_and_x_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_src_mask_and_x_mirror                      \
            arm_2d_cccn888_tile_fill_with_src_mask_and_x_mirror

#define arm_2d_cccn888_tile_fill_with_src_mask_and_x_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_src_mask_and_x_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_src_mask_and_y_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_src_mask_and_y_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_src_mask_and_y_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_src_mask_and_y_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_src_mask_and_y_mirror                      \
            arm_2d_cccn888_tile_fill_with_src_mask_and_y_mirror

#define arm_2d_cccn888_tile_fill_with_src_mask_and_y_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_src_mask_and_y_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_src_mask_and_xy_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_src_mask_and_xy_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_src_mask_and_xy_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_src_mask_and_xy_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_src_mask_and_xy_mirror                     \
            arm_2d_cccn888_tile_fill_with_src_mask_and_xy_mirror

#define arm_2d_cccn888_tile_fill_with_src_mask_and_xy_mirror(                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_src_mask_and_xy_mirror(              \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_masks_only(                                 \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_masks_only(                            \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_masks_only(                                \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_masks_only(                           \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_masks_only                                 \
            arm_2d_cccn888_tile_copy_with_masks_only

#define arm_2d_cccn888_tile_copy_with_masks_only(                               \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_masks_only(                          \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_masks_and_x_mirror(                         \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_masks_and_x_mirror(                    \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_masks_and_x_mirror(                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_masks_and_x_mirror(                   \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_masks_and_x_mirror                         \
            arm_2d_cccn888_tile_copy_with_masks_and_x_mirror

#define arm_2d_cccn888_tile_copy_with_masks_and_x_mirror(                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_masks_and_x_mirror(                  \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_masks_and_y_mirror(                         \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_masks_and_y_mirror(                    \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_masks_and_y_mirror(                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_masks_and_y_mirror(                   \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_masks_and_y_mirror                         \
            arm_2d_cccn888_tile_copy_with_masks_and_y_mirror

#define arm_2d_cccn888_tile_copy_with_masks_and_y_mirror(                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_masks_and_y_mirror(                  \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_masks_and_xy_mirror(                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_masks_and_xy_mirror(                   \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_masks_and_xy_mirror(                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_masks_and_xy_mirror(                  \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_masks_and_xy_mirror                        \
            arm_2d_cccn888_tile_copy_with_masks_and_xy_mirror

#define arm_2d_cccn888_tile_copy_with_masks_and_xy_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_masks_and_xy_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_masks_only(                                 \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_masks_only(                            \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_masks_only(                                \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_masks_only(                           \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_masks_only                                 \
            arm_2d_cccn888_tile_fill_with_masks_only

#define arm_2d_cccn888_tile_fill_with_masks_only(                               \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_masks_only(                          \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_masks_and_x_mirror(                         \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_masks_and_x_mirror(                    \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_masks_and_x_mirror(                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_masks_and_x_mirror(                   \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_masks_and_x_mirror                         \
            arm_2d_cccn888_tile_fill_with_masks_and_x_mirror

#define arm_2d_cccn888_tile_fill_with_masks_and_x_mirror(                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_masks_and_x_mirror(                  \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_masks_and_y_mirror(                         \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_masks_and_y_mirror(                    \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_masks_and_y_mirror(                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_masks_and_y_mirror(                   \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_masks_and_y_mirror                         \
            arm_2d_cccn888_tile_fill_with_masks_and_y_mirror

#define arm_2d_cccn888_tile_fill_with_masks_and_y_mirror(                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_masks_and_y_mirror(                  \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_masks_and_xy_mirror(                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_masks_and_xy_mirror(                   \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_masks_and_xy_mirror(                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_masks_and_xy_mirror(                  \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_masks_and_xy_mirror                        \
            arm_2d_cccn888_tile_fill_with_masks_and_xy_mirror

#define arm_2d_cccn888_tile_fill_with_masks_and_xy_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __SRC_MSK_ADDR, /*   source mask address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_masks_and_xy_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__SRC_MSK_ADDR),                       \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_gray8_tile_copy_with_des_mask(                                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   region address */      \
                                    ...)            /*   copy mode */           \
            arm_2dp_gray8_tile_copy_with_des_mask(                              \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

#define arm_2d_rgb565_tile_copy_with_des_mask(                                  \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   region address */      \
                                    ...)            /*   copy mode */           \
            arm_2dp_rgb565_tile_copy_with_des_mask(                             \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)

#define arm_2d_rgb888_tile_copy_with_des_mask                                   \
            arm_2d_cccn888_tile_copy_with_des_mask

#define arm_2d_cccn888_tile_copy_with_des_mask(                                 \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   region address */      \
                                    ...)            /*   copy mode */           \
            arm_2dp_cccn888_tile_copy_with_des_mask(                            \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__)


#define arm_2d_gray8_tile_copy_with_des_mask_only(                              \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_des_mask_only(                         \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_des_mask_only(                             \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_des_mask_only(                        \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_des_mask_only                              \
            arm_2d_cccn888_tile_copy_with_des_mask_only

#define arm_2d_cccn888_tile_copy_with_des_mask_only(                            \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_des_mask_only(                       \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_des_mask_and_x_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_des_mask_and_x_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_des_mask_and_x_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_des_mask_and_x_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_des_mask_and_x_mirror                      \
            arm_2d_cccn888_tile_copy_with_des_mask_and_x_mirror

#define arm_2d_cccn888_tile_copy_with_des_mask_and_x_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_des_mask_and_x_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_des_mask_and_y_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_des_mask_and_y_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_des_mask_and_y_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_des_mask_and_y_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_des_mask_and_y_mirror                      \
            arm_2d_cccn888_tile_copy_with_des_mask_and_y_mirror

#define arm_2d_cccn888_tile_copy_with_des_mask_and_y_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_des_mask_and_y_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_copy_with_des_mask_and_xy_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_copy_with_des_mask_and_xy_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_copy_with_des_mask_and_xy_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_copy_with_des_mask_and_xy_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_copy_with_des_mask_and_xy_mirror                     \
            arm_2d_cccn888_tile_copy_with_des_mask_and_xy_mirror

#define arm_2d_cccn888_tile_copy_with_des_mask_and_xy_mirror(                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_copy_with_des_mask_and_xy_mirror(              \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_des_mask_only(                              \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_des_mask_only(                         \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_des_mask_only(                             \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_des_mask_only(                        \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_des_mask_only                              \
            arm_2d_cccn888_tile_fill_with_des_mask_only

#define arm_2d_cccn888_tile_fill_with_des_mask_only(                            \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_des_mask_only(                       \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_des_mask_and_x_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_des_mask_and_x_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_des_mask_and_x_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_des_mask_and_x_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_des_mask_and_x_mirror                      \
            arm_2d_cccn888_tile_fill_with_des_mask_and_x_mirror

#define arm_2d_cccn888_tile_fill_with_des_mask_and_x_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_des_mask_and_x_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_des_mask_and_y_mirror(                      \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_des_mask_and_y_mirror(                 \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_des_mask_and_y_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_des_mask_and_y_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_des_mask_and_y_mirror                      \
            arm_2d_cccn888_tile_fill_with_des_mask_and_y_mirror

#define arm_2d_cccn888_tile_fill_with_des_mask_and_y_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_des_mask_and_y_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

#define arm_2d_gray8_tile_fill_with_des_mask_and_xy_mirror(                     \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_gray8_tile_fill_with_des_mask_and_xy_mirror(                \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb565_tile_fill_with_des_mask_and_xy_mirror(                    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_rgb565_tile_fill_with_des_mask_and_xy_mirror(               \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))


#define arm_2d_rgb888_tile_fill_with_des_mask_and_xy_mirror                     \
            arm_2d_cccn888_tile_fill_with_des_mask_and_xy_mirror

#define arm_2d_cccn888_tile_fill_with_des_mask_and_xy_mirror(                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address */ \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION)       /*   region address */      \
            arm_2dp_cccn888_tile_fill_with_des_mask_and_xy_mirror(              \
                                        NULL,                                   \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION))

/*!
 * \brief fill a target tile with a source tile and a target mask in an optional 
 *        copy mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_gray8_tile_fill_with_des_mask(                                  \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_gray8_tile_fill_with_des_mask_only(               \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_gray8_tile_fill_with_des_mask_and_x_mirror(       \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_gray8_tile_fill_with_des_mask_and_y_mirror(       \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_gray8_tile_fill_with_des_mask_and_xy_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_gray8_tile_fill_with_des_mask(                                   \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_gray8_tile_fill_with_des_mask(NULL,                         \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __SRC_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)


/*!
 * \brief fill a target tile with a source tile and a target mask in an optional 
 *        copy mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_rgb565_tile_fill_with_des_mask(                                 \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_rgb565_tile_fill_with_des_mask_only(              \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_rgb565_tile_fill_with_des_mask_and_x_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_rgb565_tile_fill_with_des_mask_and_y_mirror(      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_rgb565_tile_fill_with_des_mask_and_xy_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_rgb565_tile_fill_with_des_mask(                                  \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_rgb565_tile_fill_with_des_mask(NULL,                        \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __SRC_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

/*!
 * \brief fill a target tile with a source tile and a target mask in an optional 
 *        copy mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_cccn888_tile_fill_with_des_mask(                                \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_t * */    \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                       \
           &    ARM_2D_CP_MODE_XY_MIRROR) {                                     \
        case ARM_2D_CP_MODE_NO_MIRROR:                                          \
            tResult = arm_2dp_cccn888_tile_fill_with_des_mask_only(             \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_X_MIRROR:                                           \
            tResult = arm_2dp_cccn888_tile_fill_with_des_mask_and_x_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_Y_MIRROR:                                           \
            tResult = arm_2dp_cccn888_tile_fill_with_des_mask_and_y_mirror(     \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
        case ARM_2D_CP_MODE_XY_MIRROR:                                          \
            tResult = arm_2dp_cccn888_tile_fill_with_des_mask_and_xy_mirror(    \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
            break;                                                              \
    }                                                                           \
    tResult;                                                                    \
})

#define arm_2d_cccn888_tile_fill_with_des_mask(                                 \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
            arm_2dp_cccn888_tile_fill_with_des_mask(NULL,                       \
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __SRC_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ##__VA_ARGS__)

/*!
 * \brief copy a source tile to a target tile with a target mask and an optional 
 *        copy mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_gray8_tile_copy_with_des_mask(                                  \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_gray8_tile_fill_with_des_mask(                        \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_gray8_tile_copy_with_des_mask_only(           \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_gray8_tile_copy_with_des_mask_and_x_mirror(   \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_gray8_tile_copy_with_des_mask_and_y_mirror(   \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_gray8_tile_copy_with_des_mask_and_xy_mirror(  \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

/*!
 * \brief copy a source tile to a target tile with a target mask and an optional 
 *        copy mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_rgb565_tile_copy_with_des_mask(                                 \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_rgb565_tile_fill_with_des_mask(                       \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_rgb565_tile_copy_with_des_mask_only(          \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_rgb565_tile_copy_with_des_mask_and_x_mirror(  \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_rgb565_tile_copy_with_des_mask_and_y_mirror(  \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_rgb565_tile_copy_with_des_mask_and_xy_mirror( \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

/*!
 * \brief copy a source tile to a target tile with a target mask and an optional 
 *        copy mode
 * \param[in] __OPCODE_PTR the control block, NULL means using the default 
 *                         control block
 * \param[in] __SRC_ADDR the source tile
 * \param[in] __DES_ADDR the target tile
 * \param[in] __DES_MSK_ADDR the mask on the target side
 * \param[in] __REGION the target region
 * \param[in] ... the optional copy mode
 * \return arm_fsm_rt_t the operation result
 */
#define arm_2dp_cccn888_tile_copy_with_des_mask(                                \
                                    __OPCODE_PTR,   /*   arm_2d_op_cp_msk_t * */\
                                    __SRC_ADDR,     /*   source tile address */ \
                                    __DES_ADDR,     /*   target tile address*/  \
                                    __DES_MSK_ADDR, /*   target mask address */ \
                                    __REGION,       /*   target region address*/\
                                    ...)            /*   mode */                \
({                                                                              \
    arm_fsm_rt_t tResult = (arm_fsm_rt_t)ARM_2D_ERR_UNKNOWN;                    \
    if ((ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__) & ARM_2D_CP_MODE_FILL) {      \
        tResult = arm_2dp_cccn888_tile_fill_with_des_mask(                      \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION),                             \
                                        ##__VA_ARGS__);                         \
    } else {                                                                    \
        switch (    (ARM_2D_CP_MODE_NO_MIRROR, ##__VA_ARGS__)                   \
            &    ARM_2D_CP_MODE_XY_MIRROR) {                                    \
            case ARM_2D_CP_MODE_NO_MIRROR:                                      \
                tResult = arm_2dp_cccn888_tile_copy_with_des_mask_only(         \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_X_MIRROR:                                       \
                tResult = arm_2dp_cccn888_tile_copy_with_des_mask_and_x_mirror( \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_Y_MIRROR:                                       \
                tResult = arm_2dp_cccn888_tile_copy_with_des_mask_and_y_mirror( \
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
            case ARM_2D_CP_MODE_XY_MIRROR:                                      \
                tResult = arm_2dp_cccn888_tile_copy_with_des_mask_and_xy_mirror(\
                                        (__OPCODE_PTR),                         \
                                        (__SRC_ADDR),                           \
                                        (__DES_ADDR),                           \
                                        (__DES_MSK_ADDR),                       \
                                        (__REGION));                            \
                break;                                                          \
        }                                                                       \
    };                                                                          \
    tResult;                                                                    \
})

/*============================ TYPES =========================================*/

/*!
 * \brief control block for alpha-blending operations
 * \note arm_2d_op_alpha_t inherits from arm_2d_op_src_t explicitly 
 */
typedef struct arm_2d_op_alpha_t {
    inherit(arm_2d_op_core_t);                  //!< base
    struct {
        const arm_2d_tile_t     *ptTile;        //!< target tile 
        const arm_2d_region_t   *ptRegion;      //!< target region
    } Target;                                   //!< target
    struct {
        const arm_2d_tile_t     *ptTile;        //!< source tile 
    }Source;                                    //!< source
    uint32_t wMode;                             //!< copy mode
    uint8_t chRatio;                            //!< opacity
} arm_2d_op_alpha_t;


/*!
 * \brief control block for alpha-blending-with-colour-keying operations
 * \note arm_2d_op_alpha_cl_key_t inherits from arm_2d_op_src_t explicitly 
 */
typedef struct arm_2d_op_alpha_cl_key_t {
    inherit(arm_2d_op_core_t);                  //!< base
    struct {
        const arm_2d_tile_t     *ptTile;        //!< target tile 
        const arm_2d_region_t   *ptRegion;      //!< target region
    } Target;                                   //!< target
    struct {
        const arm_2d_tile_t     *ptTile;        //!< source tile 
    }Source;                                    //!< source
    uint32_t wMode;                             //!< copy mode
    uint8_t chRatio;                            //!< opacity

    union {
        uint8_t  chColour;                      //!< 8bit key colour
        uint16_t hwColour;                      //!< 16bit key colour
        uint32_t wColour;                       //!< 32bit key colour
    };
} arm_2d_op_alpha_cl_key_t;


/*!
 * \brief control block for colour-filling-with-mask operations
 * \note arm_2d_op_fill_cl_msk_t inherits from arm_2d_op_src_t explicitly 
 */
typedef struct arm_2d_op_fill_cl_msk_t {
    inherit(arm_2d_op_core_t);                  //!< base
    struct {
        const arm_2d_tile_t     *ptTile;        //!< target tile
        const arm_2d_region_t   *ptRegion;      //!< target region
    } Target;                                   //!< target
    struct {
        const arm_2d_tile_t     *ptTile;        //!< Alpha Mask tile
    } Mask;                                     //!< mask
    uint32_t wMode;                             //!< copy mode

    union {
        uint8_t  chColour;                      //!< 8bit key colour
        uint16_t hwColour;                      //!< 16bit key colour
        uint32_t wColour;                       //!< 32bit key colour
    };
} arm_2d_op_fill_cl_msk_t;


/*!
 * \brief control block for colour-filling-with-mask-and-opacity operations
 * \note arm_2d_op_fill_cl_msk_t inherits from arm_2d_op_src_t explicitly 
 */
typedef struct arm_2d_op_fill_cl_msk_opc_t {
    inherit(arm_2d_op_core_t);                  //!< core
    struct {
        const arm_2d_tile_t     *ptTile;        //!< target tile
        const arm_2d_region_t   *ptRegion;      //!< target region
    } Target;                                   //!< target
    struct {
        const arm_2d_tile_t     *ptTile;        //!< Alpha Mask tile
    } Mask;                                     //!< mask
    uint32_t wMode;                             //!< copy mode
    union {
        uint8_t  chColour;                      //!< 8bit key colour
        uint16_t hwColour;                      //!< 16bit key colour
        uint32_t wColour;                       //!< 32bit key colour
    };
    union {
        uint8_t chRatio;                        //!< opacity
        uint8_t chOpacity;
    };
} arm_2d_op_fill_cl_msk_opc_t;

/*!
 * \brief control block for colour-filling-with-opacity operations
 * \note arm_2d_op_fill_cl_t inherits from arm_2d_op_t explicitly 
 */
typedef struct arm_2d_op_fill_cl_opc_t {
    inherit(arm_2d_op_core_t);                  //!< base 
    struct {
        const arm_2d_tile_t     *ptTile;        //!< target tile 
        const arm_2d_region_t   *ptRegion;      //!< target region
    } Target;                                   //!< target
    union {
        uint8_t  chColour;                      //!< 8bit key colour
        uint16_t hwColour;                      //!< 16bit key colour
        uint32_t wColour;                       //!< 32bit key colour
    };
    uint8_t chRatio;                             //!< opacity
} arm_2d_op_fill_cl_opc_t;

/*!
 * \brief control block for copy with masks operations
 * 
 */
typedef arm_2d_op_src_msk_t arm_2d_op_cp_msk_t;

/*============================ GLOBAL VARIABLES ==============================*/
/*============================ PROTOTYPES ====================================*/

/*----------------------------------------------------------------------------*
 * Copy tile to destination with specified transparency ratio (0~255)         *
 *----------------------------------------------------------------------------*/

/*!
 * \brief blend a source tile to a target tile with a specified opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] chRatio the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern 
ARM_NONNULL(2,3)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_opacity_only(  arm_2d_op_alpha_t *ptOP,
                                            const arm_2d_tile_t *ptSource,
                                            const arm_2d_tile_t *ptTarget,
                                            const arm_2d_region_t *ptRegion,
                                            uint_fast8_t chRatio);

/*!
 * \brief blend a source tile to a target tile with a specified opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] chRatio the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern 
ARM_NONNULL(2,3)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_opacity_only( arm_2d_op_alpha_t *ptOP,
                                            const arm_2d_tile_t *ptSource,
                                            const arm_2d_tile_t *ptTarget,
                                            const arm_2d_region_t *ptRegion,
                                            uint_fast8_t chRatio);

/*!
 * \brief blend a source tile to a target tile with a specified opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] chRatio the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern 
ARM_NONNULL(2,3)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_opacity_only( arm_2d_op_alpha_t *ptOP,
                                            const arm_2d_tile_t *ptSource,
                                            const arm_2d_tile_t *ptTarget,
                                            const arm_2d_region_t *ptRegion,
                                            uint_fast8_t chRatio);
                                     

/*----------------------------------------------------------------------------*
 * Fill a specified region with a given colour and transparency ratio (0~255) *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour and a specified opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] tColour a gray8 colour
 * \param[in] chRatio the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_opacity( 
                                                arm_2d_op_fill_cl_opc_t *ptOP,
                                                const arm_2d_tile_t *ptTarget,
                                                const arm_2d_region_t *ptRegion,
                                                arm_2d_color_gray8_t tColour,
                                                uint_fast8_t chRatio);

/*!
 * \brief fill a target tile with a given rgb565 colour and a specified opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] tColour a rgb565 colour
 * \param[in] chRatio the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern 
ARM_NONNULL(2)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_opacity( 
                                                arm_2d_op_fill_cl_opc_t *ptOP,
                                                const arm_2d_tile_t *ptTarget,
                                                const arm_2d_region_t *ptRegion,
                                                arm_2d_color_rgb565_t tColour,
                                                uint_fast8_t chRatio);

/*!
 * \brief fill a target tile with a given cccn888 colour and a specified opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] tColour a cccn888 colour
 * \param[in] chRatio the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern 
ARM_NONNULL(2)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_opacity( 
                                                arm_2d_op_fill_cl_opc_t *ptOP,
                                                const arm_2d_tile_t *ptTarget,
                                                const arm_2d_region_t *ptRegion,
                                                arm_2d_color_cccn888_t tColour,
                                                uint_fast8_t chRatio);

/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour and an a1 mask                           *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour and an a1 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_a1_mask(
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour);

/*!
 * \brief fill a target tile with a given rgb565 colour and an a1 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_a1_mask( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour);

/*!
 * \brief fill a target tile with a given cccn888 colour and an a1 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \return arm_fsm_rt_t the operation result
 */
extern                                  
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_a1_mask( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour);

/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour and an a2 mask                           *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour and an a2 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_a2_mask(
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour);

/*!
 * \brief fill a target tile with a given rgb565 colour and an a2 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_a2_mask( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour);

/*!
 * \brief fill a target tile with a given cccn888 colour and an a2 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \return arm_fsm_rt_t the operation result
 */
extern                                  
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_a2_mask( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour);


/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour and an a4 mask                           *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour and an a4 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_a4_mask(
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour);

/*!
 * \brief fill a target tile with a given rgb565 colour and an a4 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_a4_mask( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour);

/*!
 * \brief fill a target tile with a given cccn888 colour and an a4 mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \return arm_fsm_rt_t the operation result
 */
extern                                  
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_a4_mask( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour);

/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour and an a8 mask                           *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour and a mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_mask_only(
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour);

/*!
 * \brief fill a target tile with a given rgb565 colour and a mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_mask_only( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour);

/*!
 * \brief fill a target tile with a given cccn888 colour and a mask on target side
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \return arm_fsm_rt_t the operation result
 */
extern                                  
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_mask_only( 
                                        arm_2d_op_fill_cl_msk_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour);

/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour, an a1 mask and a specified opacity      *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour, an a1 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_a1_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given rgb565 colour, an a1 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_a1_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given cccn888 colour, an a1 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_a1_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour,
                                        uint8_t chOpacity);

/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour, an a2 mask and a specified opacity      *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour, an a2 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_a2_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given rgb565 colour, an a2 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_a2_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given cccn888 colour, an a2 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_a2_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour,
                                        uint8_t chOpacity);

/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour, an a4 mask and a specified opacity      *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour, an a4 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_a4_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given rgb565 colour, an a4 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_a4_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given cccn888 colour, an a4 mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_a4_mask_and_opacity(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour,
                                        uint8_t chOpacity);

/*----------------------------------------------------------------------------*
 * Fill tile with a specified colour, an alpha mask and a specified opacity   *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a target tile with a given gray8 colour, a mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a gray8 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_gray8_fill_colour_with_mask_and_opacity_only(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_gray8_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given rgb565 colour, a mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a rgb565 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_rgb565_fill_colour_with_mask_and_opacity_only(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_rgb565_t tColour,
                                        uint8_t chOpacity);

/*!
 * \brief fill a target tile with a given cccn888 colour, a mask on target side and an opacity
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] ptAlpha the mask on the target side
 * \param[in] tColour a cccn888 colour
 * \param[in] chOpacity the opacity
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,4)
arm_fsm_rt_t arm_2dp_cccn888_fill_colour_with_mask_and_opacity_only(
                                        arm_2d_op_fill_cl_msk_opc_t *ptOP,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion,
                                        const arm_2d_tile_t *ptAlpha,
                                        arm_2d_color_cccn888_t tColour,
                                        uint8_t chOpacity);

/*----------------------------------------------------------------------------*
 * Blend tile and background with a specified transparency ratio(0~255) and   *
 * colour keying                                                              *
 *----------------------------------------------------------------------------*/

/*!
 * \brief blend a source tile to a target tile with a opacity and colour keying
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] chRatio the opacity
 * \param[in] tColour the key colour
 * \return arm_fsm_rt_t the operation result
 */
extern 
ARM_NONNULL(2,3)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_colour_keying_and_opacity(
                                            arm_2d_op_alpha_cl_key_t *ptOP,
                                            const arm_2d_tile_t *ptSource,
                                            const arm_2d_tile_t *ptTarget,
                                            const arm_2d_region_t *ptRegion,
                                            uint_fast8_t chRatio,
                                            arm_2d_color_gray8_t tColour);

/*!
 * \brief blend a source tile to a target tile with a opacity and colour keying
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] chRatio the opacity
 * \param[in] tColour the key colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_colour_keying_and_opacity(
                                                arm_2d_op_alpha_cl_key_t *ptOP,
                                                const arm_2d_tile_t *ptSource, 
                                                const arm_2d_tile_t *ptTarget, 
                                                const arm_2d_region_t *ptRegion,
                                                uint_fast8_t chRatio,
                                                arm_2d_color_rgb565_t tColour);

/*!
 * \brief blend a source tile to a target tile with a opacity and colour keying
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] chRatio the opacity
 * \param[in] tColour the key colour
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_colour_keying_and_opacity(
                                                arm_2d_op_alpha_cl_key_t *ptOP,
                                                const arm_2d_tile_t *ptSource, 
                                                const arm_2d_tile_t *ptTarget,
                                                const arm_2d_region_t *ptRegion,
                                                uint_fast8_t chRatio,
                                                arm_2d_color_cccn888_t tColour);

/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source mask and a target mask              *
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with masks
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_masks_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with masks
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_masks_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with masks
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_masks_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source mask, a target mask and x-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with masks and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_masks_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with masks and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_masks_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with masks and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_masks_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source mask, a target mask and y-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with masks and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_masks_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with masks and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_masks_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with masks and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_masks_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source mask, a target mask and xy-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with masks and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_masks_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with masks and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_masks_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with masks and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_masks_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source mask and a target mask              *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with masks
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_masks_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with masks
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_masks_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with masks
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_masks_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source mask, a target mask and x-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with masks and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_masks_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with masks and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_masks_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with masks and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_masks_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source mask, a target mask and y-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with masks and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_masks_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with masks and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_masks_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with masks and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_masks_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source mask, a target mask and xy-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with masks and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_masks_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with masks and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_masks_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with masks and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4,5)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_masks_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Copy tile to destination with a specified source mask                      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief copy a source tile to a target tile with a source mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_src_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a source mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_src_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a source mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the copy mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_src_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Copy tile to destination with a specified source mask and x-mirroring      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief copy a source tile to a target tile with a source mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_src_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a source mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_src_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a source mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the copy mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_src_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*----------------------------------------------------------------------------*
 * Copy tile to destination with a specified source mask and y-mirroring      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief copy a source tile to a target tile with a source mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_src_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a source mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_src_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a source mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the copy mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_src_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Copy tile to destination with a specified source mask and xy-mirroring      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief copy a source tile to a target tile with a source mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_src_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a source mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_src_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a source mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the copy mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_src_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*----------------------------------------------------------------------------*
 * Fill tile to destination with a specified source mask                      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief fill a source tile to a target tile with a source mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_src_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with a source mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_src_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a source mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the fill mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_src_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Fill tile to destination with a specified source mask and x-mirroring      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief fill a source tile to a target tile with a source mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_src_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with a source mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_src_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a source mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the fill mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_src_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*----------------------------------------------------------------------------*
 * Fill tile to destination with a specified source mask and y-mirroring      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief fill a source tile to a target tile with a source mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_src_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with a source mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_src_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a source mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the fill mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_src_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Fill tile to destination with a specified source mask and xy-mirroring      *
 *----------------------------------------------------------------------------*/
/*!
 * \brief fill a source tile to a target tile with a source mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_src_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with a source mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_src_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a source mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptSrcMask the mask on the source side
 * \param[in] ptTarget the target tile
 * \param[in] ptRegion the target region
 * \param[in] wMode the fill mode
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_src_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptSrcMask,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_region_t *ptRegion); 

/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source tile and a target mask              *
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with a target mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_des_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a target mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_des_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a target mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_des_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source mask, a target mask and x-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with a target mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_des_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a target mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_des_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a target mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_des_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source tile, a target mask and y-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with a target mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_des_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a target mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_des_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a target mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_des_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Copy tile to target tile with a source tile, a target mask and xy-mirroring*
 *----------------------------------------------------------------------------*/

/*!
 * \brief copy a source tile to a target tile with a target mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_copy_with_des_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief copy a source tile to a target tile with a target mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_copy_with_des_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief copy a source tile to a target tile with a target mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_copy_with_des_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source tile and a target mask              *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with a target mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_des_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with a target mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_des_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a target mask
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_des_mask_only(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 


/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source tile, a target mask and x-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with a target mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_des_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with a target mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_des_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a target mask and x-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_des_mask_and_x_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source tile, a target mask and y-mirroring *
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with a target mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_des_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with a target mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_des_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a target mask and y-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_des_mask_and_y_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);


/*----------------------------------------------------------------------------*
 * Fill tile to target tile with a source tile, a target mask and xy-mirroring*
 *----------------------------------------------------------------------------*/

/*!
 * \brief fill a source tile to a target tile with a target mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_gray8_tile_fill_with_des_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion); 

/*!
 * \brief fill a source tile to a target tile with target mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_rgb565_tile_fill_with_des_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*!
 * \brief fill a source tile to a target tile with a target mask and xy-mirroring
 * \param[in] ptOP the control block, NULL means using the default control block
 * \param[in] ptSource the source tile
 * \param[in] ptTarget the target tile
 * \param[in] ptDesMask the mask on the target side
 * \param[in] ptRegion the target region
 * \return arm_fsm_rt_t the operation result
 */
extern
ARM_NONNULL(2,3,4)
arm_fsm_rt_t arm_2dp_cccn888_tile_fill_with_des_mask_and_xy_mirror(
                                        arm_2d_op_cp_msk_t *ptOP,
                                        const arm_2d_tile_t *ptSource,
                                        const arm_2d_tile_t *ptTarget,
                                        const arm_2d_tile_t *ptDesMask,
                                        const arm_2d_region_t *ptRegion);

/*! @} */

/*========================= POST INCLUDES ====================================*/
#include "__arm_2d_fill_colour_with_mask_and_mirroring.h"
#include "__arm_2d_fill_colour_with_masks_and_mirroring.h"
#include "__arm_2d_fill_colour_with_horizontal_line_mask.h"
#include "__arm_2d_fill_colour_with_vertical_line_mask.h"
#include "__arm_2d_fill_colour_with_alpha_gradient.h"
#include "__arm_2d_fill_colour_with_alpha_gradient_and_mask.h"
#include "__arm_2d_tile_copy_with_source_mask_and_opacity.h"
#include "__arm_2d_tile_fill_with_source_mask_and_opacity.h"
#include "__arm_2d_tile_fill_with_opacity.h"

#if defined(__clang__)
#pragma clang diagnostic pop
#endif

#ifdef   __cplusplus
}
#endif

#endif
