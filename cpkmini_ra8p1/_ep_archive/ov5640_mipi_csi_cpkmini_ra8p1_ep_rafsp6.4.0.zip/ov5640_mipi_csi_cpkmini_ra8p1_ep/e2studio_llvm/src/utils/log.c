#include <stdarg.h>
#include <stdio.h>

#include "log.h"

#if LOG_CFG_LEVEL < LOG_LEVEL_NONE

#if LOG_CFG_EN_SEGGER_RTT
#include "SEGGER_RTT/SEGGER_RTT.h"
#else
static const char *sc_clear = "\x1b[2J\x1b[H";
static const char *sc_default = "\x1B[0m";
#endif

#if LOG_CFG_EN_COLOR && (LOG_CFG_EN_SEGGER_RTT == 0)
static const char *sc_grey = "\x1B[0m\x1B[2m";
static const char *sc_yellow = "\x1B[0;33m";
static const char *sc_red = "\x1B[0;31m";
#endif

static uint8_t s_auto_endl = 1;
static char s_format_cache[LOG_CFG_FORMAT_SIZE];

static void logOutput(uint8_t level, const char *tag, const char *format, va_list args);

void LOG_Printf(const char *format, ...)
{
	va_list args;

	va_start(args, format);
	vsnprintf(s_format_cache, LOG_CFG_FORMAT_SIZE, format, args);
	va_end(args);
	LOG_Puts(s_format_cache);
}

void LOG_PrintfEndl(const char *format, ...)
{
	va_list args;

	va_start(args, format);
	vsnprintf(s_format_cache, LOG_CFG_FORMAT_SIZE, format, args);
	va_end(args);
	LOG_PutsEndl(s_format_cache);
}

void LOG_Reset(void)
{
#if LOG_CFG_EN_SEGGER_RTT
	LOG_PutsEndl(RTT_CTRL_RESET);
	LOG_PutsEndl(RTT_CTRL_CLEAR);
#else
    LOG_PutsEndl(sc_default);
    LOG_PutsEndl(sc_clear);
#endif
}

void LOG_SetAutoEndl(uint8_t val)
{
	s_auto_endl = val;
}
#endif

#if LOG_CFG_LEVEL <= LOG_LEVEL_DEBUG
void LOG_D(const char *tag, const char *format, ...)
{
	va_list args;

	va_start(args, format);
	logOutput(LOG_LEVEL_DEBUG, tag, format, args);
	va_end(args);
}
#endif

#if LOG_CFG_LEVEL <= LOG_LEVEL_INFO
void LOG_I(const char *tag, const char *format, ...)
{
	va_list args;

	va_start(args, format);
	logOutput(LOG_LEVEL_INFO, tag, format, args);
	va_end(args);
}
#endif

#if LOG_CFG_LEVEL <= LOG_LEVEL_WARN
void LOG_W(const char *tag, const char *format, ...)
{
	va_list args;

	va_start(args, format);
	logOutput(LOG_LEVEL_WARN, tag, format, args);
	va_end(args);
}
#endif

#if LOG_CFG_LEVEL <= LOG_LEVEL_ERROR
void LOG_E(const char *tag, const char *format, ...)
{
	va_list args;

	va_start(args, format);
	logOutput(LOG_LEVEL_ERROR, tag, format, args);
	va_end(args);
}
#endif

#if LOG_CFG_LEVEL < LOG_LEVEL_NONE
static void logOutput(uint8_t level, const char *tag, const char *format, va_list args)
{
#if LOG_CFG_EN_TIMESTAMP
	uint32_t s, ms;

	LOG_GetTime(&s, &ms);
#endif

#if LOG_CFG_EN_COLOR
	if (level == LOG_LEVEL_DEBUG) {
	#if LOG_CFG_EN_SEGGER_RTT
		LOG_Puts(RTT_CTRL_TEXT_WHITE);
	#else
		LOG_Puts(sc_grey);
	#endif
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("DEBUG ");
	}
	else if (level == LOG_LEVEL_INFO) {
	#if LOG_CFG_EN_SEGGER_RTT
		LOG_Puts(RTT_CTRL_RESET);
	#else
		LOG_Puts(sc_default);
	#endif
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("INFO  ");
	}
	else if (level == LOG_LEVEL_WARN) {
	#if LOG_CFG_EN_SEGGER_RTT
		LOG_Puts(RTT_CTRL_TEXT_BRIGHT_YELLOW);
	#else
		LOG_Puts(sc_yellow);
	#endif
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("WARN  ");
	}
	else {
	#if LOG_CFG_EN_SEGGER_RTT
		LOG_Puts(RTT_CTRL_TEXT_BRIGHT_RED);
	#else
		LOG_Puts(sc_red);
	#endif
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("ERROR ");
	}
#else
	if (level == LOG_LEVEL_DEBUG) {
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("DEBUG ");
	}
	else if (level == LOG_LEVEL_INFO) {
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("INFO  ");
	}
	else if (level == LOG_LEVEL_WARN) {
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("WARN  ");
	}
	else {
	#if LOG_CFG_EN_TIMESTAMP
		LOG_Printf("[%d.%03d] ", s, ms);
	#endif
		LOG_Puts("ERROR ");
	}
#endif

	if (tag != NULL) {
		LOG_Puts(tag);
		LOG_Puts(" ");
	}
	LOG_Puts("==> ");

	vsnprintf(s_format_cache, LOG_CFG_FORMAT_SIZE, format, args);
	if (s_auto_endl) {
		LOG_PutsEndl(s_format_cache);
	}
	else {
		LOG_Puts(s_format_cache);
	}
}

#if LOG_CFG_EN_SEGGER_RTT
void LOG_Puts(const char *str)
{
	SEGGER_RTT_TerminalOut(LOG_CFG_RTT_CHANNEL, str);
}
#elif LOG_CFG_HAS_STDIO
void LOG_Puts(const char *str)
{
	int i;

	for (i = 0; str[i]; i++) {
		putchar(str[i]);
	}
}
#else
void LOG_Puts(const char *str) __attribute__((weak));
void LOG_Puts(const char *str)
{
	(void)str;
}
#endif

#if LOG_CFG_EN_TIMESTAMP
void LOG_GetTime(uint32_t *s, uint32_t *ms) __attribute__((weak));
void LOG_GetTime(uint32_t *s, uint32_t *ms)
{
	*s = 0;
	*ms = 0;
}
#endif
#endif
