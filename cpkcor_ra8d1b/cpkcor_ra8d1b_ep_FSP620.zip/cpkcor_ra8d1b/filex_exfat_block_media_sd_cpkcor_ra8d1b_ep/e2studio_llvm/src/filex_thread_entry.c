#include "filex_thread.h"
#include "filex.h"
#include "filex_media_operation.h"
#include "filex_dir_operation.h"
#include "filex_file_operation.h"

#include "perf_counter/perf_counter.h"

static UINT conv_month_to_int(CHAR * p_month);
static UINT file_system_init(void);
static UINT file_system_operation(ULONG request);

/* Public global variable */
FX_MEDIA g_fx_media;
uint8_t g_fx_media_media_memory[G_FX_MEDIA_MEDIA_MEMORY_SIZE];
volatile media_status_t g_fx_media_status = (media_status_t)RESET_VALUE;

/* FileX Thread entry function */
void filex_thread_entry(void)
{
    UINT status = RESET_VALUE;
    ULONG actual_event = RESET_VALUE;

    /* Suspend thread until received start file system event flag  */
    actual_event = RESET_VALUE;
    status = tx_event_flags_get (&g_request_event, REQUEST_START_FILE_SYSTEM,
                                 TX_OR_CLEAR, &actual_event, TX_WAIT_FOREVER);
    if (TX_SUCCESS != status)
    {
        PRINT_ERR_STR("tx_event_flags_get for REQUEST_START_FILE_SYSTEM failed\r\n");
        ERROR_TRAP(status);
    }

    /* Initialize the FileX file system */
    status = file_system_init();
    if (FX_SUCCESS != status)
    {
        PRINT_ERR_STR("file_system_init failed\r\n");
        ERROR_TRAP(status);
    }

    while (true)
    {
        /* Wait for a request event from the console thread */
        actual_event = RESET_VALUE;
        status = tx_event_flags_get (&g_request_event, FILE_SYSTEM_REQUEST_MASK,
                                     TX_OR_CLEAR, &actual_event, TX_WAIT_FOREVER);
        if (TX_SUCCESS != status)
        {
            PRINT_ERR_STR("tx_event_flags_get for user request events failed\r\n");
            ERROR_TRAP(status);
        }

        /* Perform file system operations as required by the user */
        status = file_system_operation(actual_event);
        if (FX_SUCCESS != status)
        {
            PRINT_ERR_STR("file_system_operation failed\r\n");
            ERROR_TRAP(status);
        }

        /* Send a request complete event flag to the console thread */
        status = tx_event_flags_set (&g_request_event, REQUEST_COMPLETED, TX_OR);
        if (TX_SUCCESS != status)
        {
            PRINT_ERR_STR("tx_event_flags_set for REQUEST_COMPLETED event failed\r\n");
            ERROR_TRAP(status);
        }

        tx_thread_sleep (FILEX_THREAD_SLEEP_TICK);
    }
}

/*******************************************************************************************************************//**
 * @brief Block media callback function.
 * @param[in]  p_args
 * @retval     None
 **********************************************************************************************************************/
void g_rm_filex_block_media_callback(rm_filex_block_media_callback_args_t *p_args)
{
    switch(p_args->event)
    {
        case RM_BLOCK_MEDIA_EVENT_MEDIA_INSERTED:
            g_fx_media_status |= MEDIA_INSERTED;
        break;

        case RM_BLOCK_MEDIA_EVENT_MEDIA_REMOVED:
            g_fx_media_status &= ~(MEDIA_INSERTED);
        break;

        case RM_BLOCK_MEDIA_EVENT_WAIT_END:
            /* FileX driver returns RM_BLOCK_MEDIA_EVENT_WAIT_END event when an operation is completed.
             * It can be read, write or erase operation. If there is an occurrence of error event,
             * the FileX callback will still return the same event and the respective API
             * will return the specific error code. */
            tx_event_flags_set(&g_media_event, RM_BLOCK_MEDIA_EVENT_WAIT_END, TX_OR);
        break;

        case RM_BLOCK_MEDIA_EVENT_POLL_STATUS:
        case RM_BLOCK_MEDIA_EVENT_MEDIA_SUSPEND:
        case RM_BLOCK_MEDIA_EVENT_MEDIA_RESUME:
        case RM_BLOCK_MEDIA_EVENT_WAIT:
        default:
            break;
    }
}

/*******************************************************************************************************************//**
 * @brief       This function converts a string month to an integer month.
 * @param[in]   p_month     pointer to a string month
 * @retval      integer month
 **********************************************************************************************************************/
static UINT conv_month_to_int(CHAR * p_month)
{
    const CHAR * p_string[] = {"Nul","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

    /* Checks and convert month string to integer */
    for (UINT value = (UINT)JANUARY; value <= (UINT)DECEMBER ; value ++)
    {
        if(RESET_VALUE == strncmp (p_string[value], p_month, MONTH_STR_LEN))
        {
            return (UINT)value;
        }
    }
    /* Set the default month to JANUARY if month is not detected */
    return (UINT)JANUARY;
}

static UINT file_system_init(void)
{
    UINT fx_status = FX_SUCCESS;
    fsp_err_t fsp_err = FSP_SUCCESS;
    time_new_t system_time = {RESET_VALUE};

    /* Extract current Date from compiler MACROS */
    system_time.month = conv_month_to_int(__DATE__ + MONTH_INDEX);
    system_time.date = atoi(__DATE__ + DATE_INDEX);
    system_time.year = atoi(__DATE__ + YEAR_INDEX);

    /* Extract current Time from compiler MACROS */
    system_time.hour = atoi(__TIME__ + HOUR_INDEX);
    system_time.min  = atoi(__TIME__ + MIN_INDEX);
    system_time.sec  = atoi(__TIME__ + SEC_INDEX);

    /* Open and configure FileX Block Media interface */
    fsp_err = RM_FILEX_BLOCK_MEDIA_Open(&g_rm_filex_block_media_ctrl, &g_rm_filex_block_media_cfg);
    RETURN_ERR_STR((UINT)fsp_err, "RM_FILEX_BLOCK_MEDIA_Open failed\r\n");

    /* Initialize the FileX system */
    fx_system_initialize();

    /* Set date for FileX system */
    fx_status = fx_system_date_set (system_time.year, system_time.month, system_time.date);
    RETURN_ERR_STR(fx_status, "fx_system_date_set failed\r\n");

    /* Set time for FileX system */
    fx_status = fx_system_time_set (system_time.hour, system_time.min, system_time.sec);
    RETURN_ERR_STR(fx_status, "fx_system_time_set failed\r\n");

    return fx_status;
}

/*
 * Create a file with 1M size to do the read/write SPEED test.
 * 1 - check the file, if exist, check the file size.
 */
#define BENCHMARK_FILE_NAME		"/filex_benchmark.txt"
#define BENCHMARK_TEST_SIZE		(64 * 1024 * 1024)
static char benchmark_buffer[4096];

static int check_sdcard(FX_MEDIA *media)
{
	unsigned long available_space;
	int status;

    status = fx_media_space_available(media, &available_space);
	if (status != FX_SUCCESS) {
		APP_PRINT("get media space fail.\n");
		return status;
	}

	if (available_space < BENCHMARK_TEST_SIZE) {
		APP_PRINT("No enough space to do benchmark test, need 0x%x\n",
				BENCHMARK_TEST_SIZE);
		return -1;
	}

	return 0;
}

static int read_speed_test(FX_MEDIA *media, char *path)
{
	size_t size = BENCHMARK_TEST_SIZE;
	uint32_t ms, speed, read_size;
	FX_FILE file;
    UINT status;

	APP_PRINT("%s\n", __func__);
    status = fx_file_open(media, &file, path, FX_OPEN_FOR_READ);
    if (status != FX_SUCCESS) {
        APP_PRINT("open %s fail: %u\n", path, status);
        return - 1;
    }

	ms = (uint32_t)get_system_ms();
	while (size > 0) {
		status = fx_file_read(&file, benchmark_buffer, 4096, &read_size);
		if (status != FX_SUCCESS) {
			APP_PRINT("write %s fail %d.\n", path, status);
			return status;
		}
		size -= 4096;
	}
	ms = (uint32_t)get_system_ms() - ms;

    fx_file_close(&file);

	speed = (BENCHMARK_TEST_SIZE >> 10) * 1000 / ms;
	APP_PRINT("-----> Read speed (%u Bytes use %u ms) %uKB/s\n",
			BENCHMARK_TEST_SIZE, ms, speed);

	return 0;
}

static int write_speed_test(FX_MEDIA *media, char *path)
{
	size_t size = BENCHMARK_TEST_SIZE;
	uint32_t ms, speed;
	FX_FILE file;
    UINT status;

	APP_PRINT("%s please wait ...\n", __func__);
    status = fx_file_open(media, &file, path, FX_OPEN_FOR_WRITE);
    if (status != FX_SUCCESS) {
        APP_PRINT("open %s fail: %u\n", path, status);
        return - 1;
    }

	memset(benchmark_buffer, 'h', 4096);

	ms = (uint32_t)get_system_ms();
	while (size > 0) {
		status = fx_file_write(&file, benchmark_buffer, 4096);
		if (status != FX_SUCCESS) {
			APP_PRINT("write %s fail %d.\n", path, status);
			return status;
		}

		size -= 4096;
	}
	ms = (uint32_t)get_system_ms() - ms;

    fx_file_close(&file);

	speed = (BENCHMARK_TEST_SIZE >> 10) * 1000 / ms;
	APP_PRINT("-----> Write speed (%u Bytes use %u ms) %uKB/s\n",
			BENCHMARK_TEST_SIZE, ms, speed);

	return 0;
}

static int check_and_manage_file(FX_MEDIA *media, char *path)
{
    UINT attributes;
    ULONG file_size;
    UINT status;

    status = fx_directory_information_get(media, path,
			&attributes, &file_size, NULL, NULL, NULL, NULL, NULL, NULL);
	if (status == FX_SUCCESS) {
		status = fx_file_delete(media, path);
		if (status != FX_SUCCESS) {
			APP_PRINT("delete %s fail.\n", path);
			return status;
		}
	}

    status = fx_file_create(media, path);
    if (status != FX_SUCCESS && status != FX_ALREADY_CREATED) {
        APP_PRINT("fail to create %s: %u\n", path, status);
        return status;
    }

	return 0;
}

static fsp_err_t benchmark_test(void)
{
	APP_PRINT("%s\n", __func__);
	if (check_sdcard(&g_fx_media))
		return -1;

	if (check_and_manage_file(&g_fx_media,
				BENCHMARK_FILE_NAME))
		return -1;

	init_cycle_counter(true);

	write_speed_test(&g_fx_media, BENCHMARK_FILE_NAME);
	read_speed_test(&g_fx_media, BENCHMARK_FILE_NAME);

	return 0;
}

static UINT file_system_operation(ULONG request)
{
    UINT fx_status = FX_SUCCESS;

    switch (request)
    {
        case REQUEST_MEDIA_OPEN:
            PRINT_INFO_STR("Open media ...\r\n\r\n");
            fx_status = media_open();
            break;

        case REQUEST_MEDIA_PROPERTY:
            PRINT_INFO_STR("Get media properties ...\r\n\r\n");
            fx_status = media_get_property();
            break;

        case REQUEST_MEDIA_FORMAT:
            PRINT_INFO_STR("Format media in exFAT-format ...\r\n\r\n");
            fx_status = media_format();
            break;

        case REQUEST_MEDIA_CLOSE:
            PRINT_INFO_STR("Close media ...\r\n\r\n");
            fx_status = media_close();
            break;

        case REQUEST_DIR_CREATE:
            PRINT_INFO_STR("Create a new directory ...\r\n\r\n");
            fx_status = dir_create();
            break;

        case REQUEST_DIR_PROPERTY:
            PRINT_INFO_STR("Get directory properties ...\r\n\r\n");
            fx_status = dir_get_property();
            break;

        case REQUEST_DIR_DELETE:
            PRINT_INFO_STR("Delete a directory ...\r\n\r\n");
            fx_status = dir_delete();
            break;

        case REQUEST_FILE_CREATE:
            PRINT_INFO_STR("Create a new file ...\r\n\r\n");
            fx_status = file_create();
            break;

        case REQUEST_FILE_WRITE:
            PRINT_INFO_STR("Write to a file ...\r\n\r\n");
            fx_status = file_write();
            break;

        case REQUEST_FILE_READ:
            PRINT_INFO_STR("Read from a file ...\r\n\r\n");
            fx_status = file_read();
            break;

        case REQUEST_FILE_DELETE:
            PRINT_INFO_STR("Delete a file ...\r\n\r\n");
            fx_status = file_delete();
            break;

		case REQUEST_FILE_SPEED_TEST:
            PRINT_INFO_STR("File read/write speed test ...\r\n\r\n");
			fx_status = media_open();
			if (fx_status != FX_SUCCESS) {
				APP_PRINT("open media fail.\n");
				break;
			}
			benchmark_test();
			media_close();
			break;

        default:
            PRINT_INFO_STR("This request is not supported\r\n\r\n");
            break;
    }

    return fx_status;
}
