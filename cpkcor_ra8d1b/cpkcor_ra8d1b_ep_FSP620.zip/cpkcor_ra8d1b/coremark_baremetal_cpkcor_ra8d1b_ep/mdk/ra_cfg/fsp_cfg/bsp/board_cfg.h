/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#include "../../../ra/board/ra8d1_cpkcor/board.h"
#endif /* BOARD_CFG_H_ */
