/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA8D1BHECBD
      #define BSP_MCU_FEATURE_SET ('B')
      #define BSP_NUMBER_OF_CORES (1)
      #define BSP_PACKAGE_BGA
      #define BSP_ROM_SIZE_BYTES (2064384)
      #define BSP_RAM_SIZE_BYTES (917504)
      #define BSP_DATA_FLASH_SIZE_BYTES (12288)
      #define BSP_PACKAGE_PINS (224)
      #define BSP_OSPI0_CS0_START_ADDRESS (2147483648)
      #define BSP_OSPI0_CS0_SIZE_BYTES (268435456)
      #define BSP_OSPI0_CS1_START_ADDRESS (2415919104)
      #define BSP_OSPI0_CS1_SIZE_BYTES (268435456)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
