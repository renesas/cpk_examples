function writeVersionDropdown() {
  /* dummy function not used for local docs */
}
