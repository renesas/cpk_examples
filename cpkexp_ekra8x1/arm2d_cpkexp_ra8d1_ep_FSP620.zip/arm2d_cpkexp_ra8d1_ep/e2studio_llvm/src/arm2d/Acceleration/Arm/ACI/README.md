**NOTE**: 

1. This Helium-ACI library is for demonstration purpose. 
2. This library **ONLY** supports **RGB565**.
3. This library **ONLY** accelerates operations that used in the **Generic Benchmark** and the **Watch-Panel Benchmark**. If you need other 2D operations, please contact us.