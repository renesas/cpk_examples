
/* Generated on Sat Apr 13 03:08:08 2024 from -i */
/* Re-sized : True */
/* Rotated : 0.0 deg */



#include "arm_2d.h"

#if defined(__clang__)
#   pragma clang diagnostic push
#   pragma clang diagnostic ignored "-Wunknown-warning-option"
#   pragma clang diagnostic ignored "-Wreserved-identifier"
#   pragma clang diagnostic ignored "-Wmissing-variable-declarations"
#   pragma clang diagnostic ignored "-Wcast-qual"
#elif defined(__IS_COMPILER_ARM_COMPILER_5__)
#   pragma diag_suppress=1296
#endif


ARM_ALIGN(4) ARM_SECTION("arm2d.asset.c_bmpListCoverLineAlpha")
static const uint8_t c_bmpListCoverLineAlpha[1*80] = {
/* -0- */
0xe0, 
/* -1- */
0xf5, 
/* -2- */
0xea, 
/* -3- */
0xe2, 
/* -4- */
0xda, 
/* -5- */
0xd2, 
/* -6- */
0xca, 
/* -7- */
0xc2, 
/* -8- */
0xba, 
/* -9- */
0xb3, 
/* -10- */
0xab, 
/* -11- */
0xa3, 
/* -12- */
0x9b, 
/* -13- */
0x93, 
/* -14- */
0x8b, 
/* -15- */
0x83, 
/* -16- */
0x7b, 
/* -17- */
0x73, 
/* -18- */
0x6b, 
/* -19- */
0x63, 
/* -20- */
0x5b, 
/* -21- */
0x53, 
/* -22- */
0x4b, 
/* -23- */
0x43, 
/* -24- */
0x3c, 
/* -25- */
0x37, 
/* -26- */
0x31, 
/* -27- */
0x2c, 
/* -28- */
0x26, 
/* -29- */
0x21, 
/* -30- */
0x1b, 
/* -31- */
0x15, 
/* -32- */
0x10, 
/* -33- */
0x0a, 
/* -34- */
0x04, 
/* -35- */
0x00, 
/* -36- */
0x00, 
/* -37- */
0x00, 
/* -38- */
0x00, 
/* -39- */
0x00, 
/* -40- */
0x00, 
/* -41- */
0x00, 
/* -42- */
0x00, 
/* -43- */
0x00, 
/* -44- */
0x02, 
/* -45- */
0x08, 
/* -46- */
0x0d, 
/* -47- */
0x13, 
/* -48- */
0x18, 
/* -49- */
0x1e, 
/* -50- */
0x23, 
/* -51- */
0x28, 
/* -52- */
0x2e, 
/* -53- */
0x33, 
/* -54- */
0x39, 
/* -55- */
0x3d, 
/* -56- */
0x44, 
/* -57- */
0x4c, 
/* -58- */
0x54, 
/* -59- */
0x5c, 
/* -60- */
0x64, 
/* -61- */
0x6c, 
/* -62- */
0x73, 
/* -63- */
0x7b, 
/* -64- */
0x83, 
/* -65- */
0x8b, 
/* -66- */
0x93, 
/* -67- */
0x9b, 
/* -68- */
0xa3, 
/* -69- */
0xab, 
/* -70- */
0xb3, 
/* -71- */
0xba, 
/* -72- */
0xc2, 
/* -73- */
0xca, 
/* -74- */
0xd2, 
/* -75- */
0xda, 
/* -76- */
0xe2, 
/* -77- */
0xea, 
/* -78- */
0xf3, 
/* -79- */
0xed, 
};
ARM_ALIGN(4) ARM_SECTION("arm2d.asset.c_bmpListCoverLineA2Alpha")
static const uint8_t c_bmpListCoverLineA2Alpha[1*80] = {
/* -0- */
0x03, 
/* -1- */
0x03, 
/* -2- */
0x03, 
/* -3- */
0x03, 
/* -4- */
0x03, 
/* -5- */
0x03, 
/* -6- */
0x03, 
/* -7- */
0x03, 
/* -8- */
0x02, 
/* -9- */
0x02, 
/* -10- */
0x02, 
/* -11- */
0x02, 
/* -12- */
0x02, 
/* -13- */
0x02, 
/* -14- */
0x02, 
/* -15- */
0x02, 
/* -16- */
0x01, 
/* -17- */
0x01, 
/* -18- */
0x01, 
/* -19- */
0x01, 
/* -20- */
0x01, 
/* -21- */
0x01, 
/* -22- */
0x01, 
/* -23- */
0x01, 
/* -24- */
0x00, 
/* -25- */
0x00, 
/* -26- */
0x00, 
/* -27- */
0x00, 
/* -28- */
0x00, 
/* -29- */
0x00, 
/* -30- */
0x00, 
/* -31- */
0x00, 
/* -32- */
0x00, 
/* -33- */
0x00, 
/* -34- */
0x00, 
/* -35- */
0x00, 
/* -36- */
0x00, 
/* -37- */
0x00, 
/* -38- */
0x00, 
/* -39- */
0x00, 
/* -40- */
0x00, 
/* -41- */
0x00, 
/* -42- */
0x00, 
/* -43- */
0x00, 
/* -44- */
0x00, 
/* -45- */
0x00, 
/* -46- */
0x00, 
/* -47- */
0x00, 
/* -48- */
0x00, 
/* -49- */
0x00, 
/* -50- */
0x00, 
/* -51- */
0x00, 
/* -52- */
0x00, 
/* -53- */
0x00, 
/* -54- */
0x00, 
/* -55- */
0x00, 
/* -56- */
0x01, 
/* -57- */
0x01, 
/* -58- */
0x01, 
/* -59- */
0x01, 
/* -60- */
0x01, 
/* -61- */
0x01, 
/* -62- */
0x01, 
/* -63- */
0x01, 
/* -64- */
0x02, 
/* -65- */
0x02, 
/* -66- */
0x02, 
/* -67- */
0x02, 
/* -68- */
0x02, 
/* -69- */
0x02, 
/* -70- */
0x02, 
/* -71- */
0x02, 
/* -72- */
0x03, 
/* -73- */
0x03, 
/* -74- */
0x03, 
/* -75- */
0x03, 
/* -76- */
0x03, 
/* -77- */
0x03, 
/* -78- */
0x03, 
/* -79- */
0x03, 
};
ARM_ALIGN(4) ARM_SECTION("arm2d.asset.c_bmpListCoverLineA4Alpha")
static const uint8_t c_bmpListCoverLineA4Alpha[1*80] = {
/* -0- */
0x0e, 
/* -1- */
0x0f, 
/* -2- */
0x0e, 
/* -3- */
0x0e, 
/* -4- */
0x0d, 
/* -5- */
0x0d, 
/* -6- */
0x0c, 
/* -7- */
0x0c, 
/* -8- */
0x0b, 
/* -9- */
0x0b, 
/* -10- */
0x0a, 
/* -11- */
0x0a, 
/* -12- */
0x09, 
/* -13- */
0x09, 
/* -14- */
0x08, 
/* -15- */
0x08, 
/* -16- */
0x07, 
/* -17- */
0x07, 
/* -18- */
0x06, 
/* -19- */
0x06, 
/* -20- */
0x05, 
/* -21- */
0x05, 
/* -22- */
0x04, 
/* -23- */
0x04, 
/* -24- */
0x03, 
/* -25- */
0x03, 
/* -26- */
0x03, 
/* -27- */
0x02, 
/* -28- */
0x02, 
/* -29- */
0x02, 
/* -30- */
0x01, 
/* -31- */
0x01, 
/* -32- */
0x01, 
/* -33- */
0x00, 
/* -34- */
0x00, 
/* -35- */
0x00, 
/* -36- */
0x00, 
/* -37- */
0x00, 
/* -38- */
0x00, 
/* -39- */
0x00, 
/* -40- */
0x00, 
/* -41- */
0x00, 
/* -42- */
0x00, 
/* -43- */
0x00, 
/* -44- */
0x00, 
/* -45- */
0x00, 
/* -46- */
0x00, 
/* -47- */
0x01, 
/* -48- */
0x01, 
/* -49- */
0x01, 
/* -50- */
0x02, 
/* -51- */
0x02, 
/* -52- */
0x02, 
/* -53- */
0x03, 
/* -54- */
0x03, 
/* -55- */
0x03, 
/* -56- */
0x04, 
/* -57- */
0x04, 
/* -58- */
0x05, 
/* -59- */
0x05, 
/* -60- */
0x06, 
/* -61- */
0x06, 
/* -62- */
0x07, 
/* -63- */
0x07, 
/* -64- */
0x08, 
/* -65- */
0x08, 
/* -66- */
0x09, 
/* -67- */
0x09, 
/* -68- */
0x0a, 
/* -69- */
0x0a, 
/* -70- */
0x0b, 
/* -71- */
0x0b, 
/* -72- */
0x0c, 
/* -73- */
0x0c, 
/* -74- */
0x0d, 
/* -75- */
0x0d, 
/* -76- */
0x0e, 
/* -77- */
0x0e, 
/* -78- */
0x0f, 
/* -79- */
0x0e, 
};

ARM_SECTION("arm2d.asset.c_bmpListCoverLineGRAY8")
const uint8_t c_bmpListCoverLineGRAY8[1*80] = {
/* -0- */
0x00, 
/* -1- */
0x00, 
/* -2- */
0x00, 
/* -3- */
0x00, 
/* -4- */
0x00, 
/* -5- */
0x00, 
/* -6- */
0x00, 
/* -7- */
0x00, 
/* -8- */
0x00, 
/* -9- */
0x00, 
/* -10- */
0x00, 
/* -11- */
0x00, 
/* -12- */
0x00, 
/* -13- */
0x00, 
/* -14- */
0x00, 
/* -15- */
0x00, 
/* -16- */
0x00, 
/* -17- */
0x00, 
/* -18- */
0x00, 
/* -19- */
0x00, 
/* -20- */
0x00, 
/* -21- */
0x00, 
/* -22- */
0x00, 
/* -23- */
0x00, 
/* -24- */
0x00, 
/* -25- */
0x00, 
/* -26- */
0x00, 
/* -27- */
0x00, 
/* -28- */
0x00, 
/* -29- */
0x00, 
/* -30- */
0x00, 
/* -31- */
0x00, 
/* -32- */
0x00, 
/* -33- */
0x00, 
/* -34- */
0x00, 
/* -35- */
0x00, 
/* -36- */
0x00, 
/* -37- */
0x00, 
/* -38- */
0x00, 
/* -39- */
0x00, 
/* -40- */
0x00, 
/* -41- */
0x00, 
/* -42- */
0x00, 
/* -43- */
0x00, 
/* -44- */
0x00, 
/* -45- */
0x00, 
/* -46- */
0x00, 
/* -47- */
0x00, 
/* -48- */
0x00, 
/* -49- */
0x00, 
/* -50- */
0x00, 
/* -51- */
0x00, 
/* -52- */
0x00, 
/* -53- */
0x00, 
/* -54- */
0x00, 
/* -55- */
0x00, 
/* -56- */
0x00, 
/* -57- */
0x00, 
/* -58- */
0x00, 
/* -59- */
0x00, 
/* -60- */
0x00, 
/* -61- */
0x00, 
/* -62- */
0x00, 
/* -63- */
0x00, 
/* -64- */
0x00, 
/* -65- */
0x00, 
/* -66- */
0x00, 
/* -67- */
0x00, 
/* -68- */
0x00, 
/* -69- */
0x00, 
/* -70- */
0x00, 
/* -71- */
0x00, 
/* -72- */
0x00, 
/* -73- */
0x00, 
/* -74- */
0x00, 
/* -75- */
0x00, 
/* -76- */
0x00, 
/* -77- */
0x00, 
/* -78- */
0x00, 
/* -79- */
0x00, 
};

ARM_SECTION("arm2d.asset.c_bmpListCoverLineRGB565")
const uint16_t c_bmpListCoverLineRGB565[1*80] = {
/* -0- */
0x0000, 
/* -1- */
0x0000, 
/* -2- */
0x0000, 
/* -3- */
0x0000, 
/* -4- */
0x0000, 
/* -5- */
0x0000, 
/* -6- */
0x0000, 
/* -7- */
0x0000, 
/* -8- */
0x0000, 
/* -9- */
0x0000, 
/* -10- */
0x0000, 
/* -11- */
0x0000, 
/* -12- */
0x0000, 
/* -13- */
0x0000, 
/* -14- */
0x0000, 
/* -15- */
0x0000, 
/* -16- */
0x0000, 
/* -17- */
0x0000, 
/* -18- */
0x0000, 
/* -19- */
0x0000, 
/* -20- */
0x0000, 
/* -21- */
0x0000, 
/* -22- */
0x0000, 
/* -23- */
0x0000, 
/* -24- */
0x0000, 
/* -25- */
0x0000, 
/* -26- */
0x0000, 
/* -27- */
0x0000, 
/* -28- */
0x0000, 
/* -29- */
0x0000, 
/* -30- */
0x0000, 
/* -31- */
0x0000, 
/* -32- */
0x0000, 
/* -33- */
0x0000, 
/* -34- */
0x0000, 
/* -35- */
0x0000, 
/* -36- */
0x0000, 
/* -37- */
0x0000, 
/* -38- */
0x0000, 
/* -39- */
0x0000, 
/* -40- */
0x0000, 
/* -41- */
0x0000, 
/* -42- */
0x0000, 
/* -43- */
0x0000, 
/* -44- */
0x0000, 
/* -45- */
0x0000, 
/* -46- */
0x0000, 
/* -47- */
0x0000, 
/* -48- */
0x0000, 
/* -49- */
0x0000, 
/* -50- */
0x0000, 
/* -51- */
0x0000, 
/* -52- */
0x0000, 
/* -53- */
0x0000, 
/* -54- */
0x0000, 
/* -55- */
0x0000, 
/* -56- */
0x0000, 
/* -57- */
0x0000, 
/* -58- */
0x0000, 
/* -59- */
0x0000, 
/* -60- */
0x0000, 
/* -61- */
0x0000, 
/* -62- */
0x0000, 
/* -63- */
0x0000, 
/* -64- */
0x0000, 
/* -65- */
0x0000, 
/* -66- */
0x0000, 
/* -67- */
0x0000, 
/* -68- */
0x0000, 
/* -69- */
0x0000, 
/* -70- */
0x0000, 
/* -71- */
0x0000, 
/* -72- */
0x0000, 
/* -73- */
0x0000, 
/* -74- */
0x0000, 
/* -75- */
0x0000, 
/* -76- */
0x0000, 
/* -77- */
0x0000, 
/* -78- */
0x0000, 
/* -79- */
0x0000, 
};

ARM_SECTION("arm2d.asset.c_bmpListCoverLineCCCA8888")
const uint32_t c_bmpListCoverLineCCCA8888[1*80] = {
/* -0- */
0xe0000000, 
/* -1- */
0xf5000000, 
/* -2- */
0xea000000, 
/* -3- */
0xe2000000, 
/* -4- */
0xda000000, 
/* -5- */
0xd2000000, 
/* -6- */
0xca000000, 
/* -7- */
0xc2000000, 
/* -8- */
0xba000000, 
/* -9- */
0xb3000000, 
/* -10- */
0xab000000, 
/* -11- */
0xa3000000, 
/* -12- */
0x9b000000, 
/* -13- */
0x93000000, 
/* -14- */
0x8b000000, 
/* -15- */
0x83000000, 
/* -16- */
0x7b000000, 
/* -17- */
0x73000000, 
/* -18- */
0x6b000000, 
/* -19- */
0x63000000, 
/* -20- */
0x5b000000, 
/* -21- */
0x53000000, 
/* -22- */
0x4b000000, 
/* -23- */
0x43000000, 
/* -24- */
0x3c000000, 
/* -25- */
0x37000000, 
/* -26- */
0x31000000, 
/* -27- */
0x2c000000, 
/* -28- */
0x26000000, 
/* -29- */
0x21000000, 
/* -30- */
0x1b000000, 
/* -31- */
0x15000000, 
/* -32- */
0x10000000, 
/* -33- */
0x0a000000, 
/* -34- */
0x04000000, 
/* -35- */
0x00000000, 
/* -36- */
0x00000000, 
/* -37- */
0x00000000, 
/* -38- */
0x00000000, 
/* -39- */
0x00000000, 
/* -40- */
0x00000000, 
/* -41- */
0x00000000, 
/* -42- */
0x00000000, 
/* -43- */
0x00000000, 
/* -44- */
0x02000000, 
/* -45- */
0x08000000, 
/* -46- */
0x0d000000, 
/* -47- */
0x13000000, 
/* -48- */
0x18000000, 
/* -49- */
0x1e000000, 
/* -50- */
0x23000000, 
/* -51- */
0x28000000, 
/* -52- */
0x2e000000, 
/* -53- */
0x33000000, 
/* -54- */
0x39000000, 
/* -55- */
0x3d000000, 
/* -56- */
0x44000000, 
/* -57- */
0x4c000000, 
/* -58- */
0x54000000, 
/* -59- */
0x5c000000, 
/* -60- */
0x64000000, 
/* -61- */
0x6c000000, 
/* -62- */
0x73000000, 
/* -63- */
0x7b000000, 
/* -64- */
0x83000000, 
/* -65- */
0x8b000000, 
/* -66- */
0x93000000, 
/* -67- */
0x9b000000, 
/* -68- */
0xa3000000, 
/* -69- */
0xab000000, 
/* -70- */
0xb3000000, 
/* -71- */
0xba000000, 
/* -72- */
0xc2000000, 
/* -73- */
0xca000000, 
/* -74- */
0xd2000000, 
/* -75- */
0xda000000, 
/* -76- */
0xe2000000, 
/* -77- */
0xea000000, 
/* -78- */
0xf3000000, 
/* -79- */
0xed000000, 
};


extern const arm_2d_tile_t c_tileListCoverLineGRAY8;
ARM_SECTION("arm2d.tile.c_tileListCoverLineGRAY8")
const arm_2d_tile_t c_tileListCoverLineGRAY8 = {
    .tRegion = {
        .tSize = {
            .iWidth = 1,
            .iHeight = 80,
        },
    },
    .tInfo = {
        .bIsRoot = true,
        .bHasEnforcedColour = true,
        .tColourInfo = {
            .chScheme = ARM_2D_COLOUR_GRAY8,
        },
    },
    .pchBuffer = (uint8_t*)c_bmpListCoverLineGRAY8,
};




extern const arm_2d_tile_t c_tileListCoverLineRGB565;
ARM_SECTION("arm2d.tile.c_tileListCoverLineRGB565")
const arm_2d_tile_t c_tileListCoverLineRGB565 = {
    .tRegion = {
        .tSize = {
            .iWidth = 1,
            .iHeight = 80,
        },
    },
    .tInfo = {
        .bIsRoot = true,
        .bHasEnforcedColour = true,
        .tColourInfo = {
            .chScheme = ARM_2D_COLOUR_RGB565,
        },
    },
    .phwBuffer = (uint16_t*)c_bmpListCoverLineRGB565,
};




extern const arm_2d_tile_t c_tileListCoverLineCCCA8888;

ARM_SECTION("arm2d.tile.c_tileListCoverLineCCCA8888")
const arm_2d_tile_t c_tileListCoverLineCCCA8888 = {
    .tRegion = {
        .tSize = {
            .iWidth = 1,
            .iHeight = 80,
        },
    },
    .tInfo = {
        .bIsRoot = true,
        .bHasEnforcedColour = true,
        .tColourInfo = {
            .chScheme = ARM_2D_COLOUR_BGRA8888,
        },
    },
    .pwBuffer = (uint32_t*)c_bmpListCoverLineCCCA8888,
};





extern const arm_2d_tile_t c_tileListCoverLineMask2;

ARM_SECTION("arm2d.tile.c_tileListCoverLineMask2")
const arm_2d_tile_t c_tileListCoverLineMask2 = {
    .tRegion = {
        .tSize = {
            .iWidth = 1,
            .iHeight = 80,
        },
    },
    .tInfo = {
        .bIsRoot = true,
        .bHasEnforcedColour = true,
        .tColourInfo = {
            .chScheme = ARM_2D_CHANNEL_8in32,
        },
    },
    .nAddress = ((intptr_t)c_bmpListCoverLineCCCA8888) + 3,
};




extern const arm_2d_tile_t c_tileListCoverLineMask;

ARM_SECTION("arm2d.tile.c_tileListCoverLineMask")
const arm_2d_tile_t c_tileListCoverLineMask = {
    .tRegion = {
        .tSize = {
            .iWidth = 1,
            .iHeight = 80,
        },
    },
    .tInfo = {
        .bIsRoot = true,
        .bHasEnforcedColour = true,
        .tColourInfo = {
            .chScheme = ARM_2D_COLOUR_8BIT,
        },
    },
    .pchBuffer = (uint8_t *)c_bmpListCoverLineAlpha,
};




extern const arm_2d_tile_t c_tileListCoverLineA2Mask;

ARM_SECTION("arm2d.tile.c_tileListCoverLineA2Mask")
const arm_2d_tile_t c_tileListCoverLineA2Mask = {
    .tRegion = {
        .tSize = {
            .iWidth = 1,
            .iHeight = 80,
        },
    },
    .tInfo = {
        .bIsRoot = true,
        .bHasEnforcedColour = true,
        .tColourInfo = {
            .chScheme = ARM_2D_COLOUR_MASK_A2,
        },
    },
    .pchBuffer = (uint8_t *)c_bmpListCoverLineA2Alpha,
};




extern const arm_2d_tile_t c_tileListCoverLineA4Mask;

ARM_SECTION("arm2d.tile.c_tileListCoverLineA4Mask")
const arm_2d_tile_t c_tileListCoverLineA4Mask = {
    .tRegion = {
        .tSize = {
            .iWidth = 1,
            .iHeight = 80,
        },
    },
    .tInfo = {
        .bIsRoot = true,
        .bHasEnforcedColour = true,
        .tColourInfo = {
            .chScheme = ARM_2D_COLOUR_MASK_A4,
        },
    },
    .pchBuffer = (uint8_t *)c_bmpListCoverLineA4Alpha,
};



#if defined(__clang__)
#   pragma clang diagnostic pop
#elif defined(__IS_COMPILER_ARM_COMPILER_5__)
#   pragma diag_warning=1296
#endif


