# Overview
This folder contains templates for adding user defined opcode:

- An OPCODE Template for copy-like 2D operations that take a target tile, a source tile and user defined arguments.
